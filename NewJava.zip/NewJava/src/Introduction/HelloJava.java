package Introduction;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

class HelloJava {
	public static void main(String[] args) {
	
		String [][] argus = new String[2][2];
		int x;
		argus[0] = args;
		x = argus[0].length;
		for(int i=0;i<x;i++){
			System.out.print(" "+argus[0][i]);
		}
		
		Set<Integer> set = new HashSet<Integer>();
		set.add(1);
		set.add(2);
	
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		map.put(1, 1);
		map.put(2, 2);
		map.put(3, 3);
		map.keySet();
		System.out.println(map.keySet());
		System.out.println(map);
		
 	}
}