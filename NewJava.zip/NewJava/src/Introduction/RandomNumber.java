package Introduction;

import java.util.Random;

public class RandomNumber {
	
	 public static String generateRandom(int length) {
	        length--;
	        char[] chars = "0123456789".toCharArray();
	        Random rnd = new Random();
	        StringBuilder sb = new StringBuilder();
	        // Should not start with zero
	        sb.append(chars[rnd.nextInt(9) + 1]);
	        for (int i = 0; i < length; i++) {
	            sb.append(chars[rnd.nextInt(10)]);
	        }
	        return sb.toString();
	 }
	 
	 
	 public static int getSum(int x){
		 int rem =0;
		 while(x!=0){
			 rem = rem +  x%10;
			 x = x/10;
		 }
		 return rem;
	 }
	 
	 public static void main(String args[]){
		 System.out.println(generateRandom(6));
		 System.out.println(getSum(12345));
	 }
}
