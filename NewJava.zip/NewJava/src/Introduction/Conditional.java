package Introduction;

import java.util.Scanner;

class Conditional {
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		System.out.println("Enter marks..");
		int x = in.nextInt();
		if (x > 60) {
			System.out.println("1st Division..><");
		} else if (x > 50 && x <= 60) {
			System.out.println("2nd division..");
		} else if (x > 40 && x <= 50) {
			System.out.println("3rd division..");
		} else {
			System.out.println("fail :p ");
		}
	}
}
