package Introduction;

import java.util.HashMap;
import java.util.Map;

class ABC {
	int x;
	static int y;
	void cal(int a, int b){
		x +=a;
		y +=b;
	}
	
}

class Dog{
	
}

public class TestJava {

	public static void main(String args[]) {
		ABC obj1 = new ABC();
		ABC obj2 = new ABC();
		obj1.x=0;
		obj1.y=0;
		System.out.println(obj1.x+" "+obj2.y);
		obj1.cal(1, 2);
		System.out.println(obj1.x+" "+obj2.y);
		obj2.x=0;
		System.out.println(obj1.x+" "+obj2.y);
		obj1.cal(2, 3);
		System.out.println(obj1.x+" "+obj2.y);
		
		int x = 0;
		try{
			int y = 5/x;
		}catch(Exception  e){
			System.out.println("ASD");
		}
		
		int arr[] = {1,2};
		int arr1[] = new int[2];
		
		Dog arr2[][] = new Dog[3][];
		//System.out.println(arr2[2][0].toString());
		int abc = 5;
		//System.out.println(abc.toString());
		System.out.println(String.valueOf(abc));
		
		System.out.println();
				
	}

}
