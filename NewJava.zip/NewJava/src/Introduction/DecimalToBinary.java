package Introduction;

public class DecimalToBinary {
	
	public static void main(String args[]){
		int n = 10;
		char ch[] = Integer.toBinaryString(n).toCharArray();
		for(int i=0;i<ch.length;i++){
			System.out.print(ch[i]+" ");
		}
	}

}
