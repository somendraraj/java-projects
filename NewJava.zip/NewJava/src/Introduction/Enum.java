package Introduction;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class Enum {
	
	public static void main(String args[]){
		ArrayList<String> list = new ArrayList<String>();
		String str = "\"{\"1234\",\"1234\",\"1234\",\"1234\",\"1234\",1234}\"";
		list.add("\"123456789\",");
		list.add("\"123456789\",");
		list.add("\"123456789\",");
		list.add("\"123456789\",");
		for(String l: list){
			System.out.println(l);
		}
		List<String> List = new ArrayList<String>(Arrays.asList(str.split("\\s+")));
		System.out.println(List.get(0).toString());
		System.out.println(List.toString());
		String str1 = "REOPEN 1234567";
		String[] s = str1.split("\\s+");
		String s1 = s[0];
		String s2 = s[1];
		System.out.println(s1+" "+s2);
		
		String regex = "\r\n\\s+";
		String s3 = "Hello\r\n\r\n\r\n\r\nsomendra";
		String s4 = s3.replaceAll("(\r\n|\\s+)", "");
		System.out.println(s3.replaceAll(regex, " "));
		System.out.println(s4);
		
		String s5 = "Hello Somendra!";
		try {
			final byte[] utf8Bytes = s5.getBytes("UTF-8");
			System.out.println(utf8Bytes.length);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
	}

}
