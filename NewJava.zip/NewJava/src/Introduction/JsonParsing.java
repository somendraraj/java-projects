package Introduction;

import java.util.List;

public class JsonParsing {

	public static void main(String args[]) {
		final String JSON_STR = "";
		StringBuilder sb = new StringBuilder();
		String ticket_id = "123WERTY123";
		String desc= "This is description ";
		String create_date = "12 may 2017";
		String new_status = "Open";
		sb.append("TicketId: " + ticket_id+"\n");
		sb.append("Desc: " + desc+"\n");
		sb.append("Date: " + create_date+"\n");
		sb.append("Status: " + new_status+"\n");
		System.out.println(sb);
		
		
		
	}
}
