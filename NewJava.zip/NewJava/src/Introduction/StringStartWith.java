package Introduction;

class A {
	public static void method() {
		System.out.println("private method");
	}
}

public class StringStartWith {

	public static void main(String args[]) {
		String prefix = "reopen";
		String str1 = "REOPEN RCPB123456";
		String str2 = "REOPEN   ";
		String str3 = "welcome to bangalore 12345";
		if (str1.startsWith(prefix.toUpperCase())) {
			System.out.println(str1);
		}
		if (str2.startsWith(prefix.toUpperCase()))
			System.out.println(str2);
		if (str3.startsWith("reopen"))
			System.out.println(str3);

		System.out.println(str1.replace("REOPEN", "").trim());
		System.out.println(str3.toUpperCase());

		StringStartWith obj = new StringStartWith();
		A obj1 = new A();
		obj1.method();
	}

}
