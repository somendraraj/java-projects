package FiveHundredDS.Matrix;

import com.google.common.base.Optional;

public class AddTester {
	
	static Integer add(Optional<Integer> a, Optional<Integer> b){
		System.out.println(a.isPresent());
		System.out.println(b.isPresent());
		Integer val1 = a.or(new Integer(0));
		Integer val2 = b.get();
		return val1+val2;
	}
	
	public static void main(String args[]){
		Integer val1 = null;
		Integer val2 = new Integer(10);
		 
      //Optional.fromNullable - allows passed parameter to be null.
      Optional<Integer> a = Optional.fromNullable(val1);
      
      Optional<Integer> b = Optional.fromNullable(val2);
		System.out.println(add(a, b));
	}

}
