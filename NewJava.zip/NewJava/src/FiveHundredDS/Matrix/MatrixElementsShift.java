package FiveHundredDS.Matrix;


/*Shift all the elements by one position in MxN Matrix*/
public class MatrixElementsShift {
	static void rightShift(int arr[][], int m, int n){
		int top = 0, bottom = m-1;
		int left = 0, right = n-1;
		int prev = arr[0][0];
		while(true){
			if(left>right)
				break;
			//change top row
			for(int i=left;i<=right;i++)
				swap(arr[top][i], prev);
			top++;
			if(top>bottom)
				break;
			//change right column
			for(int i=top;i<=bottom;i++)
				swap(arr[i][right], prev);
			right--;
			
			if(left>right)
				break;
			//change bottom row
			for(int i=right;i>=left;i--)
				swap(arr[bottom][i], prev);
			bottom--;
			
			if(top>bottom)
				break;
			for(int i=bottom;i>=top;i--)
				swap(arr[i][left], prev);
			left++;
		}
		arr[0][0] = prev;
		
	}
	
	public static void main(String args[]){
		int arr[][]  = {{1,2,3,10},
				   		{4,5,6, 11},
				   		{7,8,9, 12},
				   		{13, 14, 15, 16}
				  };
		int m = 4;
		int n = 4;
		
		rightShift(arr, m, n);
		
		for(int i=0;i<m;i++){
			for(int j=0;j<n;j++){
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	static void swap(int i, int j){
		int temp = i;
		i = j;
		j = temp;
	}
	
}
