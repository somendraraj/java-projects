package FiveHundredDS.Matrix;


/*Given a MXN Matrix Print in spiral order*/
public class SpiralMatrix {
	
	/**
	 * 
	 * @param arr
	 * @param m
	 * @param n
	 */
	static void printSpiralMatrix(int arr[][], int m, int n){
		int top = 0, bottom = m-1;
		int left = 0, right = n-1;
		
		while(true){
			if(left>right)
				break;
			//Print top row
			for(int i=left;i<=right;i++)
				System.out.print(arr[top][i]+" ");
			top++;
			//Print right column
			for(int i=top;i<=bottom;i++)
				System.out.print(arr[i][right]+" ");
			right--;
			//Print bottom row
			for(int i=right;i>=left;i--)
				System.out.print(arr[bottom][i]+" ");
			bottom--;
			//print left column
			for(int i=bottom;i>=top;i--)
				System.out.print(arr[i][left]+" ");
			left++;
		}
	}
	
	
	/**
	 * Using Recursion method
	 * 
	 * @param arr
	 * @param top
	 * @param bottom
	 * @param left
	 * @param right
	 */
	static void printMatrix(int arr[][], int top, int bottom, int left, int right){
		if(left>right)
			return;
		for(int i=left;i<=right;i++)
			System.out.print(arr[top][i]+" ");
		top++;
		if(top>right)
			return;
		for(int i=top;i<=bottom;i++)
			System.out.print(arr[i][right]+" ");
		right--;
		if(left>right)
			return;
		for(int i=right;i>=left;i--)
			System.out.print(arr[bottom][i]+" ");
		bottom--;
		if(top>bottom)
			return;
		for(int i=bottom;i>=top;i--)
			System.out.print(arr[i][left]+" ");
		left++;
		printMatrix(arr, top, bottom, left, right);
	}
	
	public static void main(String args[]){
		
		int arr[][] = {{1,2,3,10},
					   {4,5,6, 11},
					   {7,8,9, 12},
					   {13, 14, 15, 16}
					  };
		int m = 4;
		int n = 4;
		printSpiralMatrix(arr, m, n);
		System.out.println();
		printMatrix(arr, 0, 3, 0, 3);
		
	}

}
