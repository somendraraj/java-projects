package FiveHundredDS.Matrix;

import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;

public class BetweenTwoSets {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int m = in.nextInt();
		int[] a = new int[n];
		for (int a_i = 0; a_i < n; a_i++) {
			a[a_i] = in.nextInt();
		}
		int[] b = new int[m];
		for (int b_i = 0; b_i < m; b_i++) {
			b[b_i] = in.nextInt();
		}
		int start = a[n - 1];
		int end = b[0];

		int arr[] = new int[end - start + 1];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = start + i;
		}

		Set<Integer> s = getFactors(a, arr);

		int cnt = getFactorsWithSet(s, b);
		System.out.println(cnt);

	}

	static Set<Integer> getFactors(int arr1[], int arr2[]) {
		Set<Integer> set = new HashSet<Integer>();
		for (int i = 0; i < arr2.length; i++) {
			int count = 0;
			for (int j = 0; j < arr1.length; j++) {
				if ((arr2[i] % arr1[j]) == 0) {
					count++;
				}
				if (count == arr1.length) {
					set.add(arr2[i]);
				}
			}
		}

		return set;
	}

	static int getFactorsWithSet(Set<Integer> s, int arr[]) {
		int cnt = 0;
		for (Integer i : s) {
			int count = 0;
			for (int j = 0; j < arr.length; j++) {
				if ((arr[j] % i) == 0) {
					count++;
				}
				if (count == arr.length) {
					cnt++;
				}
			}

		}

		return cnt;
	}

}