package FiveHundredDS.Matrix;

/*Create a spiral matrix by given matrix*/
public class CreateSpiralMatrix {
	
	static void createSpiralMatrix(int arr[], int m, int n){
		int left = 0, right = m-1;
		int top = 0, bottom = n-1;
		int index = 0;
		int mat[][] = new int[m][n];
		while(true){
			if(left>right)
				break;
			for(int i=left;i<=right;i++)
				mat[top][i] = arr[index++];
			top++;
			if(top>bottom)
				break;
			for(int i=top;i<=bottom;i++)
				mat[i][right] = arr[index++];
			right--;
			if(left>right)
				break;
			for(int i=right;i>=left;i--)
				mat[bottom][i] = arr[index++];
			bottom--;
			if(top>bottom)
				break;
			for(int i=bottom;i>=top;i--)
				mat[i][left] = arr[index++];
			left++;
		}
		
		for(int i=0;i<m;i++){
			for(int j=0;j<n;j++){
				System.out.print(mat[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public static void main(String args[]){
		int arr[] = new int[25];
		arr[0] = 10;
		for(int i=1;i<25;i++){
			arr[i] = arr[i-1] +1;
		}
		
		createSpiralMatrix(arr, 5, 5);
	}
	
}
