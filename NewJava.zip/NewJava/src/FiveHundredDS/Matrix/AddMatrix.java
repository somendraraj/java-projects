package FiveHundredDS.Matrix;

public class AddMatrix {
	
	public  static void addSquareMatrix(int arr1[][], int arr2[][], int n){
		int [][]arr = new int[n][n];
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				arr[i][j] = arr1[i][j]+arr2[i][j];
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public static void main(String args[]){
		int a[][] =  {{1,2,3},{4,5,6},{7,8,9}};
		int b[][] =  {{9,8,7},{6,5,4},{3,2,1}};
		addSquareMatrix(a, b, 3);
	}

}
