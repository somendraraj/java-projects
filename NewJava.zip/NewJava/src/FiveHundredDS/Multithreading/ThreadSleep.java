package FiveHundredDS.Multithreading;

public class ThreadSleep extends Thread {

	public void run() {
		for (int i = 0; i < 5; i++) {
			try {
				Thread.sleep(800);
			} catch (InterruptedException ex) {
				System.out.println(ex);
			}
			System.out.println(i+" "+Thread.currentThread().getName());	
		}
	}

	public static void main(String args[]) {
		ThreadSleep t1 = new ThreadSleep();
		ThreadSleep t2 = new ThreadSleep();
		ThreadSleep t3 = new ThreadSleep();
		ThreadSleep t4 = new ThreadSleep();
		t1.start();
		t2.start();
		t3.start();
		t4.start();
	}

}
