package FiveHundredDS.Multithreading;

public class RunnableInterface implements Runnable {

	public void run() {

		try {
			for (int i = 0; i < 5; i++) {
				System.out.println("Thread is running...!"+i);
				Thread.sleep(1000);
			}

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String args[]) {
		RunnableInterface t = new RunnableInterface();
		Thread t1 = new Thread(t);
		t1.start();
	}

}
