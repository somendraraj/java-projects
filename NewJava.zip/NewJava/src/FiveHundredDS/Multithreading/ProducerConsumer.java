package FiveHundredDS.Multithreading;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/*Implements producer and consumer problem using blocking queue*/
class Producer extends Thread{
	private BlockingQueue<Integer> sharedQueue;
	
	public Producer(BlockingQueue<Integer> aQueue){
		super("Producer");
		this.sharedQueue=aQueue;
	}
	
	public void run(){
		for(int i=0;i<10;i++){
			try{
				System.out.print(getName()+" produced "+i);
				sharedQueue.put(i);
				Thread.sleep(1000);
			}catch(InterruptedException  e){
				e.printStackTrace();
			}
		}
	}
}

class Consumer extends Thread{
	private BlockingQueue<Integer> sharedQueue;
	
	public Consumer(BlockingQueue<Integer> aQueue){
		super("Consumer");
		this.sharedQueue=aQueue;
	}
	
	public void run(){
		for(int i=0;i<10;i++){
			try{
				sharedQueue.take();
				System.out.print(" "+getName()+" consumed "+i+"\n");
				Thread.sleep(1000);
			}catch(InterruptedException e){
				e.printStackTrace();
			}
		}
	}
}

public class ProducerConsumer {
	
	public static void main(String args[]){
		BlockingQueue<Integer> blQueue = new LinkedBlockingQueue<Integer>();
		Producer p = new Producer(blQueue);
		Consumer c = new Consumer(blQueue);
		
		p.start();
		c.start();
		
	}
}
