package FiveHundredDS.Multithreading;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.lang.Throwable;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DbFile {
	public static volatile boolean finished = false;
	private static final String FILE_HEADER = "id,userid,mobileno,imei"+"\n";

	public static void main(final String[] args) throws InterruptedException {
		final ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<String>(10000);
		final Thread writeWorker = new Thread("File Writer") {
			public void run() {
				try {
					LocalDate localDate = LocalDate.now();
					File targetFile = new File("lyf_"+localDate+".csv");
					FileWriter fileWriter = new FileWriter(targetFile);
					fileWriter.append(FILE_HEADER.toString());
					BufferedWriter writer = new BufferedWriter(fileWriter);
					
					String str;
					try {
						while (!finished) {
							str = queue.poll(100, TimeUnit.MILLISECONDS);

							if (str == null) {
								Thread.sleep(50);
								continue;
							}
							writer.write(str);
							writer.write('\n');
						}
					} catch (InterruptedException e) {
						writer.flush();
						writer.close();
						return;
					}finally{
						writer.flush();
						writer.close();
					}
				} catch (Throwable e) {
					
					e.printStackTrace();
					return;
				}
			}
		};

		final Thread readerThread = new Thread("DB Reader") {
			public void run() {
				try {
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "");

					Statement stmt = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
					stmt.setFetchSize(10000);
					ResultSet rs = stmt.executeQuery("select id, userId, mobileno, imei from lyfmobiletable");
					System.out.println("Fetching result");
					while (rs.next()) {
						StringBuilder sb = new StringBuilder();
						sb.append(rs.getInt(1)).append(',');
						sb.append(rs.getString(2)).append(',');
						sb.append(rs.getString(3)).append(',');
						sb.append(rs.getString(4)).append(',');
						queue.put(sb.toString());
						//System.out.println("queue size"+queue.size());
					}
					rs.close();
					stmt.close();
					conn.close();
					finished = true;
				} catch (Throwable e) {
					e.printStackTrace();
					return;
				}
			}
		};
		long startTime = System.currentTimeMillis();
		writeWorker.start();
		readerThread.start();
		System.out.println("Waiting for join..");
		readerThread.join();
		//writeWorker.join();
		System.out.println("Exit:" + (System.currentTimeMillis() - startTime));
	}
}