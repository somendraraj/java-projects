package FiveHundredDS.Test;

import java.util.HashMap;
import java.util.Map;

public class Cache {
	
	public static void main(String args[]){
		Map<Integer, String> map = new HashMap<Integer, String>();
		System.out.println(System.currentTimeMillis());
		
		for(int i=0;i<1000000;i++){
			map.put(i, "value: "+i);
		}
		System.out.println(System.currentTimeMillis());
		if(map.containsKey(956767)){
			System.out.println(map.get(95677));
		}
		System.out.println(System.nanoTime());
	}
}
