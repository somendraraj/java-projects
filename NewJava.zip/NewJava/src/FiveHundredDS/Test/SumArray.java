package FiveHundredDS.Test;

public class SumArray {
	
	
	public static void main(String artgs[]){
		int arr[] = {1,2,3,7,4,-2};;
		int sum = 0;
		for(int i=0;i<arr.length;i++){
			sum = sum+arr[i];
		}
		
		System.out.println(sum);
	}
	
	
	static void getPair(int arr[], int n){
		for(int i=0;i<arr.length-1;i++){
			for(int j=i+1;j<arr.length;j++){
				if(arr[i]+arr[j]==n){
					System.out.println(arr[i]+" "+arr[j]);
					break;
				}
			}
		}
	}

}
