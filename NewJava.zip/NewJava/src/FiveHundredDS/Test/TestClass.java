package FiveHundredDS.Test;

import java.util.*;
import java.util.Map.Entry;

public class TestClass {

	static int getMaxNumber(String str, int n, int m) {
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			Integer val = map.get(new Character(c));
			if (val != null) {
				map.put(c, new Integer(val + 1));
			} else {
				map.put(c, 1);
			}
		}
		Iterator iterator = map.entrySet().iterator();
		int pos = 0;
		List<Integer> list = new ArrayList<Integer>();
		while (iterator.hasNext()) {
			Entry iter = (Entry) iterator.next();
			Character key = (Character) iter.getKey();
			int val = (int) iter.getValue();
			list.add(val);
		}
		Collections.sort(list);
		return list.get(list.size() - 1) + m;
	}

	public static void main(String args[]) throws Exception {

		Scanner s = new Scanner(System.in);
		int t = s.nextInt();
		while (t-- > 0) {
			int n = s.nextInt();
			int m = s.nextInt();
			String st = s.nextLine();
			String str = s.nextLine();
			int res = getMaxNumber(str, n, m);
			System.out.println(res);
		}
	}

}
