package FiveHundredDS.Test;

public class TurnOff {
	
	static int turnOffK(int n, int k){
		if(n<=0)
			return n;
		return (n&~(1<<(k-1)));
	}
	
	public static void main(String args[]){
		int x = 15;
		int k = 3;
		System.out.println(turnOffK(x, k));
		System.out.println((1<<(2)));
	}

}
