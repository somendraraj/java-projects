package FiveHundredDS.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class HashMapSet {
	
	public static void main(String args[]){
		Map<String,List<String>> map = new HashMap<String, List<String>>();
		List<String> list = new ArrayList<String>();
		list.add("thsi is loist");
		list.add("that is another list");
		map.put("abc", list);
		map.put("abc1", list);
		map.put("abc3", list);
		
		Set<Entry<String, List<String>>> set = map.entrySet();
		Iterator<Entry<String, List<String>>> iter = set.iterator();
		while (iter.hasNext()) {
			Entry<String, List<String>> entry = (Entry<String, List<String>>) iter.next();
			String key = entry.getKey();
			List<String> val = entry.getValue();
			System.out.println(key+": "+val);
		}
		//System.out.println(set);
	}

}
