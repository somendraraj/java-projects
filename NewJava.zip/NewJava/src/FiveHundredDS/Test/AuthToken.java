/*package FiveHundredDS.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBElement.GlobalScope;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jio.common.KeyConstant;
import com.jio.common.OauthFilter;

public class AuthToken {

	private static final Logger log = LoggerFactory.getLogger(OauthFilter.class);
	private static final Pattern OAUTH_HEADER = Pattern.compile("\\s*(\\w*)\\s+(.*)");

	public static boolean filterToken(HttpServletRequest request) {
		log.info("filterToken start..!");
		String authHeader = request.getHeader(KeyConstant.AUTHORIZATION);
		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
			return false;
		}
		String filterToken = getAuthHeaderField(authHeader);
		if (filterToken == null || filterToken.equals("")) {
			log.info("filterToken is null...");
			return false;
		} else {
			return true;
		}
	}

	private static String getAuthHeaderField(String authHeader) {
		if (authHeader != null && authHeader != "") {
			String[] auth = authHeader.split("\\s+");
			if (auth[1].equalsIgnoreCase(Global.AUTHTOKEN))
				return auth[1];
		}
		return "";
	}

	public static void main(String args[]) {

	}

}
*/