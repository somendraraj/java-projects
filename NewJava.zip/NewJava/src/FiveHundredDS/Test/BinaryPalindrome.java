package FiveHundredDS.Test;

public class BinaryPalindrome {
	
	static boolean isKthBitSet(int x, int k){
		return ((x & (1<<(k-1)))==1)?true:false;
	}
	
	static boolean isPalindrome(int x){
		int l = 1;
		int r = 32;
		while(l<r){
			if(isKthBitSet(x, l)!= isKthBitSet(x, r)){
				return false;
			}
			l++;
			r--;
		}
		return true;
	}
	
	public static void main(String args[]){
		int x =  1<<15 + 1<<16;
		System.out.println(x);
		System.out.println(isPalindrome(x));
	}

}
