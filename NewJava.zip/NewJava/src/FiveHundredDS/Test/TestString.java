package FiveHundredDS.Test;

public class TestString {
	public static void main(String args[]){
		String str = " EC XXXXXXX";
		
		System.out.println(str.indexOf("EC"));
	}
}
