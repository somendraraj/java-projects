package FiveHundredDS.Test;

public class RegexTest {

	public static void main(String args[]) {
		String str = "reOpenc";
		String regex = "^\\s+(REOPEN)|(reopen)|(_REOPEN)|(REOPEN-)$";
		String regex1 = ".*(reopen| REOPEN|_REOPEN|REOPEN-).*";

		if (str.toLowerCase().matches(regex1)) {
			System.out.println("true");
		} else {
			System.out.println("False");
		}
	}

}
