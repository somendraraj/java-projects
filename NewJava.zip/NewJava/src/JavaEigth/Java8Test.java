package JavaEigth;

import java.util.ArrayList;
import java.util.List;

public class Java8Test {

	interface MathOperation {
		int operation(int a, int b);
	}

	private int operate(int a, int b, MathOperation mathOperation) {
		return mathOperation.operation(a, b);
	}

	public static void main(String args[]) {

		Java8Test tester = new Java8Test();

		// addition with type declaration
		MathOperation addition = (int a, int b) -> a + b;

		// without type declaration
		MathOperation subtraction = (a, b) -> a - b;

		MathOperation multiply = (a, b) -> a * b;

		MathOperation division = (a, b) -> a / b;

		System.out.println("10 + 5 = " + tester.operate(10, 5, addition));
		System.out.println("10 - 5 = " + tester.operate(10, 5, subtraction));
		System.out.println("10 * 5 = " + tester.operate(10, 5, multiply));
		System.out.println("10 / 5 = " + tester.operate(10, 5, division));

		/* For loop in java 8 */
		forEach();

	}

	static void forEach() {
		List<String> list = new ArrayList<String>();

		list.add("acb");
		list.add("cde");
		list.add("fgh");

		list.forEach(System.out::println);
	}

}
