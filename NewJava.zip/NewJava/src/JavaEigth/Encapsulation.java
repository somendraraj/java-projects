package JavaEigth;

public class Encapsulation {
	
	public static void main(String args[]){
		Class1 obj = new Class1("Mukesh", 22);
		obj.setName("Somendra");
		obj.setAge(20);
		System.out.println("Name: "+obj.getName()+"\nAge: "+obj.getAge());	
	}

}
