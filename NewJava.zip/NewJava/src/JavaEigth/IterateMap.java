package JavaEigth;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class IterateMap {
	public static void main(String args[]){
		Map<String, Integer> items = new HashMap<>();
		items.put("A", 10);
		items.put("B", 20);
		items.put("C", 30);
		items.put("D", 40);
		items.put("E", 50);
		items.put("F", 60);
		
		System.out.println("IN JAVA 7");
		for (Map.Entry<String, Integer> entry : items.entrySet()) {
			System.out.println("Item : " + entry.getKey() + " Count : " + entry.getValue());
		}
		System.out.println("IN JAVA 8");
		
		items.forEach((k,v)->System.out.println("Item : " + k + " Count : " + v));
		
		int[] arr = new int[10];
		int ik=0;
		items.forEach((k,v)->{
			//System.out.println("Item : " + k + " Count : " + v);
			arr[ik] = v;
			if("E".equals(k)){
				System.out.println("Hello E");
			}
		});
		
		//for loop in list
		System.out.println("List in JAVA");
		ArrayList<String> list = new ArrayList<String>();
		list.add("A");
		list.add("B");
		list.add("C");
		list.add("K");
		list.add("D");
		list.add("E");
		
		for(String i: list){
			System.out.println(i);
		}
		System.out.println("JAVA 8 Method for list");
		list.forEach(item->System.out.println(item));
		
		for(Integer i:arr){
			System.out.print(i+" ");
		}
	}
}