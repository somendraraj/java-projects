package com;

import java.util.Scanner;

public class RecurStr {
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		System.out.println(getMin(n));
		
	}
	
	static String getMin(int n){
		String str = "min(int, ";
		String lst = ")";
		String res = "min(int, int)";
		for(int i=3;i<=n;i++){
			res =  str+res+lst;
		}
		
		return res;
	}

}
