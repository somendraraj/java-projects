package com;

/*Given an array A[] and a number x, check for pair in A[] with sum as x*/

public class ArayPairSum {
	
	private static final int MAX = 100;
	
	public static void main(String args[]){
		int arr[] = {1,2,3,7,4,-2};
		int k = 5;
		System.out.println("Method 1");
		getPairSum(arr, k);
		System.out.println("Method 2");
		getPairSumNew(arr, k);
	}
	
	/*Order of n square*/
	static void getPairSum(int arr[], int k){
		int n = arr.length;
		for(int i=0;i<n-1;i++){
			for(int j=i+1;j<n;j++){
				if(arr[i]+arr[j] == k){
					System.out.println("{"+arr[i]+", "+arr[j]+"}");
				}
			}
		}
	}
	
	/*Order of n*/
	static void getPairSumNew(int arr[], int k){
		int n = arr.length;
		boolean count[] = new boolean[n];
		
		for(int i=0;i<n;++i){
			int temp = k - arr[i];
			if(temp>=0 && count[temp]){
				System.out.println("{"+arr[i]+", "+temp+"}");
			}
			count[arr[i]] = true;
		}
	}

}
