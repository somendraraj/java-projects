package com;

public class MelodyPassword {
	
	public static void main(String args[]){
		int n = 3;
		getPassword(n);
	}
	
	static void getPassword(int n){
		String vowel = "aeiou";
		String consonent = "bcdfghjklmnpqrstvwxz";
		char vo[] = vowel.toCharArray();
		char co[] = consonent.toCharArray();
		if(n == 1){
			for(int i=0;i<vowel.length();i++){
				System.out.println(vo[i]);
			}
			for(int i=0;i<consonent.length();i++){
				System.out.println(co[i]);
			}
		}else if(n == 2){
			for(int i=0;i<consonent.length();i++){
				for(int j=0;j<vowel.length();j++){
					String s = new StringBuilder(co[i]).append(vo[j]).toString();
					System.out.println(""+co[i]+vo[j]);
				}
			}
			for(int i=0;i<vowel.length();i++){
				for(int j=0;j<consonent.length();j++){
					System.out.println(""+vo[i]+co[j]);
				}
			}
			
		}else if(n == 3){
			for(int i=0;i<consonent.length();i++){
				for(int j=0;j<vowel.length();j++){
					for(int k=0;k<consonent.length();k++){
						System.out.println(""+co[i]+vo[j]+co[k]);
					}
					
				}
			}
			for(int i=0;i<vowel.length();i++){
				for(int j=0;j<consonent.length();j++){
					for(int k=0;k<vowel.length();k++){
						System.out.println(""+vo[i]+co[j]+vo[k]);
					}
					
				}
			}
		}
	}

}
