package com;

public class LongestCommonSubsequence {
	
	
	/*Recursive approach to find LCS time complexity close to O(2^n)*/
	static int getLCS(char []X, int i, int m, char []Y, int j, int n){
		if(i == m || j == n){
			return 0;
		}else if(X[i] == Y[j]){
			return 1+ getLCS(X, i+1, m, Y, j+1, n);
		}else {
			return Math.max(getLCS(X, i+1, m, Y, j, n), getLCS(X, i, m, Y, j+1, n));
		}
	}
	
	/*DP approach to find LCS*/
	static int LCS[][] = new int[1024][1024];
	static int getLCSByDP(char []X, int m, char []Y, int n){
		for(int i=0;i<=m;i++){
			LCS[i][n] = 0;
		}
		for(int j=0;j<=m;j++){
			LCS[m][j] = 0;
		}
		
		for(int i=m-1;i>=0;i--){
			for(int j=n-1;j>=0;j--){
				LCS[i][j] =LCS[i+1][j+1]; //matching x[i] to y[i]
				if(X[i] == Y[j]){
					LCS[i][j]++; // we found a matching pair
				}
				if(LCS[i][j+1] > LCS[i][j])
					LCS[i][j] = LCS[i][j+1];
				if(LCS[i+1][j] > LCS[i][j])
					LCS[i][j] = LCS[i+1][j];
			}
		}
		return LCS[0][0];
	}
	
	
	public static void main(String args[]){
		String str1 = "ABCDABCE";
		String str2 = "ABCXYZDB";
		int m = str1.length();
		int n = str2.length();
		char []X = str1.toCharArray();
		char []Y = str2.toCharArray();
		int len = getLCS(X, 0, m-1, Y, 0, n-1);
		System.out.println(len);
		
		
		int lendp = getLCSByDP(X, m, Y, n);
		System.out.println(lendp);
	}

}
