package com;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class RansomeNote {
	
	// Map<String, Integer> magazineMap;
	  //  Map<String, Integer> noteMap;
	    Map<Integer, String> magazineMap;
	    Map<Integer, String> noteMap;
	    
	    public RansomeNote(String magazine, String note) {
	       Map magazineMap = new HashMap<Integer, String>();
	        Map noteMap = new HashMap<Integer, String>();
	        
	        String mArray[] = magazine.split(" ");
	        for(int i=0;i<mArray.length; i++){
	        	magazineMap.put(i, mArray[i]);
	        }
	        
	        String nArray[] = note.split(" ");
	        for(int i=0;i<nArray.length;i++){
	        	noteMap.put(i, nArray[i]);
	        }
	    }
	    
	    public boolean solve() {
	        for(int key:noteMap.keySet()){
	        	String value = noteMap.get(key);
	        	if(magazineMap.containsKey(value)){
	        		magazineMap.remove(key);
	        	}else{
	        		return false;
	        	}
	        }
	        return true;
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        int m = scanner.nextInt();
	        int n = scanner.nextInt();
	        
	        // Eat whitespace to beginning of next line
	        scanner.nextLine();
	        
	        RansomeNote s = new RansomeNote(scanner.nextLine(), scanner.nextLine());
	        scanner.close();
	        
	        boolean answer = s.solve();
	        if(answer)
	            System.out.println("Yes");
	        else System.out.println("No");
	      
	    }
}
