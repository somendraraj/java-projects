package com.designpattern;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public class TinyUrlEncoder {
	
	private final static int SHORTURL_LENGTH = 6;
    
    private static Map<String, String> shortURLMap = new HashMap<>(); 
    private static Map<String, String> longURLMap = new HashMap<>();
    private static Random rand = new Random();
    
    String randomGeneratgor() {
        //size = 10 + 26 * 2
        StringBuilder shortURL = new StringBuilder();
        for(int i = 0;i < SHORTURL_LENGTH;++i) {
            int r = rand.nextInt(62);
            if(r < 10) {
                shortURL.append(r);
            } else if(r < 36) {
                shortURL.append((char)(r - 10 + 'a'));
            } else {
                shortURL.append((char)(r - 36 + 'A'));
            }
        }
        return shortURL.toString();
    }
    
    String generateShortURL() {
        String shortURL = randomGeneratgor();
        while(shortURLMap.containsKey(shortURL)) {
            shortURL = randomGeneratgor();
        }
        return shortURL;
    }
    
    // Encodes a URL to a shortened URL.
    public String encode(String longUrl) {
        if(longURLMap.containsKey(longUrl)) {
            return longURLMap.get(longUrl);
        }
        
        String shortURL = generateShortURL();
        shortURLMap.put(shortURL, longUrl);
        longURLMap.put(longUrl, shortURL);
        return shortURL;
    }

    // Decodes a shortened URL to its original URL.
    public String decode(String shortUrl) {
        if(!shortURLMap.containsKey(shortUrl)) {
            throw new RuntimeException("No such short URL");
        }
        return shortURLMap.get(shortUrl);
    }

    
    public static void main(String args[]){
    	
    	String url = "https://www.geeksforgeeks.org/how-to-design-a-tiny-url-or-url-shortener/";
    	TinyUrlEncoder obj = new TinyUrlEncoder();
    	int n = 1;
    	while(n<=10){
    		System.out.println(obj.encode(url+n));
    		n++;
    	}
    	System.out.println(shortURLMap.size());
    	//System.out.println(longURLMap);
    	int i =1;
    	while(i<100){
    		System.out.println(generate());
    		i++;
    	}
    	i=0;
    	Set<Integer> set = new HashSet<Integer>();
    	while(i<=200){
    		set.add(rand.nextInt(62));
    		i++;
    	}
    	System.out.println("Set Size: "+set);
    }
    
    
    

    private static final AtomicInteger sequence = new AtomicInteger(1);

    public static int generate(){
        return sequence.getAndIncrement();
    }
    
   
}
