package com.designpattern;

import java.lang.reflect.Constructor;

class Singleton {
	public static Singleton instance = new Singleton();

	private Singleton() {

	}
}

public class GFC {
	public static void main(String args[]) {
		Singleton instance1 = Singleton.instance;
		Singleton instance2 = null;
		try {
			Constructor[] constructors = Singleton.class.getDeclaredConstructors();
			for (Constructor cons : constructors) {
				cons.setAccessible(true);
				instance2 = (Singleton) cons.newInstance();
				break;
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		System.out.println("instance1.hashCode():- " + instance1.hashCode());
		System.out.println("instance2.hashCode():- " + instance2.hashCode());
		System.out.println("instance1.hashCode():- " + instance1.hashCode());
		System.out.println("instance2.hashCode():- " + instance2.hashCode());

	}
}
