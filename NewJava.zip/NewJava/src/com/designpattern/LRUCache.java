package com.designpattern;

import java.util.HashMap;

class Node {
	int key;
	int value;
	Node prev;
	Node next;

}

public class LRUCache {

	HashMap<Integer, Node> hashmap = new HashMap();
	Node start, end;
	int LRU_SIZE = 4;

	public int get(int key) {
		if (hashmap.containsKey(key)) {
			Node node = hashmap.get(key);
			removeNode(node);
			addAtTop(node);
			return node.value;
		}
		return -1;
	}

	public void put(int key, int value) {

		if (hashmap.containsKey(key)) {
			Node entry = hashmap.get(key);
			entry.value = value;
			removeNode(entry);
			addAtTop(entry);
		} else {
			Node newnode = new Node();
			newnode.prev = null;
			newnode.next = null;
			newnode.value = value;
			newnode.key = key;
			if (hashmap.size() > LRU_SIZE) {
				hashmap.remove(end.key);
				removeNode(end);
				addAtTop(newnode);
			} else {
				addAtTop(newnode);
			}

			hashmap.put(key, newnode);
		}
	}

	public void addAtTop(Node node) {
		node.next = start;
		node.prev = null;
		if (start != null)
			start.prev = node;
		start = node;
		if (end == null)
			end = start;
	}

	public void removeNode(Node node) {

		if (node.prev != null) {
			node.prev.next = node.next;
		} else {
			start = node.next;
		}

		if (node.next != null) {
			node.next.prev = node.prev;
		} else {
			end = node.prev;
		}
	}

	public static void main(String[] args) throws java.lang.Exception {
		// your code goes here
		LRUCache lrucache = new LRUCache();
		lrucache.put(1, 1);
		lrucache.put(10, 15);
		lrucache.put(15, 10);
		lrucache.put(10, 16);
		lrucache.put(12, 15);
		lrucache.put(18, 10);
		lrucache.put(13, 16);

		System.out.println(lrucache.get(1));
		System.out.println(lrucache.get(10));
		System.out.println(lrucache.get(15));

	}

}
