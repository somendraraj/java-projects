package com.prep.algo;

public class ElementAppearsOnce {
	
	private static int elementAppearsOnce(int[] arr){
		int ones = 0;
		int twos = 0;
		int commonBitMask;
		for(int i=1;i<arr.length;i++){
			twos = twos | (ones&arr[i]);
			ones = ones ^arr[i];
			commonBitMask = ~(ones&twos);
			ones &= commonBitMask;
			twos &= commonBitMask;
		}
		return ones;
	}
	
	public static void main(String args[]){
		int[] arr = {1,2,3,2,4,6,7,6,4,7,7,6,4,3,3,2};
		int res = elementAppearsOnce(arr);
		System.out.println(res);
	}

}
