package com.prep.algo;

public class ModuloDivisionBy2 {
	
	/**
	 * 
	 * modulo operation using bitwise operation
	 * 
	 * @param n
	 * @param d
	 * @return
	 */
	private static int mod(int n, int d){
		return (n&(d-1));
	}
	
	public static void main(String args[]){
		int num = 15;
		int divisor = 4;
		System.out.println(mod(num, divisor));
		
	}

}
