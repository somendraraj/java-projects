package com.prep.algo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RunningMeidan {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		List<Integer> list = new ArrayList<>();
		for(int i=0;i<n;i++){
			int val = sc.nextInt();
			int lo = 0;
			int hi = list.size();
			while(lo<hi){
				int median = (lo+hi)/2;
				if(val>=list.get(median)){
					lo = median + 1;
					if(median+1< list.size() && val <= list.get(median+1)){
						hi = median + 1;
					}
				}else{
					hi = median;
					if(median>0 && val>= list.get(median)-1)
						lo = median;
				}
				
			}
			list.add(lo, val);
			
			System.out.println(String.format("%.1f", getMedian(list)));
		}

	}

	public static float getMedian(List<Integer> list) {
		if (list.isEmpty()) {
			return 0;
		} else if (list.size() % 2 == 1) {
			return list.get((list.size()) / 2);
		} else {
			return (list.get(list.size() / 2 - 1) + list.get(list.size() / 2)) / 2f;
		}
	}

}
