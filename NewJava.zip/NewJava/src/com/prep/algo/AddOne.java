package com.prep.algo;

public class AddOne {
	
	/**
	 * 
	 * method for adding one using bitwise operator
	 * 
	 * @param n
	 * @return
	 */
	private static int addOne(int n){
		int m = 1;
		
		/*Flip all the set bits after rightmost zero*/
		while((n&m) == 1){
			n = n^m;
			m <<= 1;
		}
		
		/*flip the rightmost 0 bits*/
		n = n^m;
		return n;
	}
	
	
	private static int addOneToNumber(int n){
		return (-(~n));
	}
	
	
	public static void main(String args[]){
		
		int n = 12;	
		int res = addOne(n);
		System.out.println(res);
		System.out.println(2<<1);
		
		System.out.println(addOneToNumber(12));
		
	}

}
