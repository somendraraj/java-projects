package com.prep.algo;

public class Multiply3Point5 {
	
	
	private static double multiply3Point5(int n){
		return (n<<1)+n+ (n>>1);
	}
	
	public static void main(String args[]){
		int n = 4;
		double res = multiply3Point5(n);
		System.out.println(res);
	}

}
