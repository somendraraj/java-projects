package com.prep.algo;

public class TurnOffRightMostSetBit {
	
	
	public static void main(String args[]){
		
		int n = 7;
		System.out.println(n&(n-1));
		
	}

}
