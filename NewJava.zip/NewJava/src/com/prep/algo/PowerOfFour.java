package com.prep.algo;

public class PowerOfFour {

	/*
	 * divide the number by 4 iteratively and check if number%4 is not equal to
	 * 0 then return false otherwise return true
	 */

	/**
	 * 
	 * @param n
	 * @return
	 */
	private static boolean powerOfFour(int n) {
		if (n == 0)
			return false;
		while (n != 1) {
			if (n % 4 != 0)
				return false;
			n /= 4;
		}
		return true;
	}

	/**
	 * wrong method
	 * 
	 * @param n
	 * @return
	 */
	private static boolean powerOfFour1(int n) {
		int count = 0;
		if ( (n&(n-1)) !=1 ) {
			while (n > 1) {
				n >>= 1;
				count++;
			}
			return (count % 2 == 0) ? true : false;
		}
		return false;

	}

	public static void main(String args[]) {
		int n = 20;
		System.out.println(powerOfFour(n));
		System.out.println(powerOfFour1(20));
	}

}
