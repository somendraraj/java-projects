package com;

public class MaximumContigousSum {
	
	
	/*Less efficient solution*/
	static int maximumContigousSum(int arr[]){
		int n = arr.length;
		int maxSum = 0;
		for(int i=0;i<n;i++){
			for(int j=i;j<n;j++){
				int currentSum = 0;
				for(int k=i;k<=j;k++)
					currentSum += arr[k];
				if(currentSum > maxSum)
					maxSum = currentSum;
			}
		}
		return maxSum;
	}
	
	/*Optimized code*/
	static int maxContigousSum(int arr[]){
		int n = arr.length;
		int maxSum = 0;
		for(int i=0;i<n;i++){
			int currentSum = 0;
			for(int j=i;j<n;j++){
				currentSum +=arr[j];
				if(currentSum > maxSum)
					maxSum = currentSum;
			}
		}
		return maxSum;
	}
	
	public static void main(String args[]){
		int arr[] = {1, -3, 4, -2, -1, 6};
		System.out.println(maximumContigousSum(arr));
		System.out.println(maxContigousSum(arr));
	}

}
