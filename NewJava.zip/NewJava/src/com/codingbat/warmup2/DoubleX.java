package com.codingbat.warmup2;

public class DoubleX {
	
	private static boolean doubleX(String str){
		boolean bool = false;
		int k = -1;
		for(int i=0;i<str.length();i++){
			if(str.charAt(i)=='x'){
				k = i;
				//System.out.println(k);
				break;
			}
		}
		System.out.println(k);
		System.out.println(str.charAt(k+1));
		if((k>=0) && (str.charAt(1)=='x')){
			bool = true;
		}
		return bool;
	}
	
	public static void main(String args[]){
		String str = "xx";
		boolean b = doubleX(str);
		System.out.println(b);
	}
	

}
