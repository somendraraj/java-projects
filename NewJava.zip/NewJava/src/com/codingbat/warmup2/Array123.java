package com.codingbat.warmup2;

public class Array123 {

	public static boolean array123(int[] nums) {
		int count = 0;
		int current = 0;
		for (int i = 0; i < nums.length-1; i++) {
			current = nums[i];
			for (int j = i + 1; j < nums.length; j++) {
				if (nums[j] == current) {
					count++;
				}
			}
			if (count >= 3) {
				return false;
			}
		}
		return true;
	}

	public static void main(String args[]) {
		int arr[] = {1, 1, 1, 2, 2,2, 1 };
		/*
		 * array123([1, 1, 2, 3, 1]); array123([1, 1, 2, 4, 1]) → false
		 * array123([1, 1, 2, 1, 2, 3])
		 */
		System.out.println(array123(arr));
	}

}
