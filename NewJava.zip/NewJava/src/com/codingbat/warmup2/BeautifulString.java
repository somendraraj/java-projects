package com.codingbat.warmup2;

public class BeautifulString {

	static long beautifulSubarrays(int[] arr, int m) {

		int n = arr.length;
		long count = 0;
		// Pick starting point
		for (int i = 0; i < n; i++) {
			// Pick ending point
			for (int j = i; j < n; j++) {
				int ar[] = new int[n];
				int x = 0;
				int c = 0;
				for (int k = i; k <= j; k++) {
					ar[x] = arr[k];
					x++;
					if ((arr[k] % 2) != 0) {
						c++;
					}
				}
				// int c = getOddCount(ar);
				if (c == m) {
					count++;
				}

			}
		}

		return count;
	}

	static int getOddCount(int[] arr) {
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			if ((arr[i] % 2) != 0) {
				count++;
			}
		}
		return count;
	}

	public static void main(String[] args) {
		int arr[] = { 1, 2, 3, 4 };
		long res = beautifulSubarrays(arr, 1);
		System.out.println(res);
	}

}
