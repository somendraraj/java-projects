package com.linkedin.interview;

public class FirstAndLastOccurence {
	
	static void printFirstAndLastOccur(int[] arr, int x){
		int first =-1,last = -1;
		for(int i=0;i<arr.length;i++){
			if(arr[i]==x){
				last = i;
				if(first == -1)
					first = last;
			}
		}
		System.out.println("First: "+first+" last: "+last);
	}
	
	public static void main(String args[]){
		int arr[] = {1, 3, 5, 5, 5, 5 ,67, 123, 125, 5} ;
		printFirstAndLastOccur(arr, 5);
		
		String ticket = "rcpb111234";
		System.out.println(ticket);
		System.out.println(ticket.CASE_INSENSITIVE_ORDER);
		System.out.println(ticket.toUpperCase());
	}

}
