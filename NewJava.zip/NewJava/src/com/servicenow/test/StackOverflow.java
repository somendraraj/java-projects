package com.servicenow.test;

public class StackOverflow {

	static byte recurse() {
		return recurse();
	}
	
	static int sum(int[] arr){
		int sum = 0;
		for(int a: arr){
			sum +=a;
		}
		return sum;
	}

	public static void main(String args[]) {
		//recurse();
		
		System.out.println(sum(new int[] {10,20,30,40}));
		
		String[] s = {"a","b","c"};
		Object[] ob = s;
		for(String st: s){
			System.out.println(st);
		}
		
		for(Object st: ob){
			System.out.println((String)st);
		}
		
	}

}
