package com.servicenow.test;

public class MaximumOnes {

	/**
	 * do the binary search op
	 * 
	 * @param mat
	 * @return
	 */
	static int getRowNumber(int[][] mat) {
		int maxVal = mat.length+1;
		int rowIndex = 0;
		for (int i = 0; i < mat.length; i++) {
			int m = binarySearch(mat[i]);
			System.out.println(m);
			if (m < maxVal){
				maxVal = m;
				rowIndex = i;
			}
				
		}
		return rowIndex;
	}

	static int binarySearch(int[] arr) {
		int low = 0;
		int high = arr.length - 1;
		while (low <= high) {
			int mid = low + (high - low) / 2;
			if ((mid == 0 || (arr[mid - 1] == 0)) && arr[mid] == 1)
				return mid;
			else if (arr[mid] == 0) {
				low = mid + 1;
			} else {
				high = mid - 1;
			}
		}
		return -1;
	}

	public static void main(String args[]) {
		int[][] mat = { { 0, 0, 1, 1 }, { 0, 0, 0, 1 }, { 0, 1, 1, 1 }, { 0, 0, 1, 1 }, { 1, 1, 1, 1 } };

		System.out.println(getRowNumber(mat));
	}

}
