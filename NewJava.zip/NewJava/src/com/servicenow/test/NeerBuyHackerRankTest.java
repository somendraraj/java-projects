package com.servicenow.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NeerBuyHackerRankTest {

	static void textQueries(List<String> sentences, List<String> queries) {

		List<Set<String>> list = new ArrayList<Set<String>>();

		for (String s : sentences) {
			Set<String> set = new HashSet<String>();
			String[] str = s.split(" ");
			for (String ss : str) {
				set.add(ss);
			}
			list.add(set);
		}
		for (String q : queries) {
			String[] s = q.split(" ");
			for (int i = 0; i < list.size(); i++) {
				Set<String> sentence = list.get(i);
				int count = 0;
				for (String ss : s) {
					if (sentence.contains(ss)) {
						count++;
					}
				}
				if (count == s.length)
					System.out.print(i + " ");
			}
			System.out.println();
		}

	}

	static int findBreakDuration(int n, int k, int t, List<Integer> start, List<Integer> finish) {
		
		int[] gap = new int[t];
		
		for(int i=0;i<n;i++){
			
		}
		
		for (int i = n - 1; i > 0; i++) {
			int si = start.get(i);
			int fi = finish.get(i);
			int fi1 = finish.get(i-1);
			int diff = si-fi1;
			if (diff>0 && k>0) {
				start.add(i, fi);
				finish.add(i, fi-diff);
				k--;
			}
		}
		return t-finish.get(n-1);
	}


	static void textQueries1(List<String> sentences, List<String> queries) {

		List<Set<String>> list = new ArrayList<Set<String>>();

		for (String s : sentences) {
			Set<String> set = new HashSet<String>();
			String[] str = s.split(" ");
			for (String ss : str) {
				set.add(ss);
			}
			list.add(set);
		}
		for (String q : queries) {
			String[] s = q.split(" ");
			boolean bool = false;
			for (int i = 0; i < list.size(); i++) {
				Set<String> sentence = list.get(i);
				int count = 0;
				for (String ss : s) {
					if (sentence.contains(ss)) {
						count++;
					} else {
						break;
					}
				}
				if (count == s.length) {
					System.out.print(i + " ");
					bool = true;
				}

			}
			if (!bool) {
				System.out.print(-1);
			}
			System.out.println();
		}

	}

}
