package com.servicenow.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

class Pair {
	private int start, finish;

	public Pair(int start, int finish) {
		this.start = start;
		this.finish = finish;
	}

	public int getFinish() {
		return finish;
	}

	public int getStart() {
		return start;
	}

	@Override
	public String toString() {
		return "{" + getStart() + ", " + getFinish() + "}";
	}
};

public class ProgrammingTest {

	static double findMinAvgWaitingTime(int n, int[] t, int[] l) {
		List<Pair> orders = new ArrayList<>();
		
		for (int i = 0; i < n; i++) {
			orders.add(new Pair(t[i], l[i]));
			
		}
		// System.out.println(orders);
		// Sort the activities according to their waiting time
		Collections.sort(orders, (a, b) -> a.getFinish() - b.getFinish());

		System.out.println(orders);

		double wt = orders.get(0).getFinish();// -orders.get(0).getStart();
		double maxWait = (double) wt;
		double min = orders.get(0).getStart();
		for (int i = 1; i < n; i++) {
			
			Pair p = orders.get(i);
			double start = (double) p.getStart();
			double finish = (double) p.getFinish();
			
			if(min<start){
				min = start;
			}
			
			wt = wt + finish;

			if ((wt - start) < 0) {
				maxWait += (double) (wt);
			} else {
				maxWait += (double) (wt -start);
			}

		}

		return (maxWait )/ n;
	}

	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();
		int[] t = new int[n];
		int[] l = new int[n];
		for (int i = 0; i < n; i++) {
			t[i] = sc.nextInt();
			l[i] = sc.nextInt();
		}

		double res = findMinAvgWaitingTime(n, t, l);
		System.out.println(res);
	}

}
