package com;

public class FibonacciSeries {
	
	/*recursion method timeComplexity O(2^n)*/
	/*0, 1, 1, 2, 3, 5, 8 */
	static int nthFibonacci(int n){
		if(n == 0){return 0;}
		if(n == 1){return 1;}
		return nthFibonacci(n-1)+nthFibonacci(n-2);
	}
	
	/*Buttom up Dynamic Programming 
	 * Time Complexity O(n)
	 * Space Complexity O(n)*/
	static int nthFib(int n){
		int Fib[] = new int[n+1];
		Fib[0] = 0;
		Fib[1] = 1;
		for(int i=2; i<=n;i++){
			Fib[i] = Fib[i-1]+Fib[i-2];
		}
		return Fib[n];
	}
	
	/*Top dpown Dynamic Programming
	 * Time Complexity O(n)
	 * Space Complexity O(n)*/
	static int nthFib1(int n){
		int Fib[] = new int[n+1];
		if(n== 1)
			return 1;
		if(n == 2)
			return 1;
		if(Fib[0] != 0) return Fib[n];
		return Fib[n] = nthFib1(n-1) + nthFib1(n-2);
	}
	
	/*We need previous two nums for next nums
	 * Time complexity = O(n)
	 * Space complexity = O(1)*/
	static int getFibonacci(int n){
		int first =0, second = 1, sum =0;
		for(int i=1;i<n;i++){
			sum = first + second;
			first = second;
			second = sum;
		}
		
		return sum;
	}
	
	public static void main(String args[]){
		int n = 6;
		System.out.println(nthFibonacci(n));
		System.out.println(nthFib(n));
		System.out.println(nthFib1(n));
		System.out.println(getFibonacci(n));
	}

}
