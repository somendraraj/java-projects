package com.tree;



class Values{
	int min, max;
}


public class PrintVerticalBinaryTree {
	
	static class Node{
		int data;
		Node left, right;
		public Node(int data){
			this.data = data;
			this.left = this.right = null;
		}
	}

	
	Node root;
	Values val = new Values();
	
	void findMinMax(Node node, Values min, Values max, int hd){
		
		//Base case
		if(node==null)
			return;
		
		//Update min max
		if(hd< min.min)
			min.min=hd;
		if(hd>max.max)
			max.max=hd;
		
		//recur
		findMinMax(node.left, min, max,  hd-1);
		findMinMax(node.right, min, max, hd+1);
	}
	
	//Utility function to print vertical line
	void printVerticalLine(Node node, int line, int hd){
		
		//Base case
		if(node == null)
			return;
		if(hd==line){
			System.out.print(node.data+" ");
		}
		//Recur for left and right subtree
		printVerticalLine(node.left, line, hd-1);
		printVerticalLine(node.right, line, hd+1);
	}
	
	//vertical order print
	void printVerticalOrder(Node node){
		// Find min and max distances with resepect to root
        findMinMax(node, val, val, 0);
  
        // Iterate through all possible vertical lines starting
        // from the leftmost line and print nodes line by line
        for (int line_no = val.min; line_no <= val.max; line_no++) 
        {
            printVerticalLine(node, line_no, 0);
            System.out.println("");
        }
	}
	
	//Main function to run program
	public static void main(String args[]){
		PrintVerticalBinaryTree tree = new PrintVerticalBinaryTree();
		tree.root = new Node(1);
		tree.root.left=new Node(2);
		tree.root.right=new Node(3);
		tree.root.left.left=new Node(4);
		tree.root.left.right=new Node(5);
		tree.root.right.left=new Node(6);
		tree.root.right.right=new Node(7);
		tree.root.right.left.right=new Node(8);
		tree.root.right.right.right=new Node(9);
		
		System.out.println("Print Vertical order tree");
		tree.printVerticalOrder(tree.root);
		
	}

}
