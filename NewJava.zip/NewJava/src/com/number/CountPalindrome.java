package com.number;

public class CountPalindrome {
	
	public static int count(String s){
		int len = s.length();
		int p0[] = new int[len+1];
		int p1[] = new int[len];
		for(int i=1;i<len;i++){
			for(int j=0;j<len;j++){
				p0[i] = p1[i];
				if (s.charAt(i)==s.charAt(i+1))
					p1[i] +=p1[i+1]+1;
				else
					p1[i] +=p1[i+1]-p0[i+1];
			}
		}
		return p1[0]+1;
	}
	
	public static int countP(String s){
		int pow = (int ) Math.pow(2, s.length());
			  return  pow- count(s);
	}
	
	// Driver Method
	public static void main(String[] args)
	{
		String str = "wowpurerocks";
		System.out.println(count(str));
	}

}

