package com.number;

import java.util.Arrays;

public class SieveOfEratostheness {
	
	
	void sieveOfEratosthenes(int[] s, int n){
		
		//Create a array with boolean type and size n+1, and initializes to false
		boolean[] prime = new boolean[n+1];
		Arrays.fill(prime, false);
		
	}

}
