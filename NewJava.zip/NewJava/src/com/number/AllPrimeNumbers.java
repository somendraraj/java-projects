package com.number;

import java.util.ArrayList;
import java.util.List;

public class AllPrimeNumbers {

	static List<Integer> countPrimes(int beg, int end) {
		int flag = 0;
		List<Integer> primes = new ArrayList<Integer>();
		for (int i = beg; i <= end; i++) {
			for (int j = 2; j < i; j++) {
				if (i % j == 0) {
					flag = 0;
					break;
				} else {
					flag = 1;
				}
			}
			if (flag == 1) {
				primes.add(i);
			}
		}
		return primes;
	}

	public static void main(String[] args) {
		List<Integer> primes = countPrimes(7, 7);
		System.out.println(primes);
	}

}
