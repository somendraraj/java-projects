package com.number;

import java.util.Scanner;

public class NumberToWord {

	/* The first string is not used, it is to make array indexing simple */
	private static String single_digits[] = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
			"nine" };

	/* The first string is not used, it is to make array indexing simple */
	private static String two_digits[] = { "", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",
			"seventeen", "eighteen", "nineteen" };

	/*
	 * The first two string are not used, they are to make array indexing simple
	 */
	private static String tens_multiple[] = { "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy",
			"eighty", "ninety" };

	private static String tens_power[] = { "hundred", "thousand", "million" };

	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);
		String number = sc.nextLine();
		printWord(number);

	}

	static void printWord(String n) {
		int len = n.length();
		switch (len) {
		case 1:
			printSingleDigit(n);
			break;
		case 2:
			printTwoDigit(n);
			break;
		case 3:
			printThreeDigit(n);
			break;
		case 4:
			printSingleDigit(n);
			break;
		case 5:
			printSingleDigit(n);
			break;
		case 6:
			printSingleDigit(n);
			break;
		}

	}

	static void printSingleDigit(String n) {
		int dig = -1;
		if (n.length() < 2 && n.length() > 0) {
			dig = Integer.parseInt(n);
			System.out.println(single_digits[dig]);
		}
	}

	static void printTwoDigit(String n) {
		
	}

	static void printThreeDigit(String n) {

	}

	static void printFourDigit(String n) {

	}

}
