package com.number;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class GenerateRandomNumber {
	
	private static void write() {
		long start = System.currentTimeMillis();
		
		File file = new File("abc.txt");
		FileWriter fw = null;
		try {
			fw = new FileWriter(file);

			while (true) {
				fw.write(String.valueOf(randamNumber()));
				long second = System.currentTimeMillis();
				if(second-start>=100){
					System.out.println("end!");
					System.exit(0);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fw != null) {
					fw.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	public static long randamNumber() {
		long number = (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
		return number;
	}

	public static void main(String args[]) {
		System.out.println("start!");
		write();
		
	}

}
