package com.number;

import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class LeaderBoard {
	
	
	public static void main(String[] args) {
        /*Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] scores = new int[n];
        for(int scores_i=0; scores_i < n; scores_i++){
            scores[scores_i] = in.nextInt();
        }
        int m = in.nextInt();
        int[] alice = new int[m];
        for(int alice_i=0; alice_i < m; alice_i++){
            alice[alice_i] = in.nextInt();
        }
        
        //leaderboard code
        int value = 0;
        int arr[] = new int[m+n];
        Map<Integer, Integer> map = new TreeMap<Integer, Integer>();
        for(int i=0;i<n;i++){
        	arr[i] = scores[i];
        	if(!map.containsKey(scores[i])){
        		map.put(scores[i], ++value);
        	}else{
        		map.put(scores[i], value);
        	}
        	
        }
        System.out.println(map);
        for(int i=0;i<m;i++){
        	if(!map.containsKey(alice[i])){
        		map.put(alice[i], ++value);
        	}else{
        		map.put(alice[i], value);
        	}
        	System.out.println(map.get(alice[i]));
        }
       
        System.out.println(map);*/
        
        int seconds = 5;
        System.out.println(seconds*1000);
        
        char x = ' ';//seconds*1000;
        
        
        
    }

}
