package com.number;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.google.common.collect.Multiset.Entry;

public class AddCountryCode {
	

    private static String addCountryCode(String mobileNos){
    	String[] mobile = mobileNos.split(",");
    	StringBuilder sb = new StringBuilder();
    	for(String m: mobile){
    		if(m.length()==10 && !(m.startsWith("+91"))){
    			sb.append("+91");
    			sb.append(m+",");
    		}else{
    			sb.append(m+",");
    		}
    	}
    	return sb.substring(0, sb.length()-1).toString();
    }
    
	
	public static void main(String args[]){
		String str = "7021063163,9087654321,9089620677,+917021007229";
		String result = addCountryCode(str);
		System.out.println(result);
	
		System.out.println(result);
		
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		map.put(1, 1);
		map.put(2, 2);
		map.put(3, 3);
		map.forEach((k, v)->System.out.println("key: "+k+" value: "+v));
		
		map.entrySet().stream()
		.filter(x-> "3".equals(x.getValue().toString()))
		.forEach(x->System.out.println("key: "+x.getKey()+" value: "+x.getValue()));
		
		
		String date = "15-07-2018 00:12:59";
		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FMT_2);
		String d = formatter.format(new Date());
		System.out.println( checkDate(new Date()));
		
		
	}
	
	
	 /**
     * method is used to check date form richmedia analysis report count
     * @param accessDate
     * @return
     */
	
	static String DATE_FMT_2 = "dd-MM-yyyy";
    public static int checkDate(Date accessDate) {
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_FMT_2);
        String today = formatter.format(new Date());
        String dbDate = formatter.format(accessDate);
        return today.compareTo(dbDate);
    }

}
