package com.number;

import java.util.Scanner;

public class FactorSum {
	
	static int getSum(int n){
		int sum = 0;
		for(int i=1;i<=n;i++){
			if( (n%i) == 0){
				sum +=i;
			}
		}
		return sum;
	}
	
	//optimization code
	static int sumOfFactors(int n){
		int res = 1;
		
		//Traversing through all the prime factors
		for(int i=2;i<=Math.sqrt(n);i++){
			
			int count = 0, currSum = 1, currTerm = 1;
			while(n%i == 0){
				count++;
				n = n/i;
				currTerm *=i;
				currSum +=currTerm;
			}
			res *=currSum;
		}
		
		if(n>2)
			res *=(1+n);
		return res;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		System.out.println(getSum(n));
		System.out.println(sumOfFactors(n));

	}

}
