package com.number;

import java.util.Arrays;

public class SorocoIncreasingOrder {

	private static void generateSequence(int n) {
		int arr[] = { 4, 4, 2, 2, 5, 5, 3, 6, 7, 8, 8, 6, 7 };
		Arrays.sort(arr);
		for (int i = 0; i < arr.length - 1; i++) {
			if (arr[i] == arr[i + 1]) {
				i++;
			} else {
				System.out.println(arr[i]);
			}
		}

		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					arr[i] = arr[i] - arr[i];
					arr[j] = arr[j] - arr[j];
				}
			}
			if (arr[i] != 0) {
				System.out.println(arr[i]);
			}

		}
		int arr1[] = { 4, 4, 2, 2, 5, 5, 3, 6, 7, 8, 8, 6, 7 };
		int res = arr1[0];
		for(int i=1;i<arr1.length;i++){
			res ^=arr1[i];
		}
		System.out.println(res);

	}

	public static void main(String args[]) {
		int n = 2;
		generateSequence(n);
	
	}

}
