package com.number;

public class NumberGroup {
	
	
	
	public static void main(String args[]){
		
		
		/*long[] number = new long[1000000];
		int j = 0;
		for(int i=1;i<=2000000;i++){
			System.out.println(i);
			if( (i%2) != 0){
				number[j] = i;j++;
			}
			//System.out.println(number[j]);
		}*/
		System.out.println("abd");
		int i =0;
		for(;;){
			for( i=0;i<=5;i++){
				System.out.println(i);
			}
			if(i>5)
				break;
		}
		
		
	}

}
