package com;

public class PrintOuter {

	static void printOuterLoop(int arr[][], int n){
		for(int i=0;i<1;i++){
			for(int j=0;j<n;j++){
				System.out.print(arr[0][j]+" ");

			}
		}
		for(int i=1;i<n;i++){
			for(int j=n-1;j>n-2;j--){
				System.out.print(arr[i][j]+" ");

			}
		}
		for(int i=n-1;i<n;i++){
			for(int j=n-2;j>=0;j--){
				System.out.print(arr[i][j]+" ");

			}
		}
		for(int i=n-2;i>=1;i--){
			for(int j=0;j<1;j++){
				System.out.print(arr[i][j]+" ");

			}
		}
		
		System.out.println("\n     ***Method 2*****");
		for(int j=0;j<n;j++){
			System.out.print(arr[0][j]+" ");
		}
		for(int i=1;i<n;i++){
			System.out.print(arr[i][n-1]+" ");
		}
		for(int j=n-2;j>=0;j--){
			System.out.print(arr[n-1][j]+" ");
		}
		for(int i=n-2;i>=1;i--){
			System.out.print(arr[i][0]+" ");
		}
		
		System.out.println("\n      ****Method 3*****");
		for(int i=0;i<n-2;i++){
			for(int j=0;j<n;j++){
				if(i==0){
					System.out.print(arr[i][j]+" ");
				}else{
					
				}
			}
			System.out.print(arr[i+1][0]+" "+arr[i+1][n-1]+" ");
		}
		for(int j=0;j<n;j++){
			System.out.print(" "+arr[n-1][j]);
		}
			
	}
		
	public static void main(String args[]){
		int arr[][] = {{1,2,3,4},
					   {5,6,7,8},
					   {9,10,11,12},
					   {13,14,15,16}};
		
		int n = arr.length;
		printOuterLoop(arr, n);
	}

}
