package com.test.thread;

public interface ActionListener {

	void actionPerformed(Object data);
}
