package com.test.thread;

import java.util.concurrent.Callable;

public class Worker implements Callable<Long> {

	private long num;

	public Worker(long i) {
		this.num = i;
	}

	public Long call() {
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this.num;

	}
}
