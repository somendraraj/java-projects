package com.test.thread;

public class WorkerThread implements Runnable {
	
	private static int i;
	
	@Override
	public void run(){
		synchronized (this){
			System.out.println("thread " + i++);
		}
	}
	
	
	public static int getI() {
		return i;
	}
	
	
	public static void setI(int i) {
		WorkerThread.i = i;
	}
}