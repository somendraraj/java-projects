package com.test.thread;

public class NthFibonacci {
	
	
	public static void print(){
		long start = System.currentTimeMillis();
		int sum = 0;
		for(int i=0;i<40000000;i++){
			sum = sum +1;
		}
		System.out.print(sum +" ");
		System.out.println(System.currentTimeMillis()-start);
		start = System.currentTimeMillis();
		int sum1 = 0;
		for(int i=0;i<40000000;i++){
			sum1 +=1;
		}
		
		System.out.print(sum1 +" ");
		System.out.println(System.currentTimeMillis()-start);
		start = System.currentTimeMillis();
		
		int sum2 = 0;
		for(int i=0;i<40000000;i++){
			sum2++;
		}
		
		System.out.print(sum2 +" ");
		System.out.println(System.currentTimeMillis()-start);
		start = System.currentTimeMillis();
		
		int sum3 = 0;
		for(int i=0;i<40000000;i++){
			sum3 = (-(~sum3));
		}
		
		System.out.print(sum3 +" ");
		System.out.println(System.currentTimeMillis()-start);
		
	}

	public static void main(String args[]) {
		int n = 5;
		int a = 0;
		int b = 1;
		int c = 0;
		if (n < 1) {
			System.out.println(n);
		} else {
			for (int i = 2; i <= n; i++) {
				a = b;
				b = c;
				c = a + b;
			}
		}

		System.out.println(b);
		
		print();

	}

}
