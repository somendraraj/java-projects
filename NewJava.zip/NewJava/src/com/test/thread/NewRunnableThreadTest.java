package com.test.thread;

public class NewRunnableThreadTest {

	public static void main(String args[]) {
		NewRunnable nr = new NewRunnable();
		Thread t1 = new Thread(nr);
		Thread t2 = new Thread(nr);
		Thread t3 = new Thread(nr);
		t1.setName(" Thread One ");
		t2.setName(" Thread Two ");
		t3.setName(" Thread Three ");
		
		
		try {
			t1.start();
			t1.join();
			t2.start();
			t2.join();
			t3.start();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
