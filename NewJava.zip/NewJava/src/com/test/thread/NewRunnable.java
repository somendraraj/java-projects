package com.test.thread;

public class NewRunnable implements Runnable {
	
	@Override
	public void run(){
		for(int i=1;i<=3;i++){
			System.out.println("Run by "+Thread.currentThread().getName()+" "+i);
		}
	}
}
