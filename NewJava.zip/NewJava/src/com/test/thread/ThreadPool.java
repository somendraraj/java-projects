package com.test.thread;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;

public class ThreadPool extends Thread {
	
	private AtomicBoolean execute;
	private ConcurrentLinkedQueue<Runnable> runnable;
	
	public ThreadPool(String name, AtomicBoolean execute, ConcurrentLinkedQueue<Runnable> runnable){
		super(name);
		this.execute=execute;
		this.runnable=runnable;
	}
	

}
