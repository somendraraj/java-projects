package com.test.thread;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

public class ConcurrentThread extends Thread {
	
	private static ExecutorService excutor = Executors.newFixedThreadPool(10);
	
	static int i = 0;

	public static void threadStart() throws InterruptedException {
		
		Thread t1 = new Thread() {
			@Override
			public void run() {
				add();
			}
		};
		Thread t2 = new Thread() {
			@Override
			public void run() {
				add();
			}
		};
		t1.start();
		t1.join();
		t2.start();
		t2.join();
		
		System.out.println(count);
	}

	
	static ReentrantLock lock = new ReentrantLock();
	
	static int count = 0;
	
	public static void add(){
		lock.lock();
		try{
			count++;
		}finally{
			lock.unlock();
		}
	}
	
	public static void main(String args[]) throws InterruptedException {
		
		new WorkerThread().setI(1);
		//excutor.execute(new WorkerThread());
		for(int i=0;i<=10;i++){
			threadStart();
		}
		
		

	}

}
