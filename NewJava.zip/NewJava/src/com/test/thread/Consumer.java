package com.test.thread;

import java.util.concurrent.BlockingQueue;

public class Consumer implements Runnable{
	
	protected BlockingQueue queue = null;
	
	Consumer(BlockingQueue queue){
		this.queue = queue;
	}
	
	@Override
	public void run(){
		try{
			int sum = 0;
			while(!queue.isEmpty()){
				sum = sum + (int) queue.poll();
				System.out.println("inside " +sum);
			}
			System.out.println("Queue Size "+queue.size());
			System.out.println("Outside "+sum);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
