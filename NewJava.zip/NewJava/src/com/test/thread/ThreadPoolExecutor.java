package com.test.thread;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ThreadPoolExecutor {

	public static long method() {
		ExecutorService executor = Executors.newFixedThreadPool(10);
		
		Long countL = 0L;
		List<Callable<Long>> callables = Arrays.asList(
				() -> fetchResult(0), 
				() -> fetchResult(1),
				() -> fetchResult(2),
				() -> fetchResult(3), 
				() -> fetchResult(4), 
				() -> fetchResult(5), 
				() -> fetchResult(6),
				() -> fetchResult(7), 
				() -> fetchResult(8), 
				() -> fetchResult(9));
		try {
			executor.invokeAll(callables).stream().map(future -> {
				try {
					return future.get();
				} catch (Exception e) {
					throw new IllegalStateException(e);
				}
			}).forEach(System.out::println);
			
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}finally{
			executor.shutdown();
		}

		return countL;
	}

	private static long fetchResult(int i) {
		try {
			if (i % 2 == 0) {
				Thread.sleep(1000);
			} else {
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 2 * i;
	}
	
	
	

	public static void main(String[] args) {

		System.out.println(method());

	}

}
