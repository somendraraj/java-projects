package com.test.thread;

import java.util.Random;
import java.util.concurrent.BlockingQueue;

public class Producer implements Runnable {

	protected BlockingQueue queue = null;

	Producer(BlockingQueue queue) {
		this.queue = queue;
	}

	@Override
	public void run() {
		try {
			while (queue.size() <= 100) {
				queue.put(generateNumber());
				Thread.sleep(10);
			}

			System.out.println("Queue Size "+queue.size());
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}

	int generateNumber() {
		Random rand = new Random();
		return rand.nextInt(10);
	}

}
