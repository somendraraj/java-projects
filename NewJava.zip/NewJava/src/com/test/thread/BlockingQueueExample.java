package com.test.thread;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class BlockingQueueExample {
	
	
	public static void main(String args[]) throws Exception{
		BlockingQueue<Integer> queue = new ArrayBlockingQueue<>(1024);
		
		Producer producer = new Producer(queue);
		Consumer consumer = new Consumer(queue);
		
		Thread t1 = new Thread(producer);
		Thread t2 = new Thread(consumer);
		
		t1.start();
		t1.join();
		t2.start();
	
		
		Thread.sleep(1000);
	}

}
