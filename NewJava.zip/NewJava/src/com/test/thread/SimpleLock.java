package com.test.thread;

public class SimpleLock implements Runnable {
	
	private int count = 0;
	
	public int inc(){
		synchronized(this){
			return ++count;
		}
	}
	
	
	public static void main(String args[]){
		SimpleLock obj = new SimpleLock();
		
		obj.inc();
	}

	@Override
	public void run() {
		
		
	}

}
