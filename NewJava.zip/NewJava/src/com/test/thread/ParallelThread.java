package com.test.thread;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ParallelThread {

	private volatile Long res = 0L;


	public Long method() throws InterruptedException, ExecutionException {
		ExecutorService executor = Executors.newFixedThreadPool(10);
		System.out.println(new Date().getSeconds());
		List<Future<Long>> fut = new ArrayList<>();
		/*for (int i = 0; i <= 9; i++) {
			fut.add(executor.submit(new Worker(i)));
		}
		
		for (Future<Long> ff : fut) {
			res += ff.get();
		}*/
		//executor.shutdown();
		//executor.awaitTermination(10, TimeUnit.SECONDS);
		
		List<Future<Long>> list = new ArrayList<>();
		for(int i=0;i<10;i++){
			final int table = i;
			Future<Long> future = executor.submit(new Callable<Long>() {
				public Long call() throws Exception {
					return fetchResult(table);
				}
			});
			list.add(future);
		}
		long count = 0;
		for(Future<Long> f: list){
			count+=f.get();
		}
		
		System.out.println("FINAL : "+ count);
		System.out.println(new Date().getSeconds());
		return count;
		
		

	}


	public static void main(String[] args) throws InterruptedException, ExecutionException {

		ParallelThread t = new ParallelThread();
		Long x = t.method();
		System.out.println(x);
	}
	
	
	private static long fetchResult(int i) throws InterruptedException{
		if(i%2==0){
			Thread.sleep(2000);
		}
		return 2*i;
	}

}
