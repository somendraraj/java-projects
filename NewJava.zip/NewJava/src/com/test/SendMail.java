package com.test;

public class SendMail {
	
	
	
	
	public static void main(String args[]){
		
	}

}
