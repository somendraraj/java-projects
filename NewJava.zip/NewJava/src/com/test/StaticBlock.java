package com.test;

public class StaticBlock {
	
	/**
	 * executes at class loading time
	 */
	static{
		System.out.println("print befor main method!!!");
	}
	
	public static void main(String args[]){
		System.out.println("Main Method");
	}
}
