package com.test.string;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidMobile {
	
	static final String regex = "^([0-9]{10})|([0-9a-zA-Z]{13})$";

	public static boolean checkMobile(String mobile) {
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(mobile);
		return m.matches();
	}
	
	
	public static void main(String args[]){
		
		
		String mobile = "9089620677";
		String mobile1 = "089620677";
		String mobile2 = "+919089620677";
		String mobile3 = "+919089620677";
		String mobile4 = "0919089E20677";
		String mobile5 = "09190896206770";
		System.out.println(checkMobile(mobile));
		System.out.println(checkMobile(mobile1));
		System.out.println(checkMobile(mobile2));
		System.out.println(checkMobile(mobile3));
		System.out.println(checkMobile(mobile4));
		System.out.println(checkMobile(mobile5));
		
		System.out.println(mobile2.substring(3));
		System.out.println(mobile2.substring(0,3));
		System.out.println(mobile2.substring(3));
	}

}
