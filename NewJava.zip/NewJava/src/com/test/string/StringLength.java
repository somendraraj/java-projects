package com.test.string;

public class StringLength {
	
	public static void main(String args[]){
		String str = "Somendra Ril Corp:Hi ";

	}

}
