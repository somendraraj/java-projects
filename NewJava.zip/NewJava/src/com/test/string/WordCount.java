package com.test.string;

public class WordCount {
	
	
	static int countWord(String str, String word){
		String[] words = str.split(" ");
		int count = 0;
		for(int i=0;i<words.length;i++){
			if(word.equals(words[i])){
				count++;
			}
		}
		return count;
	}
	
	public static void main(String args[]){
		String str = new String();
		str = "Asked me to tell about the app I am working on and asked me about my role in that and then asked me to explain a specific feature which I implemented.";
		String word = "me";
		System.out.println(countWord(str, word));
		
	}

}
