package com.test.string;

import java.util.ArrayList;
import java.util.List;

public class NullCheck {
	
	//@SuppressWarnings("unused")
	public static void main(String args[]){
		String str = "";
		if(str != null && str.isEmpty()){
			System.out.println("Empty");
		}else{
			System.out.println("Null");
		}
		
		List<String > list = new ArrayList<String>();
		list.contains("a");
		
	}

}
