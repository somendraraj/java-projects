package com.test.string;

public class StartsWith {

	public static void main(String[] args) {
		String str = "https://www.google.com";
		String str1 = "http://www.google.com/";
		
		if(str.startsWith("https://")){
			System.out.println(str);
		}
		if(str1.startsWith("https://")){
			System.out.println(str1);
		}
		
		
		long start = 1000000000;
		long end = 9999999999l;
		System.out.println(end-start);
		
	}
}
