package com.test.string;

import java.util.UUID;

import Introduction.RandomNumber;

public class SubString {

	/*
	 * {departmentKey=2, image=client_2040, lng=72986015, mobile=+919089620677,
	 * categoryKey=23, description=Description testing,
	 * location=Location:Akashganga Rd, Kranti Nagar, Thane West, Thane,
	 * Maharashtra 400601, India, subcategoryKey=10, landmark=Thane,
	 * lat=19202211}
	 */

	public static void main(String args[]) {

		String lat = "19202211";
		String lat1 = lat.substring(0, 2) + "." + lat.substring(2, 6);
		System.out.println(lat1);

		long time = System.currentTimeMillis();

		System.out.println(time);

		String str = "INS2";

		long l = 1234567890;

		String mobile = "9089620677";
		String mobile1 = "9089620677";

		String m = mobile.substring(mobile.length() - 10);
		System.out.println(m);

		System.out.println(str.substring(3, 4));

		String id = UUID.randomUUID().toString();
		System.out.println(id);

	}

}
