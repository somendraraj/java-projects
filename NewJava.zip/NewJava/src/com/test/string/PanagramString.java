package com.test.string;

import java.util.Scanner;

public class PanagramString {

	private static String isPanagram(String str) {
		str = str.replace(" ", "").trim().toLowerCase();
		System.out.println(str);
		char[] ch = str.toCharArray();
		int [] arr = new int[26];
		for (int i = 0; i < str.length(); i++) {
			arr[ch[i]-'a'] = 1;
		}
		for(int i=0;i<26;i++){
			//System.out.println(i+" :"+arr[i]);
			if(arr[i]!=1)
				return "not panagram";
		}
		return "pangram";
	}

	public static void main(String args[]) throws java.lang.Exception {

		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		String result = isPanagram(str);
		System.out.println(result);

	}

}
