package com.test.string;

public class AnagramSearchSubstring {
	
	
	public static final int MAX_SIZE = 256;
	
	private static boolean compare(char[] ch1, char[] ch2){
		for(int i=0;i<ch1.length;i++){
			if(ch1[i]!=ch2[i])
				return false;
		}
		return true;
	}

	public static void main(String[] args) {
		
		String text = "abdc";
		String pat = "abcd";
		char[]  ch1 = new char[MAX_SIZE];
		ch1 = text.toCharArray();
		
		System.out.println(ch1.length);
		char[] ch2 = new char[MAX_SIZE];
		ch2 = pat.toCharArray();
		
		System.out.println(compare(ch1, ch2));
	}

}
