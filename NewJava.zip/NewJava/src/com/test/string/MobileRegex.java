package com.test.string;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MobileRegex {
	
	public static boolean checkMobile(String mb){
		Pattern p = Pattern.compile("^([0-9]{10})|\\+([0-9]{12})$");
		Matcher m = p.matcher(mb);  
		return m.matches();  
	}
	
	public static void main(String rgas[]){
		
		
		String mobile = "9089620677";
		String mobile1 = "+919089620677";
		String mobile2 = "+9190896206778";
		
		String mobile3 = "908962067";
		
		String mobile4 = "90896206790";
		
	
			
		System.out.println(checkMobile(mobile));
		
		System.out.println(checkMobile(mobile1));
		
		System.out.println(checkMobile(mobile2));
		
		System.out.println(checkMobile(mobile3));
		
		System.out.println(checkMobile(mobile4));
		
		
	}

}
