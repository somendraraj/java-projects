package com.test.string;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Fintelix {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String c = sc.nextLine();
		
		char ch = c.charAt(0);
		
		System.out.println(ch);
		
		System.out.println("This is ram");
		
		Map<Character, String> map = new HashMap<Character, String>();
		
		

	}

}
