package com.test.string;

public class PaternSearchSetOne {
	
	/**
	 * 
	 * Naive solution using two loop
	 * 
	 * @param text
	 * @param pat
	 */
	
	private static void search(String text, String pat){
		int n = text.length();
		int m = pat.length();
		
		char[] ct = text.toCharArray();
		char[] pt = pat.toCharArray();
		
		for(int i=0;i<=n-m;i++){
			int j;
			for(j=0;j<m;j++){
				if(ct[i+j]!=pt[j]){
					break;
				}
				
			}
			if(j==m){
				System.out.println("found at "+i);
			}
		}
	}
	
	public static void main(String args[]){
		String text = "AAAAA AAAAAA AAAAAA";
		String pat = "AAAAA";
		
		search(text, pat);
	}

}
