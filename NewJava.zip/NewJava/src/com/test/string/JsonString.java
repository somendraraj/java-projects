package com.test.string;

import org.json.JSONObject;

public class JsonString {

	public static void main(String args[]){
		
		JSONObject json = new JSONObject();
		JSONObject msg = new JSONObject();
		msg.put("Content", "Hello World!");
		json.put("touser", "1234567890");
		json.put("text", msg);
		json.put("msgtype", "1234567890");
		json.put("makeAutofollow", false);
		
		System.out.println(json.toString());
		
		if(json.toString().contains("makeAutofollow")){
			System.out.println("makeautofollow");
			boolean makeAutofollow = json.getBoolean("makeAutofollow");
			System.out.println(makeAutofollow);
		}else{
			System.out.println("makeautofollow1");
		}
		
	}
}
