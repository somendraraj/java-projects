package com.test.string;

import org.json.JSONObject;

public class TrimString {

	
	
	public static void main(String args[]){
		String str = "";
		for(int i=0;i<10;i++){
			str+=" ";
		}
		str=str+"123";
		System.out.println(str.length());
		System.out.println(str.trim().length());
		System.out.println(str.length());
		
		
		JSONObject js = new JSONObject();
		js.put("mobile", 1234);
		
		//String url = "https://betapp.rsocial.net:8080/group1/M00/00/4B/CoxiJlnbbayAJ847AAAOmczBiqA70.html";
		String url = "https://betapp.rsocial.net:8080/group1/M00/00/56/CoxiJlomM3CAdg9cAAATvnMVUh861.html?mid=48266";
		//https://betapp.rsocial.net:8080/group1/M00/00/56/CoxiJlomM3CAdg9cAAATvnMVUh861.html
		url = url.substring(0, (url.indexOf('?')==-1)?url.length():url.indexOf('?'));
		System.out.println(url);
			
	}
}
