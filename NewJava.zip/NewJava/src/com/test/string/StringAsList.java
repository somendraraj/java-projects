package com.test.string;

import java.util.Arrays;
import java.util.List;

public class StringAsList {
	
	public static void main(String args[]){
		
		String str = "A, B, C, D, E, F"; 
		
		List<String> list = Arrays.asList(str.split("\\s*,\\s*"));
		
		System.out.println(list);
		
	}

}
