package com.test.string;

public class StringYesOrNo {

	public static void main(String rga[]) {
		System.out.println(isContentYes("Y"));
	}

	private static boolean isContentYes(String content) {
		return (content.equalsIgnoreCase("YES") || content.equalsIgnoreCase("Y")) ? true : false;
	}

}
