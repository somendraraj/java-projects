package com.test;

public class Loop {

	public static void main(String args[]){
		int arr[] = new int[100];
		for(int i=0;i<100;i++){
			arr[i] = 1;
		}
		int i = 1;
		for(Integer k : arr){
			if(i++>10){
				break;
			}
			System.out.println(i);
		}
	}
}
