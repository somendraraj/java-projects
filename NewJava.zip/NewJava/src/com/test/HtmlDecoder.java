package com.test;

import org.apache.commons.lang3.StringEscapeUtils;

public class HtmlDecoder {
	
	public static void main(String args[]){
		
		String str = "139&#x2F;25, 7th Main Rd, Krishna Reddy Layout, Amarjyoti Layout, Domlur, Bengaluru, Karnataka 560071, India";
		
		String afterDecoding = StringEscapeUtils.unescapeHtml4(str);
		System.out.println(afterDecoding);
		
		
	}

}
