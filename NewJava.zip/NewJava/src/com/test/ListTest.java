package com.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ListTest {
	
	
	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		String content = sc.nextLine();
		
		List<String> AnsweredList = new ArrayList<String>();
		
		if( ((content.equalsIgnoreCase("A")) || (content.equalsIgnoreCase("B"))
				|| (content.equalsIgnoreCase("C")) || (content.equalsIgnoreCase("D")))){
			AnsweredList.add(content);
		}
		System.out.println(AnsweredList);
		
		
		
		
	}

}
