package com.test.squad;

import java.util.LinkedList;
import java.util.Queue;

public class Sulution {
	
	public static void main(String args[]){
		Queue<Integer> queue = new LinkedList<>();
		queue.add(1);
		queue.add(2);
		queue.add(3);
		System.out.println(queue);
		while(!queue.isEmpty()){
			int val = queue.peek();
			queue.remove();
			System.out.println(val);
		}
		System.out.println(queue);
	}

}
