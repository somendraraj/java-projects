package com.test.browserstack;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

class Pair{
	int a;
	int b;
	Pair(int a, int b){
		this.a = a;
		this.b = b;
	}
}

public class RecyclePairSum {

	/*
	 * Complete the uniqueRecycledPairs function below.
	 */
	static long uniqueRecycledPairs(int[] arr) {
		
		Set<Integer> set = new HashSet<Integer>();
		for (Integer i : arr) {
			set.add(i);
		}

		Iterator<Integer> iter = set.iterator();
		int k = 0;
		int[] arr1 = new int[set.size()];
		
		while (iter.hasNext()) {
			arr1[k++] = iter.next();
		}
		//System.out.println(set);
		

		int count = 0;
		String str1 = "";
		String str2 = "";
		for(int i=0;i<arr1.length-1;i++){
			for(int j=i+1;j<arr1.length;j++){
				str1 = String.valueOf(arr1[i]);
				str2 = String.valueOf(arr1[j]);
				if(arr1[i]<arr1[j]&& isEqualLen(str1, str2) && isRightRotation(str1, str2)){
					//System.out.println(arr1[i]+" "+arr1[j]);
					count++;
				}
			}
		}
		
		return count;
	}

	private static boolean isEqualLen(String str1, String str2) {
		return (str1.length() == str2.length()) ? true : false;
	}

	private static boolean isRightRotation(String str1, String str2) {
		if (str1.concat(str1).contains(str2)) {
			return true;
		}
		return false;
	}

	private static int sumOfDigits(int n) {
		int sum = 0;
		while (n != 0) {
			int tmp = n % 10;
			sum += tmp;
			n /= 10;
		}
		return sum;
	}

	

	public static void main(String[] args) throws IOException {
		
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		int k = 0;
		while(n-->0){
			arr[k++] = sc.nextInt();
		}
		
		System.out.println(uniqueRecycledPairs(arr));
	}
}
