package com.test.browserstack;


/**
 * Compute sum of digits in all numbers from 1 to n
 * 
 * @author Somendra1.Raj
 *
 */
public class ComputeSumOfDigits {
	
	private static int sumOfDigits(int n){
		int sum = 0;
		while(n!=0){
			int tmp = n%10;
			sum += tmp;
			n /= 10;
		}
		return sum;
	}
	
	
	private static int reverse(int n){
		int rev = 0;
		while(n!=0){
			int temp = n%10;
			rev = rev*10 + temp;
			n /=10;
		}
		return rev;
	}
	
	public static void main(String args[]){
		int n = 32812312;
		int sum = 0;
		for(int i=1;i<=n;i++){
			sum +=sumOfDigits(i);
			
		}
		int reverse = reverse(n);
		System.out.println("reverse : "+reverse);
		
		System.out.println(sum);
	}
}
