package com.test.browserstack;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringMapping {
	
	
	public static void main(String args[]){
		String[] alphabet = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
		
		Map<Integer, String> map = new HashMap();
		
		String str = "aaaaaannndnnnnnnfffhfhhgjjjwkkkllclc";
		
		Pattern pattern = Pattern.compile("[a+]{2}");
		Matcher matcher = pattern.matcher(str);
		int count = 0;
		while(matcher.find()){
			count++;
		}
		System.out.println(count);
		long cnt = "aaacvgdsygaa".chars().filter(ch -> ch == 'a').count();
		System.out.println(cnt);
		
		Scores sc = new Scores(1, 2);
		System.out.println(sc.id +" "+sc.date);
		
		
		count = 0;
		for(int i=0;i<alphabet.length;i++){
			for(int j=0;j<alphabet.length;j++){
				String s = alphabet[i]+alphabet[j];
				//System.out.println(s);
				count++;
			}
		}
		System.out.println(count);
		
		int n = 2344;
		String s = "";
		while(n>0){
			int rem = n%26;
			if(rem>1){
				s = alphabet[rem-1]+s;
			}else{
				s = alphabet[rem]+s;
			}
			
			n=n/26;
		}
		System.out.println(s);
		
	}

}
