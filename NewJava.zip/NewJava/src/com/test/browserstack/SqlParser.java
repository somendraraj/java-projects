package com.test.browserstack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


class SortByID implements Comparator<Scores>{
	
	public int compare(Scores a, Scores b){
		return a.id-b.id;
	}
}

class SortByName implements Comparator<Scores>{
	@Override
	public int compare(Scores a, Scores b){
		return a.name.compareTo(b.name);
	}
}

class SortByDate implements Comparator<Scores>{
	@Override
	public int compare(Scores a, Scores b){
		return a.date.compareTo(b.date);
	}
}

class SortByScore implements Comparator<Scores>{
	
	public int compare(Scores a, Scores b){
		return a.score-b.score;
	}
}

public class SqlParser {
	
	
	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int q = sc.nextInt();
		String column = sc.nextLine();
		String[] col = column.split(",");
		
		List<String[]> list = new ArrayList<>();
		for(int i=0;i<n;i++){
			String s = sc.nextLine();
			String[] str = s.split(",");
			list.add(str);
		}
		
		for(int i=0;i<q;i++){
			String query = sc.nextLine();
		}
		
		
	}

}
