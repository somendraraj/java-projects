package com.test.browserstack;

import org.apache.commons.lang3.StringUtils;

public class IthPostionCharacterOfString {
	
	
	static String decimalToBinary(String s, int m){
		while(m>0){
			int tmp = m%2;
			//System.out.println(tmp);
			s += tmp;
			m /= 2;
		}
		s = StringUtils.reverse(s);
		return s;
	}
	
	static char getIthPositionCharacter(int m,  int n, int i){
		String str = "";
		str = decimalToBinary(str, m);
		String str1 ="";
		for(int j=0;j<n;j++){
			str1 = convertString(str);
			str = str1;
			str1="";
		}
		return str.charAt(i);
	}
	
	static String convertString(String str){
		char[] ch = str.toCharArray();
		String s = "";
		for(char c: ch){
			if(c== '0'){
				s+="01";
			}else{
				s+="10";
			}
		}
		return s;
	}
	
	public static void main(String args[]){
		
		int m = 5;
		int n = 2;
		int i = 8;
		String s = "";
		//s = decimalToBinary(s, m);
		System.out.println(getIthPositionCharacter(m,n,i));
		
	}

}
