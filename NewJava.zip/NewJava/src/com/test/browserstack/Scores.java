package com.test.browserstack;

public class Scores {

	public int id;
	public String name;
	public String date;
	public int score;
	private int v2;

	public Scores(int id, String name, String date, int score) {
		this.id = id;
		this.name = name;
		this.date = date;
		this.score = score;
	}
	
	public Scores(int id, int v2) {
		this.id = id;
		this.v2=v2;
	}

	@Override
	public String toString() {
		return "Scores [id=" + this.id + ", name=" + this.name + ", date=" + this.date + ", score=" + this.score + "]";
	}

}
