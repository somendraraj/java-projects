package com.test.browserstack;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class ReplaceString {

	static int giftBoxes(String g, String c) {
		if (!c.contains(g)) {
			return 0;
		}
		return 1 + giftBoxes(g, c.replaceFirst(g, ""));
	}

	static long uniqueRecycledPairs(int[] arr){
		Map<Integer, int[]> map = new HashMap<Integer, int[]>();
		for(Integer i: arr){
			storeAnagram(String.valueOf(i).toCharArray(), map, i);
		}
		
		Set<Integer> set = new HashSet<Integer>();
		for(Integer i: arr){
			set.add(i);
		}
		System.out.println(set);
		Iterator<Integer> iter = set.iterator();
		int k = 0;
		int[] arr1 = new int[set.size()];
		while (iter.hasNext()) {
		    arr1[k++] = iter.next();
		}
		
		System.out.println(map);
		Arrays.sort(arr1);
		
		for(int i: arr1){
			System.out.println(i);
		}
		
		int n = arr1.length;
		long count = 0;
		for(int i=0;i<n-1;i++){
			for(int j=i+1;j<n;j++){
				if(areAnagram(map.get(arr1[i]), map.get(arr1[j]))){
					if(arr1[i]<arr1[j]){
						count++;
						//System.out.println(String.valueOf(arr[i])+" "+String.valueOf(arr[j]));
					}
					
				}
			}
		}
		return count;
	}

	static int NO_OF_CHARS=10;
	static boolean areAnagram(int str1[], int str2[]) {
		if (str1.length != str2.length)
			return false;

		// Compare count arrays
		for (int i = 0; i < NO_OF_CHARS; i++)
			if (str1[i] != str2[i])
				return false;

		return true;
	}
	
	
	private static void storeAnagram(char[] ch, Map<Integer, int[]> map, int key){
		int count[] = new int[NO_OF_CHARS];
		Arrays.fill(count, 0);
		for (int i = 0; i < ch.length; i++) {
			count[ch[i]-'0']++;
		}
		map.put(key, count);
	}

	

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int[] arr = new int[n];
		
		for(int i=0;i<n;i++){
			arr[i] = sc.nextInt();
		}
		
		System.out.println(uniqueRecycledPairs(arr));
		
		
	}
	

}
