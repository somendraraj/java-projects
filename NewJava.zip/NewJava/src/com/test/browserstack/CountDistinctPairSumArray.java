package com.test.browserstack;

import java.util.HashSet;
import java.util.Set;

public class CountDistinctPairSumArray {
	
	private static int countPairSum(int[] arr, long k){
		int count = 0;
		int n = arr.length;
		Set<Integer> set = new HashSet<Integer>();
		
		for(Integer i : arr){
			System.out.println(k-i+" " +set);
			if(set.contains((int) k-i)){
				count++;
				//set.remove(k-i);
			}else{
				set.add(i);
			}
		}
		
		System.out.println(set);
		
		return count;
		
	}
	
	public static void main(String args[]){
		int arr[] = {1,11, 2, 9, 3, 10};
		long k = 12;
		System.out.println(countPairSum(arr, k));
	}

}
