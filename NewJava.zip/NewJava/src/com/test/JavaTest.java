package com.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;


class Test{

}

public final class JavaTest extends Test {
	
	
	static final Integer i1 =1;
	final Integer i2 = 2;
	Integer i3 = 3;
	
	
	public int i;
	public static void main(String[] args) {
		
		
		final Integer i4 = 4;
		Integer i5 = 5;
		
		class Inner{
			final Integer i6 = 6;
			Integer i7 = 7;
			Inner(){
				System.out.println(i6+i7);
			}
		}
		
		
		String str1 = new String("hello");
		String str2 = new String("hello");

		if (str1.equals(str2)) {
			System.out.println("equlas method has same hashcode" + str1.hashCode() + " " + str2.hashCode());
		}

		if (str1 == str2) {
			System.out.println("== reference");
		} else {

			System.out.println("not equal reference");

		}
		

		System.out.println(Runtime.getRuntime().totalMemory());
		System.out.println(Runtime.getRuntime().maxMemory());
		System.out.println(Runtime.getRuntime().freeMemory());

	}

	static int sumofoddFactors(int n) {
		int res = 1;
		while (n % 2 == 0)
			n = n / 2;

		for (int i = 3; i <= Math.sqrt(n); i++) {
			int count = 0, curr_sum = 1;
			int curr_term = 1;
			while (n % i == 0) {
				count++;

				n = n / i;

				curr_term *= i;
				curr_sum += curr_term;
			}

			res *= curr_sum;

		}

		if (n >= 2)
			res *= (1 + n);

		return res;
	}

}
