package com.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class IfElseTest {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		//String str = sc.nextLine();

		/*
		 * if(str.equalsIgnoreCase("A")){ System.out.println("Value is :"+str);
		 * }else if(str.equalsIgnoreCase("B")){
		 * System.out.println("Value is :"+str); }else
		 * if(str.equalsIgnoreCase("C")){ System.out.println("Value is :"+str);
		 * }else if(str.equalsIgnoreCase("D")){
		 * System.out.println("Value is :"+str); }else{
		 * System.out.println("Junk value"); }
		 * 
		 * List<String> lista = new ArrayList<String>(); List<String> listb =
		 * new ArrayList<String>();
		 * 
		 * lista.add("a"); lista.add("b"); lista.add("c"); lista.add("d");
		 * 
		 * lista.add("a"); listb.add("e"); listb.add("f"); listb.add("g");
		 * listb.add("h");
		 * 
		 * lista.addAll(listb); System.out.println("Complete list:"+lista);
		 * 
		 * lista.clear();
		 * 
		 * System.out.println("Cleared List: "+lista);
		 */

		String content = sc.nextLine();

		System.out.println("Workign");
		if ((!content.equalsIgnoreCase("A")) && (!content.equalsIgnoreCase("B")) && (!content.equalsIgnoreCase("C"))
				&& (!content.equalsIgnoreCase("D"))) {
			System.out.println("ABCD");
		} else {
			System.out.println("Not ABCD");
		}
		
		
		List<String> list1 = new ArrayList<String>();
		List<String> list2 = new ArrayList<String>();
		
		list1.add("a");
		list1.add("b");
		list1.add("c");
		list1.add("d");
		list1.add("e");
		
		list2.add("a");
		list2.add("b");
		list2.add("c");
		list2.add("a");
		
		List<String> list3 = new ArrayList<String>();
		
		list3 = list1;
		System.out.println("List3"+list3);
		
		Set<String> set = new HashSet<String>();
		set.add("a");
		set.add("b");
		set.add("a");
		set.add("c");
		set.add("c");
		System.out.println(set);
		
		
		for(int i=0;i<list1.size();i++){
			for(int j=0;j<list2.size();j++){
				if(list1.get(i)==list2.get(j)){
					list1.remove(i);
				}
			}
		}
		
		Iterator<String> iter = set.iterator();
		for(int i=0;i<list1.size();i++){
			while(iter.hasNext()){
				if(list1.get(i).equals(iter.next())){
					list1.remove(i);
				}
			}
		}
		System.out.println("List 1"+list1);
		
		//System.out.println(list1);
		
		List<Integer> original = Arrays.asList(12,16,17,19,101);
		List<Integer> selected = Arrays.asList(16,19);

		ArrayList<Integer> add = new ArrayList<Integer>(selected);
		add.removeAll(original);
		System.out.println("Add: " + add);

		ArrayList<Integer> remove = new ArrayList<Integer>(original);
		remove.removeAll(selected);
		System.out.println("Remove: " + remove);
		
		if(original.contains(16)){
			System.out.println("contains");
		}else{
			System.out.println("Not conatins");
		}
		
		
		

	}

}
