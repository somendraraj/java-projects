package com.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.google.gson.JsonObject;

public class TestDate {
	
	static void compareDate(){
		
	}
	
	public static void main(String args[]){
		 Calendar cal = Calendar.getInstance();
         SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");    
         String formattedDate3 = df.format(cal.getTime());
         System.out.println("formattedDate3 : "+formattedDate3);
         
         
         
         String str = "1/03/2017 10:58:33";
         //Date date = null;
         try {
        	 Date date = df.parse(str);
			//System.out.println("Date "+date);
			String str_date = df.format(date);
			System.out.println("formattedDate4 : "+str_date);
			long diff = Math.abs(cal.getTimeInMillis()-date.getTime());
			System.out.println("MONTHS: "+date.getTime());
			System.out.println("DAYS: "+TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
			if(formattedDate3.compareTo(str_date)>0){
				System.out.println("This is test: "+str_date);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
         //"10500008425"
         
         //client_id=bef6825bb70c579365250748208cbc50
        // client_secret=874b14fa13b023e37824730cd1f10a8b
         
      //  String st = "EAACEdEose0cBAODielzDBf5MarZC7eh0zKBRSCZA81zycPNLIr639LeZArvzGzNzw6WOxSFZCOmnPwW19Eh72syaYeEvDfyhzp8b26oUgTgHVZA1ZBo7gRsML8YvMtEPpZAFERrarGAQXQykciZBMnL0973I8ZBE7UyDVsQkWTXarEia8wvWWtYq5rpaTHRlfd6hCsr1dQbfLXgZDZD";
       // System.out.println(st.length());
         
        
         System.out.println(60*60*24*30*12);
         
         String strT = "str";
         String st = "str";
         String strTT = new String("str");
         String stt = new String("str");
         System.out.println(strT==st);
         System.out.println(stt.equals(strTT));

         int val = 24*30*3600;
         
         System.out.println(val);
         System.out.println(Integer.valueOf(val));
         
	}

}
