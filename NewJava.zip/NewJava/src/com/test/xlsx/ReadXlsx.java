package com.test.xlsx;


import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;

public class ReadXlsx {
	
	private FileInputStream file = null;

    public final int COL_STATE = 0;
    public final int COL_CITY = 1;
    public final int COL_NAME = 3;
    public final int COL_ADDRESS = 4;
    public final int COL_PHONE2 = 5;
    public final int COL_PHONE = 7;
    public final int COL_EMAIL = 6;
    public final int COL_PINCODE = 7;
    public final int COL_LATITUDE = 8;
    public final int COL_LONGITUDE = 9;

    private XSSFSheet openFile(String fileName) {
        try {

            this.file = new FileInputStream(new File(fileName));
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            return workbook.getSheetAt(0);
        } catch (Exception ex) {
            System.out.println("File not found");
            return null;
        }
    }

    private void closeFile() {
        try {
            this.file.close();
        } catch (Exception ex) {

        }
    }

    public void parse(String fileName) {
        try {

            XSSFSheet sheet = this.openFile(fileName);

            if (sheet == null) {
                return;
            }

            Iterator<Row> rowIterator = sheet.iterator();
            DataFormatter format = new DataFormatter();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                System.out.println("This is test");
              //  System.out.println(row.getRowNum());
                JSONObject obj = new JSONObject();
                obj.put("phone", row.getCell(COL_PHONE).getStringCellValue());
                obj.put("business_name", row.getCell(COL_NAME).getStringCellValue());
                obj.put("country", "India");
                obj.put("state", row.getCell(COL_STATE).getStringCellValue());
                obj.put("city", row.getCell(COL_CITY).getStringCellValue());
                obj.put("address", row.getCell(COL_ADDRESS).getStringCellValue());
                obj.put("pin_code", row.getCell(COL_PINCODE).getStringCellValue());
                // obj.put("category", row.getCell(COL_STATE).getStringCellValue());
                obj.put("creator_name", row.getCell(COL_NAME).getStringCellValue());
                obj.put("email", row.getCell(COL_EMAIL).getStringCellValue());
                System.out.println(obj.toString());

                // MultipartFileUploader fu = new
                // MultipartFileUploader("http://localhost:9091/api/dealer");
                // fu
                // .params("dealer", obj.toString())
                // .file("channel_logo", new File("m:/temp/users.png"))
                // .file("business_photos[]", new File("m:/temp/users.png"))
                // .file("business_photos[]", new File("m:/temp/users.png"))
                // .upload();
            }
            closeFile();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    private String getNumericValue(Row row, int col) {
        try {
            return NumberToTextConverter.toText(row.getCell(col).getNumericCellValue());
        } catch (Exception ex) {
            return "";
        }
    }

    private String getStringValue(Row row, int col) {
        try {
            return row.getCell(col).getStringCellValue();
        } catch (Exception ex) {
            return "";
        }
    }

    private String getDateValue(Row row, int col) {
        try {
            Date dt = row.getCell(col).getDateCellValue();
            DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
            return df.format(dt);
        } catch (Exception ex) {
            return "";
        }
    }

    public static void main(String[] args) {
        new ReadXlsx().parse("./dealers.xlsx");
    }

}



