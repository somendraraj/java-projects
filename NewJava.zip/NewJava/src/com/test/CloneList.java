package com.test;

import java.util.ArrayList;

public class CloneList {

	@SuppressWarnings("unchecked")
	public static void main(String args[]) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("e");
		list.add("b");
		list.add("c");

		ArrayList<String> cloneList = new ArrayList<String>();
		cloneList.addAll(list);
		// list.clear();
		System.out.println("List: " + list + " CloneList: " + cloneList);

		ArrayList<String> list1 = new ArrayList<String>();
		list1 = (ArrayList<String>) list.clone();

		System.out.println("new clone list" + list1);
		
		String lat = "19.193888";
		Float fl = Float.parseFloat(lat);
		System.out.println(fl);
		
		String num = "123456789";
		if(num.matches("\\d+")){
			System.out.println("Match");
		}
		
		
		String str = "Hiwedrftgyuiwsedrtfyuhiawsedrtfyuwstyqqqqqqq";
		String sub = str.substring(0, Math.min(str.length(), 20));
		System.out.println(sub);
		System.out.println(sub.length());
	}

}
