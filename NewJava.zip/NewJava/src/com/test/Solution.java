package com.test;

import java.util.Scanner;
import java.util.Stack;

public class Solution {

	public static Stack<Integer> stack = new Stack<Integer>();

	static void solve(Stack<Integer> stack, int x, int d) {
		int n = stack.size();

		int arr[] = new int[n];
		for (int i = 0; i < n; i++) {
			arr[i] = stack.pop();
		}

		for (int i = n - x; i < n; i++) {
			arr[i] +=d;
		}

		for (long i = n - 1; i >= 0; i--) {
			stack.push(arr[(int) i]);
		}

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.nextLine();
		while (n-- > 0) {
			String str = sc.nextLine();
			if (str.startsWith("push")) {
				String s[] = str.split(" ");
				stack.push(Integer.parseInt(s[1]));
				System.out.println(s[1]);
			} else if (str.contains("pop")) {
				if (!stack.isEmpty()) {
					stack.pop();
					if (!stack.isEmpty()) {
						long y = stack.peek();
						System.out.println(y);
					} else {
						System.out.println("EMPTY");
					}

				} else {
					System.out.println("EMPTY");
				}
			} else {
				String s[] = str.split(" ");
				int x = Integer.parseInt(s[1]);
				int d = Integer.parseInt(s[2]);
				solve(stack, x, d);
				System.out.println(stack.peek());
			}
		}
		System.out.println(stack);
	}
}
