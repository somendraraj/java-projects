package com.test;

public class MaxMinString {

	public static void main(String[] args) {
		
		String str = "1234567890123456789012";
		
		StringBuilder sb = new StringBuilder();
		
		 sb.append((str.length()<=20)?str:str.substring(0, 20)+"...");
		System.out.println(sb);
		System.out.println(str.length());
		
	}

}
