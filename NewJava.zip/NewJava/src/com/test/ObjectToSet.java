package com.test;


import java.util.HashSet;
import java.util.Set;


public class ObjectToSet {

	public static void main(String[] args) {
		Object list = new HashSet<String>();
		
		Set<String> integers = cast(list);
		System.out.println(integers);
	}

	@SuppressWarnings("unchecked")
	public static <T extends HashSet<?>> T cast(Object obj) {
		return (T) obj;
	}

}
