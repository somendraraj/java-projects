package com;
import java.lang.StackOverflowError;


public class TOH{
		public static void TOH(int n, char A, char B, char C){
			/*If only one disk, make the move and return*/
			if(n == 0){
				System.out.println("Move disk"+n+" from "+A+"to"+B);
			}
			/*Move top n-1 disks from A to B, using C as auxiliary*/
			TOH(n-1, A, C, B);
			System.out.println("Move disk "+n+" from "+A+"to"+B);
			TOH(n-1, C, B, A);
		}
		
	public static void main(String args[]){
		TOH obj = new TOH();
		char source_tower='A',destination_tower='B',temporary_tower='C';
		obj.TOH(3, source_tower, destination_tower, temporary_tower);
	}

}
