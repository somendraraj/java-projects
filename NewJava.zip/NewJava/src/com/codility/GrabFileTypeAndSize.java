package com.codility;

public class GrabFileTypeAndSize {

	public static void main(String args[]) {
		String file = "my.song.mp3 11b\ngreatSong.flac 1000b\nnot3.txt 5b\nvideo.mp4 200b\ngame.exe 100b\nmov!e.mkv 10000b";
		
		
		
		String res = solution(file);
		System.out.println(res);
	}

	public static String solution(String str) {
		
		String[] s = str.split("[\\s+\n]");
		for(int i=0;i<s.length;i++){
			
		}
		int count_mu=0, count_im=0, count_mo=0, count_ot=0;
		for(int i=0;i<s.length-1;i+=2){
			
			if(s[i].contains("mp3") || s[i].contains("aac") || s[i].contains("flac")){
				int len = s[i+1].length()-1;
				count_mu  += Integer.parseInt(s[i+1].substring(0, len));
				
			}else if(s[i].contains("jpg") || s[i].contains("bmp") || s[i].contains("gif")){
				int len = s[i+1].length()-1;
				count_im  += Integer.parseInt(s[i+1].substring(0, len));
				
			}else if(s[i].contains("mp4") || s[i].contains("avi") || s[i].contains("mkv")){
				int len = s[i+1].length()-1;
				count_mo  += Integer.parseInt(s[i+1].substring(0, len));
			} else {
				int len = s[i+1].length()-1;
				count_ot  += Integer.parseInt(s[i+1].substring(0, len));
			}
		}
		String res = "music "+count_mu+"b\n"+"images "+count_im+"b\n"+"movies "+count_mo+"b\n"+"others "+count_ot+"b";
		
		return res;
	}

}
