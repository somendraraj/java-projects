package com.codility;

public class GrabParkingTest {

	public static void main(String args[]) {
		System.out.println(solution("10:00", "10:21"));
	}

	public static int solution(String E, String L) {
		int h1 = Integer.parseInt(E.substring(0, 2));
		int m1 = Integer.parseInt(E.substring(3, 5));
		int h2 = Integer.parseInt(L.substring(0, 2));
		int m2 = Integer.parseInt(L.substring(3, 5));
		int h = h2 - h1;
		int m = m2 - m1;

		if (m > 0) {
			h = h + 1;
		}

		if (h == 0 && m == 0) {
			return 0;
		}
		int res = 2;
		if (h == 1) {
			res = res + 3;
		} else {
			res = res + ((h - 1) * 4) + 3;
		}
		return res;
	}

}
