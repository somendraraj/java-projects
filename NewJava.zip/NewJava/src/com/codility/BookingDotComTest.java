package com.codility;

public class BookingDotComTest {
	
	static int[] oddNumbers(int l, int r) {
        int arr[] = new int[100000];
        int j=0;
        for(int i=l;i<=r;i++){
            if((i&1)!=0){
                arr[j] = i;
                j++;
            }
        }
        return arr;
    }

	public static void main(String args[]){
		int l = 1;
		int r = 100000;
		int arr[] = oddNumbers(l, r);
		int len = (r-l)/2+1;
		System.out.println(len);
		for(int i=0;i<len;i++){
			//System.out.println(arr[i]);
		}
	}

}
