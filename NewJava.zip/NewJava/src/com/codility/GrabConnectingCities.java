package com.codility;

public class GrabConnectingCities {
	
	public static void solution(int t[]){
		int m = t.length;
		for(int i=0;i<t.length;i++){
			//t[i] = m
		}
		
	}

	public static void main(String[] args) {
		

	}

}
