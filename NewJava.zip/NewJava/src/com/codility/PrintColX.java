package com.codility;

import java.util.HashMap;
import java.util.Map;

public class PrintColX {
	
	public static String getX(int col, String str){
		Map<Integer, String> map = new HashMap<Integer, String>();
		int count = 0;
		for(int i=0;i<str.length();i++) {
			char c = str.charAt(i);
			if(c=='('){
				count--;
			}else if(c==')'){
				count++;
			}
			if(c>='a' && c<='z'){
				if(map.get(count)!=null){
					map.put(count, map.get(count)+c);
				}else{
					map.put(count, String.valueOf(c));
				}
			}
			if(c=='.'){
				count++;
			}
		}
		System.out.println(map);
		return map.get(col);
	}
	public static void main(String args[]){
		
		
		String str = "a(b(..)c(d(..)e(f(..).)))";
		int index = 2;
		System.out.println(getX(index, str));
		
	}

}
