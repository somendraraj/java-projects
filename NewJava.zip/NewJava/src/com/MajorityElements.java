package com;

import java.util.HashMap;

public class MajorityElements {
	
	public static void main(String args[]){
		int arr[] = {3,3,4,2,6,4,4,9,4};
		
	}
	
	static int getMajority(int arr[]){
		HashMap<Integer, Integer> hashMap = new HashMap<Integer, Integer>();
		for(int i=0;i<arr.length;i++){
			if(hashMap.containsKey(arr[i])){
				
			}
		}
		return 0;
	}

}
