package com;

import java.util.Scanner;

public class Factorial {
	@SuppressWarnings("resource")
	public static void main(String args[]){
		
		//Factorial f = new Factorial();
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int fact = Fact(n);
		System.out.println(fact);
	}
	
	
	public static int Fact(int n){
		if(n<=1)
			return 1;
		else{
			return n*Fact(n-1);
		}
	}

}
