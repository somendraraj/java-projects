package com;

import java.util.Scanner;

public class SolutionDS {
	
	static class MyList{
		public int a;
		public int b;
		public int k;
		
		public MyList(int a, int b, int k){
			this.a = a;
			this.b = b;
			this.k = k;
		}
	}
	
	static long returnLong(int n, int m, MyList ops[]){
		int arr[] = new int[n+1];
		for(int i=0;i<arr.length;i++){
			arr[i] = 0;
		}
		
		for(int i =0;i<m;i++){
			arr[ops[i].a-1] +=ops[i].k;
			arr[ops[i].b] -=ops[i].k;
		}
		
		long max = arr[0];
		long sum = max;
		for(int i=1;i<n;i++){
			sum += arr[i];
            if(sum > max) {
                max = sum;
            }
		}
		return max;
	}
	
	public static void main(String args[]){
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int m = scan.nextInt();
		MyList[] ops = new MyList[m];
		
		for(int i=0;i<m;i++){
			int a = scan.nextInt();
			int b = scan.nextInt();
			int k = scan.nextInt();
			ops[i] = new MyList(a, b, k);
		}
		
		Long max = returnLong(n, m, ops);
		System.out.println(max);
	}

}
