package com;

import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class MarbelsGame {
	
	public static void main(String args[]){
		 Scanner in = new Scanner(System.in);
	     ArrayList<String> list = new ArrayList<String>();
	     list.add("name"+":"+"Somendra");
	     list.add("followId"+":"+"12345");
	     list.add("Content"+":"+"Hi This is content");
	     list.add("msgType"+":"+"text");
	     Map<String, ArrayList<String>> map = new ConcurrentHashMap<String, ArrayList<String>>();
	     map.put("123456", list);
	}
	
	static int getCupNumber(int m, int n){
		return 0;
	}

}
