package com.hackerrank.ai;

import java.util.Scanner;

public class BotSavesPrincess1 {

	static class Position {
		int start;
		int end;

		public Position(int start, int end) {
			this.start = start;
			this.end = end;
		}

		public int getStart() {
			return this.start;
		}

		public int getEnd() {
			return this.end;
		}
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();

		String[][] arr = new String[n][n];
		Position[] pos = new Position[2];
		sc.nextLine();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				arr[i][j] = sc.next();

				if (arr[i][j].equals("m")) {
					pos[0] = new Position(i, j);
				}
				if (arr[i][j].equals("p")) {
					pos[1] = new Position(i, j);
				}
			}
		}

		System.out.println(pos[0].getStart() + " " + pos[0].getEnd());
		System.out.println(pos[1].getStart() + " " + pos[1].getEnd());
	}
}
