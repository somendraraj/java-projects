package com.java.date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;

public class DateTime {
	
	public static String getDate(){
		SimpleDateFormat dayFormat = new SimpleDateFormat("dd-MM-yyyy");
		return dayFormat.format(new Date());
		//return date;
	}
	
	
	public static boolean isLessThan30Days(String day) throws ParseException{
		
		SimpleDateFormat dayFormat = new SimpleDateFormat("dd-MM-yyyy");
		String today = dayFormat.format(new Date());
		
		Date date1 = dayFormat.parse(today);
	    Date date2 = dayFormat.parse(day);
	    long diff = date2.getTime() - date1.getTime();
	    System.out.println ("Days: " + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
	    System.out.println ("Days: " + diff);
	    if(Math.abs(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS))<=30){
	    	return true;
	    }
	    return false;
		
	}

	public static void main(String args[]) throws ParseException {
		SimpleDateFormat dayFormat = new SimpleDateFormat("dd-MM-yyyy");
		String date = dayFormat.format(new Date());
		
		Date newDate = dayFormat.parse("21-11-2017");

		/*System.out.println(date);

		Calendar myCal = new GregorianCalendar();

		myCal.setTime(newDate);

		System.out.println("Day: " + myCal.get(Calendar.DATE));
		System.out.println("Month: "+myCal.get(Calendar.MONTH)+1);
		System.out.println("Year: " + myCal.get(Calendar.YEAR));
*/
		
		//System.out.println(getDate());
		
		System.out.println(isLessThan30Days("23-12-2017"));
		
		System.out.println(30*24*3600);
		
		try{
			
			   String date1 = "2018-07-13 06:28:00";
		        String date2 = "2018-07-13 14:28:00";
		        int diff = compareTwoDate(date1, date2);
		        System.out.println("date"+ diff);
		        
		        System.out.println("date: "+ trim(new Date()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static int compareTwoDate(String startTime, String endTime) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date b = formatter.parse(startTime);
        Date c = formatter.parse(endTime);
        return b.compareTo(c);

    }
	
	public static int comparedate() throws Exception{
        String date1 = "2018-07-12 14:28:00";
        String date2 = "2018-07-13 14:28:00";
        int diff = compareTwoDate(date1, date2);
        System.out.println(diff);
        return 0;
    }
	
	 public static Date trim(Date date) {
	        Calendar calendar = Calendar.getInstance();
	        calendar.setTime(date);
	        calendar.set(Calendar.MILLISECOND, 0);
	        calendar.set(Calendar.SECOND, 0);
	        calendar.set(Calendar.MINUTE, 0);
	        calendar.set(Calendar.HOUR, 0);
	       
	        return calendar.getTime();
	    }

}
