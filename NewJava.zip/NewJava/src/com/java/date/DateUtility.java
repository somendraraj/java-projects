package com.java.date;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.TimeZone;

public class DateUtility {

    private static final SimpleDateFormat ORA_DATE_TIME_FORMAT = new SimpleDateFormat("yyyyMMdd");

    /**
     * ORA
     */
    private static final SimpleDateFormat ORA_DATE_TIME_EXTENDED_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss");

    private static final long ONE_DAY = 24 * 60 * 60 * 1000;

    private static final long ONE_HOUR = 60 * 60 * 1000;

    private static final long ONE_MIN = 60 * 1000;

    static public final String DATE_FMT_1 = "yyyy-MM-dd";

    /**
     * date format yyyyMMdd
     */
    static public final String DATE_FMT_0 = "yyyyMMdd";

    static public final String DATE_FMT_2 = "dd-MM-yyyy";

    /**
     * HH:MM:SS，：00:59:06 + 01:00:59  02:00:05。
     * 
     * @param time1
     *            
     * @param time2
     *            
     * @return 
     */
    public static String addTwoTimeStr(String time1, String time2) {

        String returnStr = "00:00:00";
        if (time1 != null && !time1.equalsIgnoreCase("") && time2 != null && !time2.equalsIgnoreCase("")) {
            String[] time1Array = time1.split(":");
            String[] time2Array = time2.split(":");
            int hour1 = (new Integer(time1Array[0])).intValue();
            int hour2 = (new Integer(time2Array[0])).intValue();
            int min1 = (new Integer(time1Array[1])).intValue();
            int min2 = (new Integer(time2Array[1])).intValue();
            int sec1 = (new Integer(time1Array[2])).intValue();
            int sec2 = (new Integer(time2Array[2])).intValue();

            String lastSec, lastMin, lastHour;

            int totalSec = sec1 + sec2;
            if (totalSec / 60 > 0) {
                // 1min1
                min1 = min1 + totalSec / 60;
            }
            if (totalSec % 60 > 9) {
                lastSec = new Integer(totalSec % 60).toString();
            } else {
                lastSec = new String("0" + new Integer(totalSec % 60).toString());
            }

            int totalMin = min1 + min2;
            if (totalMin / 60 > 0) {
                // 1hour1
                hour1 = hour1 + totalMin / 60;
            }
            if (totalMin % 60 > 9) {
                lastMin = new Integer(totalMin % 60).toString();
            } else {
                lastMin = new String("0" + new Integer(totalMin % 60).toString());
            }

            int totalHour = hour1 + hour2;
            if (totalHour % 24 > 9) {
                lastHour = new Integer(totalHour % 24).toString();
            } else {
                lastHour = new String("0" + new Integer(totalHour % 24).toString());
            }

            returnStr = lastHour + ":" + lastMin + ":" + lastSec;
        } else if (time1 != null && !time1.equalsIgnoreCase("")) {
            returnStr = time1.substring(0, 8);
        } else if (time2 != null && !time2.equalsIgnoreCase("")) {
            returnStr = time2.substring(0, 8);
        } else {
            returnStr = "00:00:00";
        }

        return returnStr;
    }

    // 
    @SuppressWarnings({ "deprecation" })
    public static String currentDate() {
        Date myDate = new Date();
        int thisYear = myDate.getYear() + 1900;
        int thisMonth = myDate.getMonth() + 1;
        int thisDate = myDate.getDate();
        String date = thisYear + "" + thisMonth + "" + thisDate + "";
        return date;
    }

    /**
     * ORA
     * 
     * @return ORA
     */
    @SuppressWarnings("unused")
	private static synchronized DateFormat getOraDateTimeFormat() {
        SimpleDateFormat theDateTimeFormat = (SimpleDateFormat) ORA_DATE_TIME_FORMAT.clone();
        theDateTimeFormat.setLenient(false);
        return theDateTimeFormat;
    }

    /**
     * ORA
     * 
     * @return ORA
     */
    private static synchronized DateFormat getOraExtendDateTimeFormat() {
        SimpleDateFormat theDateTimeFormat = (SimpleDateFormat) ORA_DATE_TIME_EXTENDED_FORMAT.clone();
        theDateTimeFormat.setLenient(false);
        return theDateTimeFormat;
    }

    /**
     *  YYYY-MM-DD
     * 
     * @return  YYYY-MM-DD
     */
    public static String getSystemCurrentDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        return doTransform(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH));
    }

    /**
     * YYYY-MM-DD
     * 
     * @param year
     *            
     * @param month
     *            
     * @param day
     *            
     * @return
     */
    private static String doTransform(int year, int month, int day) {
        StringBuffer result = new StringBuffer();
        result.append(String.valueOf(year)).append("-").append(month < 10 ? "0" + String.valueOf(month) : String.valueOf(month)).append("-")
                .append(day < 10 ? "0" + String.valueOf(day) : String.valueOf(day));
        return result.toString();
    }

    /**
     *  YYYY-MM-DD hh:mm:ss
     * 
     * @return YYYY-MM-DD hh:mm:ss
     */
    public static final String getSystemCurrentDateTime() {
        Calendar newCalendar = Calendar.getInstance();
        newCalendar.setTimeInMillis(System.currentTimeMillis());
        int year = newCalendar.get(Calendar.YEAR);
        int month = newCalendar.get(Calendar.MONTH) + 1;
        int day = newCalendar.get(Calendar.DAY_OF_MONTH);
        int hour = newCalendar.get(Calendar.HOUR_OF_DAY);
        int minute = newCalendar.get(Calendar.MINUTE);
        int second = newCalendar.get(Calendar.SECOND);
        return doTransform(year, month, day, hour, minute, second);
    }

    /**
     *  hh:mm:ss
     * 
     * @return hh:mm:ss
     */
    public static final String getSystemCurrentTime() {
        return getSystemCurrentDateTime().substring(11, 19);
    }

    /**
     * YYYY-MM-DD hh:mm:ss
     * 
     * @param year
     *            
     * @param month
     *            
     * @param day
     *            
     * @param hour
     *            
     * @param minute
     *            
     * @param second
     *            
     * @return
     */
    private static final String doTransform(int year, int month, int day, int hour, int minute, int second) {
        StringBuffer result = new StringBuffer();
        result.append(String.valueOf(year)).append("-").append(month < 10 ? "0" + String.valueOf(month) : String.valueOf(month)).append("-")
                .append(day < 10 ? "0" + String.valueOf(day) : String.valueOf(day)).append(" ")
                .append(hour < 10 ? "0" + String.valueOf(hour) : String.valueOf(hour)).append(":")
                .append(minute < 10 ? "0" + String.valueOf(minute) : String.valueOf(minute)).append(":")
                .append(second < 10 ? "0" + String.valueOf(second) : String.valueOf(second));
        return result.toString();
    }

    /**
     * 
     * 
     * @return  :YYYY-MM-DD
     */
    public static synchronized String getDayBeforeToday() {
        Date date = new Date(System.currentTimeMillis());
        GregorianCalendar gc = (GregorianCalendar) Calendar.getInstance();
        gc.setTime(date);
        gc.add(Calendar.DATE, -1);
        return doTransform(toString(gc.getTime(), getOraExtendDateTimeFormat())).substring(0, 10);
    }

    /**
     * 
     * 
     * @param dateStr
     *             :YYYY-MM-DD
     * @return  :YYYY-MM-DD
     */
    public static synchronized String getDayBeforeToday(String dateStr) {
        Date date = toDayStartDate(dateStr);
        GregorianCalendar gc = (GregorianCalendar) Calendar.getInstance();
        gc.setTime(date);
        gc.add(Calendar.DATE, -1);

        return doTransform(toString(gc.getTime(), getOraExtendDateTimeFormat())).substring(0, 10);
    }

    /**
     * 
     * 
     * @return  :YYYY-MM-DD
     */
    public static synchronized String getDayAfterToday() {
        Date date = new Date(System.currentTimeMillis());
        GregorianCalendar gc = (GregorianCalendar) Calendar.getInstance();
        gc.setTime(date);
        gc.add(Calendar.DATE, 1);
        return doTransform(toString(gc.getTime(), getOraExtendDateTimeFormat())).substring(0, 10);
    }

    /**
     * 
     * 
     * @param dateStr
     *             :YYYY-MM-DD
     * @return  :YYYY-MM-DD
     */
    public static synchronized String getDayAfterToday(String dateStr) {
        Date date = toDayStartDate(dateStr);
        GregorianCalendar gc = (GregorianCalendar) Calendar.getInstance();
        gc.setTime(date);
        gc.add(Calendar.DATE, 1);
        return doTransform(toString(gc.getTime(), getOraExtendDateTimeFormat())).substring(0, 10);
    }

    /**
     * 
     * 
     * @return  :YYYY-MM-DD
     */
    public static synchronized Date getDayAfterMonth(int months) {
        Date date = new Date(System.currentTimeMillis());
        GregorianCalendar gc = (GregorianCalendar) Calendar.getInstance();
        gc.setTime(date);
        gc.add(Calendar.MONTH, months);
        return gc.getTime();
    }

    /**
     * YYYY-MM-DD hh:mm:ss
     * 
     * @param date
     *            ORA
     * @return
     */
    private static String doTransform(String date) {
        StringBuffer buffer = new StringBuffer();
        buffer.append(date.substring(0, 4));
        buffer.append("-");
        buffer.append(date.substring(4, 6));
        buffer.append("-");
        buffer.append(date.substring(6, 8));
        buffer.append(" ");
        buffer.append(date.substring(8, 10));
        buffer.append(":");
        buffer.append(date.substring(10, 12));
        buffer.append(":");
        buffer.append(date.substring(12, 14));

        return buffer.toString();
    }

    /**
     * 、。 ，.
     * 
     * @param theDate
     *            
     * @param theDateFormat
     *            
     * @return 
     */
    public static synchronized String toString(Date theDate, DateFormat theDateFormat) {
        if (theDate == null) {
            return "";
        } else {
            return theDateFormat.format(theDate);
        }
    }

    /**
     * Date YYYY-MM-DD hh:mm:ss
     * 
     * @param theDate
     *            Date
     * @return 
     */
    public static synchronized String toDefaultString(Date theDate) {
        if (theDate == null) {
            return "";
        }
        return doTransform(toString(theDate, getOraExtendDateTimeFormat()));
    }

    /**
     * 2004-8-13 12:31:22Date
     * 
     * @param dateStr
     *            
     * @return Date
     */
    public static synchronized Date toDate(String dateStr) {
        String[] list0 = dateStr.split(" ");
        String date = list0[0];
        String time = list0[1];
        String[] list1 = date.split("-");
        int year = new Integer(list1[0]).intValue();
        int month = new Integer(list1[1]).intValue();
        int day = new Integer(list1[2]).intValue();
        String[] list2 = time.split(":");
        int hour = new Integer(list2[0]).intValue();
        int min = new Integer(list2[1]).intValue();
        int second = new Integer(list2[2]).intValue();
        Calendar cale = Calendar.getInstance();
        cale.set(year, month - 1, day, hour, min, second);
        return cale.getTime();
    }

    /**
     * 2004-8-13,2004-10-8Date,Date YYYY-MM-DD
     * 00:00:00,
     * 
     * @param dateStr
     *            
     * @return Date
     */
    public static synchronized Date toDayStartDate(String dateStr) {
        String[] list = dateStr.split("-");
        int year = Integer.parseInt(list[0]);
        int month = Integer.parseInt(list[1]);
        int day = Integer.parseInt(list[2]);
        Calendar cale = Calendar.getInstance();
        cale.set(year, month - 1, day, 0, 0, 0);

        return cale.getTime();

    }

    /**
     * 2004-8-13,2004-10-8Date,Date YYYY-MM-DD
     * 23:59:59,
     * 
     * @param dateStr
     *            :2004-8-13,2004-10-8
     * @return Date
     */
    public static synchronized Date toDayEndDate(String dateStr) {
        String[] list = dateStr.split("-");
        int year = new Integer(list[0]).intValue();
        int month = new Integer(list[1]).intValue();
        int day = new Integer(list[2]).intValue();
        Calendar cale = Calendar.getInstance();
        cale.set(year, month - 1, day, 23, 59, 59);
        return cale.getTime();

    }

    /**
     * scorm
     * 
     * @param scormTime1
     *            scorm,00:00:00(1..2).0(1..3)
     * @param scormTime2
     *            scorm,00:00:00(1..2).0(1..3)
     * @return scorm
     */
    public static synchronized String addTwoScormTime(String scormTime1, String scormTime2) {
        int dotIndex1 = scormTime1.indexOf(".");
        int hh1 = Integer.parseInt(scormTime1.substring(0, 2));
        int mm1 = Integer.parseInt(scormTime1.substring(3, 5));
        int ss1 = 0;
        if (dotIndex1 != -1) {
            ss1 = Integer.parseInt(scormTime1.substring(6, dotIndex1));
        } else {
            ss1 = Integer.parseInt(scormTime1.substring(6, scormTime1.length()));
        }
        int ms1 = 0;
        if (dotIndex1 != -1) {
            ms1 = Integer.parseInt(scormTime1.substring(dotIndex1 + 1, scormTime1.length()));
        }

        int dotIndex2 = scormTime2.indexOf(".");
        int hh2 = Integer.parseInt(scormTime2.substring(0, 2));
        int mm2 = Integer.parseInt(scormTime2.substring(3, 5));
        int ss2 = 0;
        if (dotIndex2 != -1) {
            ss2 = Integer.parseInt(scormTime2.substring(6, dotIndex2));
        } else {
            ss2 = Integer.parseInt(scormTime2.substring(6, scormTime2.length()));
        }
        int ms2 = 0;
        if (dotIndex2 != -1) {
            ms2 = Integer.parseInt(scormTime2.substring(dotIndex2 + 1, scormTime2.length()));
        }

        int hh = 0;
        int mm = 0;
        int ss = 0;
        int ms = 0;

        if (ms1 + ms2 >= 1000) {
            ss = 1;
            ms = ms1 + ms2 - 1000;
        } else {
            ms = ms1 + ms2;
        }
        if (ss1 + ss2 + ss >= 60) {
            mm = 1;
            ss = ss1 + ss2 + ss - 60;
        } else {
            ss = ss1 + ss2 + ss;
        }
        if (mm1 + mm2 + mm >= 60) {
            hh = 1;
            mm = mm1 + mm2 + mm - 60;
        } else {
            mm = mm1 + mm2 + mm;
        }
        hh = hh + hh1 + hh2;

        StringBuffer sb = new StringBuffer();
        if (hh < 10) {
            sb.append("0").append(hh);
        } else {
            sb.append(hh);
        }
        sb.append(":");
        if (mm < 10) {
            sb.append("0").append(mm);
        } else {
            sb.append(mm);
        }
        sb.append(":");
        if (ss < 10) {
            sb.append("0").append(ss);
        } else {
            sb.append(ss);
        }
        sb.append(".");
        if (ms < 10) {
            sb.append(ms).append("00");
        } else if (ms < 100) {
            sb.append(ms).append("0");
        } else {
            sb.append(ms);
        }
        return sb.toString();
    }

    /**
     * timeType（） ，date，
     * 0（：2003-2-23  2004-6-122312，0， 2003-2-23  2005-6-23
     * ，，28（）。 2003-2-23  2001-6-23
     * ，，-20（））
     * 
     * @param date
     *            
     * @param timeType
     *            0，1
     * @return timeType
     */
    public static int CompareDateWithNow(Date date, int timeType) {
        Date now = Calendar.getInstance().getTime();

        Calendar calendarNow = Calendar.getInstance();
        calendarNow.setTime(now);
        calendarNow.set(Calendar.HOUR, 0);
        calendarNow.set(Calendar.MINUTE, 0);
        calendarNow.set(Calendar.SECOND, 0);

        Calendar calendarPara = Calendar.getInstance();
        calendarPara.setTime(date);
        calendarPara.set(Calendar.HOUR, 0);
        calendarPara.set(Calendar.MINUTE, 0);
        calendarPara.set(Calendar.SECOND, 0);

        float nowTime = now.getTime();
        float dateTime = date.getTime();

        if (timeType == 0) {
            if (calendarNow.get(Calendar.DAY_OF_YEAR) == calendarPara.get(Calendar.DAY_OF_YEAR))
                return 0;
            return (calendarNow.get(Calendar.YEAR) - calendarPara.get(Calendar.YEAR)) * 12 + calendarNow.get(Calendar.MONTH) - calendarPara.get(Calendar.MONTH);
        } else {
            float result = nowTime - dateTime;
            float day = 24 * 60 * 60 * 1000;
            // System.out.println("day "+day);
            // result = (result > 0) ? result : -result;
            // System.out.println(result);
            result = result / day;
            Float resultFloat = new Float(result);
            float fraction = result - resultFloat.intValue();
            if (fraction > 0.5) {
                return resultFloat.intValue() + 1;
            } else if (fraction < -0.5) {
                return resultFloat.intValue() - 1;
            } else {
                return resultFloat.intValue();
            }
        }
    }

    /**
     * 2、、<br>
     * <br>
     * 
     * @param pBeginTime
     *            <br>
     * @param pEndTime
     *            <br>
     * @return String <br>
     * @Exception <br>
     */
    public static String TimeDiff(String pBeginTime, String pEndTime) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm");
        Long beginL = format.parse(pBeginTime).getTime();
        Long endL = format.parse(pEndTime).getTime();
        Long day = (endL - beginL) / 86400000;
        Long hour = ((endL - beginL) % 86400000) / 3600000;
        Long min = ((endL - beginL) % 86400000 % 3600000) / 60000;
        return ("" + day + "" + hour + "" + min);
    }

    /**
     * 12
     * 
     * @return 12
     */
    public static boolean isLastMonth() {
        if (month() == 12)
            return true;
        return false;
    }

    /**
     * 
     * 
     * @return 
     */
    public static Integer year() {
        Calendar calendar = Calendar.getInstance();
        return new Integer(calendar.get(Calendar.YEAR));
    }

    /**
     * 
     * 
     * @return 
     */
    public static Integer month() {
        Calendar calendar = Calendar.getInstance();
        return new Integer(calendar.get(Calendar.MONTH) + 1);
    }

    /**
     * ,1，12
     * 
     * @return 
     */
    public static Integer beforeMonth() {
        Calendar calendar = Calendar.getInstance();
        int month = calendar.get(Calendar.MONTH);
        if (month == 0) {
            return new Integer(12);
        } else {
            return new Integer(month);
        }
    }

    /**
     * ,12，1
     * 
     * @return 
     */
    public static Integer nextMonth() {
        Calendar calendar = Calendar.getInstance();
        int month = calendar.get(Calendar.MONTH);
        if (month == 11) {
            return new Integer(1);
        } else {
            return new Integer(month + 2);
        }
    }

    /**
     * 
     * 
     * @return 
     */
    public static Integer day() {
        Calendar calendar = Calendar.getInstance();
        return new Integer(calendar.get(Calendar.DAY_OF_MONTH));
    }

    /**
     * 
     * 
     * @return 
     */
    public static Integer hour() {
        Calendar calendar = Calendar.getInstance();
        return new Integer(calendar.get(Calendar.HOUR_OF_DAY));
    }

    /**
     * 
     * 
     * @return 
     */
    public static Integer minute() {
        Calendar calendar = Calendar.getInstance();
        return new Integer(calendar.get(Calendar.MINUTE));
    }

    /**
     * 
     * 
     * @return 
     */
    public static Integer second() {
        Calendar calendar = Calendar.getInstance();
        return new Integer(calendar.get(Calendar.SECOND));
    }

    /**
     * 
     * 
     * @return 
     */
    public static int WeekofMonth() {
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.WEEK_OF_MONTH);
    }

    /**
     * 
     * 
     * @return 
     */
    public static int DayofWeek() {
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.DAY_OF_WEEK) - 1;
    }

    /**
     * 
     * 
     * @return 
     */
    public static int getMaxWeekofMonth() {
        Calendar calendar = Calendar.getInstance();
        return calendar.getActualMaximum(Calendar.WEEK_OF_MONTH);
    }

    /**
     * 
     * 
     * @return 
     */
    public static int WeekofMonth(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, day, 0, 0, 0);
        return calendar.get(Calendar.WEEK_OF_MONTH);
    }

    /**
     * 
     * 
     * @return 
     */
    public static int DayofWeek(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, day, 0, 0, 0);
        return calendar.get(Calendar.DAY_OF_WEEK) - 1;
    }

    /**
     * 
     * 
     * @return 
     */
    public static int getTodayofWeek() {
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.DAY_OF_WEEK) - 1;
    }

    /**
     * 
     * 
     * @return 
     */
    public static int getMaxWeekofMonth(int year, int month) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, 1, 0, 0, 0);
        return calendar.getActualMaximum(Calendar.WEEK_OF_MONTH);
    }

    /**
     * ，YYYY-MM-DD
     * 
     * @return ，YYYY-MM-DD
     */
    public static String Date() {
        Calendar calendar = Calendar.getInstance();
        StringBuffer date = new StringBuffer();
        date.append(calendar.get(Calendar.YEAR));
        date.append('-');
        date.append(calendar.get(Calendar.MONTH) + 1);
        date.append('-');
        date.append(calendar.get(Calendar.DAY_OF_MONTH));
        return date.toString();
    }

    /**
     * ，YYYY-MM-DD HH:MM:SS
     * 
     * @return ，YYYY-MM-DD HH:MM:SS
     */
    public static String DateTime() {
        Calendar calendar = Calendar.getInstance();
        StringBuffer date = new StringBuffer();
        date.append(calendar.get(Calendar.YEAR));
        date.append('-');
        date.append(calendar.get(Calendar.MONTH) + 1);
        date.append('-');
        date.append(calendar.get(Calendar.DAY_OF_MONTH));
        date.append(' ');
        date.append(calendar.get(Calendar.HOUR_OF_DAY));
        date.append(':');
        date.append(calendar.get(Calendar.MINUTE));
        date.append(':');
        date.append(calendar.get(Calendar.SECOND));
        return date.toString();
    }

    /**
     * 2
     * 
     * @param startTime
     *            
     * @param endTime
     *            
     * @return 2。>0：startTime>endTime 0:startTime=endTime
     *         <0:startTime<endTime
     * @throws ParseException
     */
    public static int compareTwoDate(String startTime, String endTime) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date b = formatter.parse(startTime);
        Date c = formatter.parse(endTime);
        return b.compareTo(c);

    }

    /**
     * 2
     * 
     * @param startTime
     *            
     * @param endTime
     *            
     * @return 2。>0：startTime>endTime 0:startTime=endTime
     *         <0:startTime<endTime
     * @throws ParseException
     */
    public static int compareTwoDate(Date endTime, Date startTime) {

        java.util.Calendar c1 = java.util.Calendar.getInstance();

        java.util.Calendar c2 = java.util.Calendar.getInstance();

        c1.setTime(endTime);

        c2.setTime(startTime);

        int result = c1.compareTo(c2);

//        if (result == 0)
//
//            System.out.println("");
//
//        else if (result < 0)
//
//            System.out.println("");
//
//        else
//
//            System.out.println("");
        return result;
    }

    /**
     * 
     * 
     * @param nowSysDateTime
     *            
     * @param startTime
     *            
     * @param endTime
     *            
     * @return nowSysDateTimestartTimeendTimetrue
     * @throws ParseException
     */
    public static boolean compareThreeDate(String nowSysDateTime, String startTime, String endTime) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date b = formatter.parse(startTime);
        Date a = formatter.parse(nowSysDateTime);
        Date c = formatter.parse(endTime);
        if (a.compareTo(b) >= 0 && a.compareTo(c) <= 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * / 20021 (2002,1,-1) =2001.
     * 
     * @param year
     *            
     * @param month
     *            
     * @param pastMonth
     *            ,,
     * @return 
     */
    public static int getYearPastMonth(int year, int month, int pastMonth) {
        return year + (int) Math.floor((double) (month - 1 + pastMonth) / (double) 12);
    }

    /**
     * .
     * 
     * @param month
     *            
     * @param pastMonth
     *            
     * @return 
     */
    public static int getMonthPastMonth(int month, int pastMonth) {
        return ((12 + month - 1 + pastMonth) % 12) + 1;
    }

    /**
     * . 0.1,2,3,4.
     * 
     * @param nMonth
     *            int
     * @return int
     */
    public static int getQuarterbyMonth(int nMonth) {
        final int[] monthQuarters = { 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4 };

        if (nMonth >= 0 && nMonth <= 12) {
            return monthQuarters[nMonth];
        } else {
            return 0;
        }
    }

    /**
     * .
     * 
     * @return java.sql.Date
     */
    public static java.sql.Date getNowSqlDate() {
        java.util.Date aDate = new java.util.Date();
        return new java.sql.Date(aDate.getTime());
    }

    /**
     * .
     * 
     * @return java.util.Date
     */
    public static java.util.Date getNowDate() {
        return Calendar.getInstance().getTime();
    }

    /**
     * .
     * 
     * @return java.sql.Time
     */
    public static java.sql.Timestamp getNowTimestamp() {
        return new java.sql.Timestamp(new java.util.Date().getTime());
    }

    /**
     * ,yyyy-MM-dd HH:mm.
     * 
     * @param aTime
     *            
     * @return String
     */
    public static String getTimeShow(java.sql.Timestamp aTime) {
        if (null == aTime) {
            return "";
        }
        SimpleDateFormat sdfTemp = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        return sdfTemp.format(aTime);
    }

    /**
     * .
     * 
     * @param aTime
     *            
     * @param aFormat
     *            SimpleDateFormat
     * @return 
     */
    public static String getSelfTimeShow(java.sql.Timestamp aTime, String aFormat) {
        if (null == aTime) {
            return "";
        }
        SimpleDateFormat sdfTemp = new SimpleDateFormat(aFormat, Locale.US);
        return sdfTemp.format(aTime);
    }

    /**
     * .
     * 
     * @param aTime
     *            
     * @param aFormat
     *            SimpleDateFormat
     * @return 
     */
    public static String getSelfTimeShow(java.sql.Date aTime, String aFormat) {
        if (null == aTime) {
            return "";
        }
        SimpleDateFormat sdfTemp = new SimpleDateFormat(aFormat, Locale.US);
        return sdfTemp.format(aTime);
    }

    /**
     * .
     * 
     * @param year
     *            
     * @param month
     *            
     * @return 
     */
    public static int getDayinMonth(int year, int month) {
        final int[] dayNumbers = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        int result;
        if ((month == 2) && ((year % 4) == 0) && ((year % 100) != 0) || ((year % 400) == 0)) {
            result = 29;
        } else {
            result = dayNumbers[month - 1];
        }
        return result;
    }

    /**
     * .
     * 
     * @param ayear
     *            
     * @param amonth
     *            
     * @param aday
     *            
     * @return 0,-1,1
     */
    public static int validDate(int ayear, int amonth, int aday) {
        int isGood = 0;
        if ((ayear == 0) || (amonth == 0) || (aday == 0)) {
            isGood = 1;
        } else {
            int monthDays = getDayinMonth(ayear, amonth);
            if ((aday < 1) || (aday > monthDays)) {
                isGood = -1;
            }
        }
        return isGood;
    }

    /**
     * .
     * 
     * @param syear
     *            
     * @param smonth
     *            
     * @param sday
     *            
     * @return 0,-1,1
     */
   /* public static int validDate(String syear, String smonth, String sday) {
        int ayear, amonth, aday;
        ayear = StringUtil.myparseInt(syear, 0);
        amonth = StringUtil.myparseInt(smonth, 0);
        aday = StringUtil.myparseInt(sday, 0);
        return validDate(ayear, amonth, aday);
    }*/

    /**
     * : 2003-9-5.
     * 
     * @param aDateStr
     *            
     * @return 0,-1,1
     */
  /*  public static int validDate(String aDateStr) {
        if (StringUtil.isTrimEmpty(aDateStr)) {
            return 1;
        }
        String[] aObj = StringUtil.splitString("/-/", aDateStr);
        if (null == aObj) {
            return 1;
        }
        return validDate(aObj[0], aObj[1], aObj[2]);
    }
*/
    /**
     * .
     * 
     * @param nHour
     *            int
     * @param nMin
     *            int
     * @param nSec
     *            int
     * @return int 0,-1,1
     */
    public static int validTime(int nHour, int nMin, int nSec) {
        int isGood = 0; // normal
        if ((nHour == 0) || (nMin == 0) || (nSec == 0)) {
            isGood = 1; // empty
        } else {
            if ((nHour > 23 || nHour < 0 || nMin > 59 || nMin < 0 || nSec > 59 || nSec < 0)) {
                isGood = -1; // invalid
            }
        }
        return isGood;
    }

    /**
     * : 2003-9-5 13:52:5.
     * 
     * @param aDateTimeStr
     *            
     * @return 0,-1,1
     */
  /*  public static int validDateTime(String aDateTimeStr) {
        if (StringUtil.isTrimEmpty(aDateTimeStr)) {
            return 1;
        }
        String[] aObj = StringUtil.splitString("/ /", aDateTimeStr);
        if (null == aObj) {
            return 1;
        }
        if (aObj.length != 2) {
            return 1;
        }
        if (validDate(aObj[0]) == 0) {
            String[] aTimeObj = StringUtil.splitString("/:/", aObj[1]);
            if (aTimeObj.length == 3) {
                int nHour = StringUtil.myparseInt(aTimeObj[0], 0);
                int nMin = StringUtil.myparseInt(aTimeObj[0], 0);
                int nSec = StringUtil.myparseInt(aTimeObj[0], 0);
                return validTime(nHour, nMin, nSec);
            }
        }
        return -1;
    }*/

    /**
     * .
     * 
     * @param syear
     *            
     * @param smonth
     *            
     * @param sday
     *            
     * @return true
     */
   /* public static boolean isEmptyDate(String syear, String smonth, String sday) {
        boolean isEmpty = false;
        int ayear, amonth, aday;
        ayear = StringUtil.myparseInt(syear, 0);
        amonth = StringUtil.myparseInt(smonth, 0);
        aday = StringUtil.myparseInt(sday, 0);

        if ((ayear == 0) || (amonth == 0) || (aday == 0)) {
            isEmpty = true;
        }
        return isEmpty;
    }*/

    /**
     * .
     * 
     * @param ayear
     *            
     * @param amonth
     *            
     * @param aday
     *            
     * @return true
     */
    public static boolean isEmptyDate(int ayear, int amonth, int aday) {
        boolean isEmpty = false;
        if ((ayear == 0) || (amonth == 0) || (aday == 0)) {
            isEmpty = true;
        }
        return isEmpty;
    }

    /**
     * /.
     * 
     * @param nSecs
     *            
     * @return Timestamp
     */
    public static java.sql.Timestamp getPastTime(int nSecs) {
        java.sql.Timestamp ts1 = getNowTimestamp();
        java.sql.Timestamp ts2;
        ts2 = new java.sql.Timestamp(ts1.getTime() - nSecs * 1000);
        return ts2;
    }

    /**
     * .
     * 
     * @param aTime
     *            
     * @param nSecs
     *            :
     * @return Timestamp
     */
    public static java.sql.Timestamp getPastTime(java.sql.Timestamp aTime, int nSecs) {
        java.sql.Timestamp ts2;
        ts2 = new java.sql.Timestamp(aTime.getTime() - nSecs * 1000);
        return ts2;
    }

    /**
     * aDate.
     * 
     * @param aDate
     *            
     * @return true
     */
    public static boolean isToday(java.sql.Date aDate) {
        Calendar aCal1 = Calendar.getInstance();
        aCal1.setTime(aDate);

        java.sql.Date date1 = getNowSqlDate();

        Calendar aCal2 = Calendar.getInstance();
        aCal2.setTime(date1);

        return ((aCal1.get(Calendar.DATE) == aCal2.get(Calendar.DATE)) && (aCal1.get(Calendar.YEAR) == aCal2.get(Calendar.YEAR)) && (aCal1.get(Calendar.MONTH) == aCal2
                .get(Calendar.MONTH)));
    }

    /**
     * long. ,.
     * 
     * @param str
     *            
     * @param pattern
     *            
     * @throws NullPointerException
     * @return long
     */
    public static Long str2DateTime(String str, String pattern) {
        DateFormat dateFmt = new SimpleDateFormat(pattern, Locale.US);
        Calendar calendar = Calendar.getInstance();
        try {
            calendar.setTime(dateFmt.parse(str));
            // return c.getTimeInMillis();
            return new Long(calendar.getTime().getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * long.
     * 
     * @param strTemp
     *            String
     * @return long
     */
    public static Long dateStr2Time(String strTemp) {
        if (null == strTemp || strTemp.length() < 8) {
            return null;
        }
        String sSign = strTemp.substring(4, 5);
        String sPattern = new StringBuffer("yyyy").append(sSign).append("MM").append(sSign).append("dd").toString();
        return str2DateTime(strTemp, sPattern);
    }

    /**
     * long.  2004-5-6 23:52:22 ,
     * 
     * @param strTemp
     *            String
     * @return long
     */
    public static Long dateTimeStr2Time(String strTemp) {
        if (null == strTemp || strTemp.length() < 8) {
            return null;
        }
        String sSign = strTemp.substring(4, 5);
        String sPattern = new StringBuffer("yyyy").append(sSign).append("MM").append(sSign).append("dd").append(" hh:mm:ss").toString();

        Long aLong = str2DateTime(strTemp, sPattern);
        if (null == aLong) {
            String sShortPattern = new StringBuffer("yyyy").append(sSign).append("MM").append(sSign).append("dd").append(" hh:mm").toString();
            aLong = str2DateTime(strTemp, sShortPattern);
        }
        return aLong;
    }

    /**
     * 2003-10-11,,.
     * 
     * @param aStr
     *            ,2003-11-11
     * @return Timestamp
     */
    public static java.sql.Timestamp dateStr2Timestamp(String aStr) {
        Long temp = dateStr2Time(aStr);
        if (null == temp) {
            return null;
        }
        return new java.sql.Timestamp(temp.longValue());
    }

    /**
     * 2003-10-11,,.
     * 
     * @param aStr
     *            ,2003-11-11
     * @return Date
     */
    public static java.util.Date dateStr2Date(String aStr) {
        Long result = dateStr2Time(aStr);
        if (null == result) {
            return null;
        }
        return new java.sql.Date(result.longValue());

        // version 1 for check 2004.6.26 by scud

        // Calendar aSJ = Calendar.getInstance(); aSJ.setTime(new
        // java.util.Date()); if (StrFunc.calcCharCount('-', aStr) >= 2) { int
        // aYear, aMonth, aDay; String[] aObj = StrFunc.splitString("/-/",
        // aStr); aYear = StrFunc.myparseInt(aObj[0]); aMonth =
        // StrFunc.myparseInt(aObj[1]) - 1; aDay = StrFunc.myparseInt(aObj[2]);
        // if (aYear > 0 && aMonth > -1 && aDay > -1) { aSJ.set(aYear, aMonth,
        // aDay); } } return new java.sql.Date(aSJ.getTime().getTime());
    }

    /**
     * 2003-10-11 23:43:55,,.
     * 
     * @param aStr
     * @return Date
     */
    public static java.util.Date timeStr2Date(String aStr) {
        Long result = dateTimeStr2Time(aStr);
        if (null == result) {
            return null;
        }
        return new java.sql.Date(result.longValue());
    }

    /**
     * 2003-10-11 23:43:55,,.
     * 
     * @param aStr
     *            
     * @return Timestamp
     */
    public static java.sql.Timestamp dateTimeStr2Timestamp(String aStr) {
        Long tempVar = dateTimeStr2Time(aStr);
        if (null == tempVar) {
            return null;
        }
        return new java.sql.Timestamp(tempVar.longValue());
    }

    /**
     * ,0:0:0. ,getFormDate.
     * 
     * @param aStr
     *            String
     * @return Timestamp
     */
   /* public static java.sql.Timestamp dateStr2BeginDateTime(String aStr) {
        if (StringUtil.isTrimEmpty(aStr)) {
            return null;
        } else {
            return dateTimeStr2Timestamp(aStr + " 0:0:0");
        }
    }*/

    /**
     * ,23:59:59. ,getFormDate.
     * 
     * @param aStr
     *            String
     * @return Timestamp
     */
    /*public static java.sql.Timestamp dateStr2EndDateTime(String aStr) {
        if (StringUtil.isTrimEmpty(aStr)) {
            return null;
        } else {
            return dateTimeStr2Timestamp(aStr + " 23:59:59");
        }
    }*/

    /**
     * .
     * 
     * @param aDate
     *            
     * @return 
     */
    public static int getYearFromDate(java.util.Date aDate) {
        Calendar cFF = Calendar.getInstance();
        cFF.setTime(aDate);
        return cFF.get(Calendar.YEAR);
    }

    /**
     * .
     * 
     * @param aDate
     *            
     * @return 
     */
    public static int getMonthFromDate(java.util.Date aDate) {
        Calendar cFF = Calendar.getInstance();
        cFF.setTime(aDate);
        return cFF.get(Calendar.MONTH) + 1;
    }

    /**
     * .
     * 
     * @param aDate
     *            
     * @return 
     */
    public static int getDAYFromDate(java.util.Date aDate) {
        Calendar cFF = Calendar.getInstance();
        cFF.setTime(aDate);
        return cFF.get(Calendar.DATE);
    }

    /**
     * .
     * 
     * @param aDate
     *            
     * @return 
     */
    public static int getHourFromDate(java.util.Date aDate) {
        Calendar cFF = Calendar.getInstance();
        cFF.setTime(aDate);
        return cFF.get(Calendar.HOUR_OF_DAY);
    }

    /**
     * .
     * 
     * @param aDate
     *            
     * @return 
     */
    public static int getMinuteFromDate(java.util.Date aDate) {
        Calendar cFF = Calendar.getInstance();
        cFF.setTime(aDate);
        return cFF.get(Calendar.MINUTE);
    }

    /**
     * .
     * 
     * @param aDate
     *            
     * @return 
     */
    public static int getWeekFromDate(java.util.Date aDate) {
        Calendar cFF = Calendar.getInstance();
        cFF.setTime(aDate);
        return cFF.get(Calendar.DAY_OF_WEEK);
    }

    /**
     * .
     * 
     * @param year
     *            
     * @param month
     *            
     * @return 
     */
    public static int getFirstDayOfWeek(Integer year, Integer month) {
        Calendar cFF = Calendar.getInstance();
        cFF.set(Calendar.YEAR, year);
        cFF.set(Calendar.MONTH, month - 1);
        cFF.set(Calendar.DATE, 1);
        return cFF.get(Calendar.DAY_OF_WEEK) - 1;
    }

    /**
     * 
     * 
     * @param compMillSecond
     *             1970  1  1 
     * @return :367Day 59H 56Min
     */
    public static String diff(long compMillSecond) {
        long diff = System.currentTimeMillis() - compMillSecond;
        long day = diff / ONE_DAY;
        long hour = (diff % ONE_DAY) / ONE_HOUR;
        long min = ((diff % ONE_DAY) % ONE_HOUR) / ONE_MIN;
        return String.valueOf(day) + " Days " + String.valueOf(hour) + " Hours " + String.valueOf(min) + " Mins ";
    }

    /**
     * 
     * 
     * @param overdate
     * @return
     */
    public static String getIntevalDays(Date overdate) {
        String temp = null;
        Date nowdate = new Date();
        long nowlong = nowdate.getTime();
        long overlong = overdate.getTime();
        long templong = overlong - nowlong;
        long day = templong / 1000 / 60 / 60 / 24;
        temp = String.valueOf(day);
        if (overdate.getTime() < nowdate.getTime()) {
            return "-1";
        }
        return temp;
    }

    /**
     * 2
     * 
     * @param beforeDate
     *            
     * @param afterDate
     *            
     * @return 
     */
    public static Integer getIntevalDays(Date beforeDate, Date afterDate) {
        Integer temp = -1;
        long beforeLong = beforeDate.getTime();
        long afterLong = afterDate.getTime();
        if (beforeLong < afterLong) {
            long templong = afterLong - beforeLong;
            long day = templong / 1000 / 60 / 60 / 24;
            temp = Integer.valueOf(String.valueOf(day));
        }
        return temp;
    }

    /**
     * 
     * 
     * @param overdate
     * @return
     */
    public static long getIntevalMinutes(Date overdate) {
        Date nowdate = new Date();
        long nowlong = nowdate.getTime();
        long overlong = overdate.getTime();
        long templong = nowlong - overlong;
        long hour = templong / 1000 / 60 / 60 / 24;
        templong = templong - hour * 60 * 60 * 1000;
        // 
        long second = templong / 1000;
        if (overdate.getTime() > nowdate.getTime()) {
            return 0;
        }
        return second;
    }

    /**
     * 
     * 
     * @param date
     *            
     * @param days
     *            
     * @return 
     */
    public static synchronized Date getDayAfterDate(Date date, int days) {
        GregorianCalendar gc = (GregorianCalendar) Calendar.getInstance();
        gc.setTime(date);
        gc.add(Calendar.DAY_OF_YEAR, days);
        return gc.getTime();
    }

    public static java.util.Date toDateFmt(String sDate) {
        return toDate(sDate, DATE_FMT_1);
    }

    /**
     * 
     * 
     * @return
     */
    public static Date getWeekStartDate() {
        Calendar calendar = Calendar.getInstance();
        Date firstDateOfWeek;
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        calendar.add(Calendar.DAY_OF_WEEK, -(dayOfWeek - 1));
        firstDateOfWeek = calendar.getTime();
        calendar.add(Calendar.DAY_OF_WEEK, 6);
        return firstDateOfWeek;
    }

    /**
     * 
     * 
     * @return
     */
    public static Date getWeekEndDate() {
        Calendar calendar = Calendar.getInstance();
        Date lastDateOfWeek;
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        calendar.add(Calendar.DAY_OF_WEEK, -(dayOfWeek - 1));
        calendar.add(Calendar.DAY_OF_WEEK, 6);
        lastDateOfWeek = calendar.getTime();
        return lastDateOfWeek;
    }

    /**
     * 
     * 
     * @return Date YYYY-MM-DD 00:00:00
     */
    public static Date getMonthStartDate() {
        java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd");
        GregorianCalendar gc = (GregorianCalendar) Calendar.getInstance();
        gc.setTime(new Date(System.currentTimeMillis()));
        gc.set(Calendar.DAY_OF_MONTH, 1);
        return toDayStartDate(df.format(gc.getTime()));
    }

    /**
     * 
     * 
     * @return Date YYYY-MM-DD 23:59:59
     */
    public static Date getMonthEndDate() {
        java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date(System.currentTimeMillis()));
        cal.add(Calendar.MONTH, 1);
        cal.set(Calendar.DATE, 1);
        cal.add(Calendar.DATE, -1);
        return toDayEndDate(df.format(cal.getTime()));
    }

    /**
     * 
     * 
     * @return
     */
    public static String getAfterHour() {
        SimpleDateFormat forma = new SimpleDateFormat("HHmmss");
        java.util.Calendar Cal = java.util.Calendar.getInstance();
        Cal.setTime(new Date());
        Cal.add(java.util.Calendar.HOUR_OF_DAY, +1);

        return forma.format(Cal.getTime());

    }
    
    public static String getAfterMin(long now, int minute) {
        SimpleDateFormat forma = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
        java.util.Calendar Cal = java.util.Calendar.getInstance();
        Cal.setTime(new Date(now));
        Cal.add(java.util.Calendar.MINUTE, + minute);

        return forma.format(Cal.getTime());

    }

    /**
     * 
     * 
     * @return
     */
    public static String getSysdateNow() {
        return toString(new java.util.Date(System.currentTimeMillis()), "HHmmss");
    }

    /**
     * get system date string
     * 
     * @return the formated string of system date
     */
    public static String getSysdate0() {
        return toString(new java.util.Date(System.currentTimeMillis()), DATE_FMT_0);
    }

    /**
     * 
     * 
     * @param d
     * @return
     */
    public static String date2String(Date d) {
        SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd ");
        String result = format1.format(d);
        return result;
    }

    /**
     * 
     * 
     * @param d
     * @return
     */
    public static String dateYmdString(Date d) {
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd ");
        String result = format1.format(d);
        return result;
    }

    /**
     * 
     * 
     * @param d
     * @return
     */
    public static Date String2Date(String d) {
        try {
            SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
            Date result = format1.parse(d);
            return result;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    /**
     * 
     * 
     * @param str
     * @return
     */
    public static int monthDays(String str) {

        Calendar c = Calendar.getInstance();
        int year = Integer.parseInt(str.substring(0, 4));
        int month = Integer.parseInt(str.substring(5, 7)) - 1;
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        int i = c.getActualMaximum(Calendar.DAY_OF_MONTH);
        return i;
    }

    /**
     * yyyy-MM-dd
     * 
     * @param d
     * @return
     */
   /* public static String getYear(Date d) {
        String s = DateUtils.date2String(d);
        String result = s.substring(0, 4);
        return result;
    }*/

    /**
     * yyyy-MM-dd
     * 
     * @param d
     * @return
     */
   /* public static String getMonth(Date d) {
        String s = DateUtils.date2String(d);
        String result = s.substring(5, 7);
        return result;
    }*/

    /**
     * yyyy-MM-dd
     * 
     * @param d
     * @return
     */
  /*  public static String getDay(Date d) {
        String s = DateUtils.date2String(d);
        String result = s.substring(8, 10);
        return result;
    }*/

    /**
     * yyyy-MM-dd:HH:mm:ss
     * 
     * @param d
     * @return
     */
    public static String formateDate(Date d) {
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String result = format1.format(d);
        return result;
    }

    /**
     * 
     * 
     * @param d
     * @return
     * @throws ParseException
     */
    /**
     * 
     * 
     * @param d
     * @return
     * @throws ParseException
     */
    public static Date formateStr(String d) {
        Date str = null;
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            str = format1.parse(d);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return str;
    }

    /**
     * yyyy-MM-dd:HH:mm:ss
     * 
     * @param d
     * @return
     */
    public static String formatDateToStr(Date d, String format) {
        SimpleDateFormat format1 = new SimpleDateFormat(format);
        String result = format1.format(d);
        return result;
    }

    public static String getAfterDay(int day) {
        Date date = new Date();
        GregorianCalendar gc = (GregorianCalendar) Calendar.getInstance();
        gc.setTime(date);
        gc.add(Calendar.DATE, day);
        String value = doTransform(toString(gc.getTime(), getOraExtendDateTimeFormat()));
        return value;

    }

    public static Date gethours(String time) {
        Date date = null;
        SimpleDateFormat hours = new SimpleDateFormat("HH:mm:ss");
        try {
            date = hours.parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return date;

    }

    public static String fromDateToString(Date date) {
        String str = null;
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            str = inputFormat.format(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return str;
    }

    public static long fromDateStringToLong(String inVal) { // 
        Date date = new Date(); // 
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            date = inputFormat.parse(inVal); // 
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date.getTime(); // 
    }

    @SuppressWarnings({ "deprecation", "unused" })
	private static String dqsj() { // （ 2007-11-6 15:10:58）
        Date date = new Date(); // 
        String today = date.toLocaleString(); // 
        // System.out.println(" "+today); //
        return today; // 
    }

   /* public static long getCountSsTime(String Sendtime) {

        long endT = fromDateStringToLong(DateUtils.getSystemCurrentDateTime()); // 
        long startT = fromDateStringToLong(Sendtime); // 
        long ss = (endT - startT) / (1000); // 
        return ss;
    }*/

    public static String getTime(String endtime, String begtime) {// 
                                                                  // ，

        long endT = fromDateStringToLong(endtime); // 
        long startT = fromDateStringToLong(begtime); // 

        long ss = (endT - startT) / (1000); // 
        // System.out.println(ss);
        int MM = (int) ss / 60; // 
//        int hh = (int) ss / 3600; // 
//        int dd = (int) hh / 24; // 

        // System.out.println("" + dd + " ：" + hh + "  " + MM + "  "
        // + ss + "  ：" + ss * 1000 + " ");
        String msg = "";

        if (MM >= 1440) { // 1
            int min = MM % 1440;// 
            String mi = min / 60 + "" + min % 60 + "";// ，
            msg = MM / 1440 + "" + mi;// ，，
        }
        if (MM < 60) {// 1
            msg = MM + "";
        }
        if (MM >= 60 && MM < 1440) { // ，
            msg = MM / 60 + "" + MM % 60 + "";
        }
        msg = String.valueOf(ss);
        return msg;
    }

    public static String getTimedifference(String beginTime, String endTime) {

        String differenceTim = "";
        SimpleDateFormat dfs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        try {
            java.util.Date begin = dfs.parse(beginTime);
            java.util.Date end = dfs.parse(beginTime);
            long between = (end.getTime() - begin.getTime()) / 1000;// 1000
            long day1 = between / (24 * 3600);
            long hour1 = between % (24 * 3600) / 3600;
            long minute1 = between % 3600 / 60;
            long second1 = between % 60 / 60;
            differenceTim = "" + day1 + "" + hour1 + "" + minute1 + "" + second1 + "";

        } catch (ParseException e) {

            e.printStackTrace();
        }
        return differenceTim;

    }

    public static String getGmtDate(Date date) {

        SimpleDateFormat f = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", java.util.Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("GMT"));
        return f.format(date);
    }

    public static int getMothofDay() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, getYearFromDate(new Date()));
        cal.set(Calendar.MONTH, getMonthFromDate(new Date()));
        int maxDate = cal.getActualMaximum(Calendar.DATE);
        return maxDate;
    }

    /**
     * 
     * 
     * @param day
     * @return
     */
    public static long getafterMonthFromSecond(int month) {
        Calendar cFF = Calendar.getInstance();
        cFF.setTime(new Date());
        cFF.add(Calendar.MONTH, month);
        long begin = new Date().getTime();
        long second = (cFF.getTime().getTime() - begin) / 1000;
        return second;
    }

    /**
     * 
     * 
     * @param day
     * @return
     */
    public static Date getafterMonthFromDate(int month) {
        Calendar cFF = Calendar.getInstance();
        cFF.setTime(new Date());
        cFF.add(Calendar.MONTH, month);

        return cFF.getTime();
    }

    /****************************** add **************************************/
    /**
     * 
     * 
     * @param date
     * @param pattern
     * @return
     */
    public static Date toDate(String date, String pattern) {
        if (("" + date).equals("")) {
            return null;
        }
        if (pattern == null) {
            pattern = "yyyy-MM-dd";
        }
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        Date newDate = new Date();
        try {
            newDate = sdf.parse(date);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return newDate;
    }

    /**
     * 
     * 
     * @param date
     * @param pattern
     * @return
     */
    public static String toString(Date date, String pattern) {
        if (date == null) {
            return "";
        }
        if (pattern == null) {
            pattern = "yyyy-MM-dd";
        }
        String dateString = "";
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        try {
            dateString = sdf.format(date);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return dateString;
    }

    /**
     * 
     * 
     * @return
     */
    public static String[] getLastMonth() {
        // 
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;

        // 
        cal.set(Calendar.DAY_OF_MONTH, 1);

        // ,
        cal.add(Calendar.DAY_OF_MONTH, -1);

        // 
        int day = cal.get(Calendar.DAY_OF_MONTH);

        String months = "";
        String days = "";

        if (month > 1) {
            month--;
        } else {
            year--;
            month = 12;
        }
        if (!(String.valueOf(month).length() > 1)) {
            months = "0" + month;
        } else {
            months = String.valueOf(month);
        }
        if (!(String.valueOf(day).length() > 1)) {
            days = "0" + day;
        } else {
            days = String.valueOf(day);
        }
        String firstDay = "" + year + "-" + months + "-01";
        String lastDay = "" + year + "-" + months + "-" + days;

        String[] lastMonth = new String[2];
        lastMonth[0] = firstDay;
        lastMonth[1] = lastDay;

        // System.out.println(lastMonth[0] + "||" + lastMonth[1]);
        return lastMonth;
    }

    /**
     * 
     * 
     * @return
     */
    public static String[] getCurrentMonth() {
        // 
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;

        // 
        cal.set(Calendar.DAY_OF_MONTH, 1);

        // ,
        cal.add(Calendar.DAY_OF_MONTH, -1);

        // 
        int day = cal.get(Calendar.DAY_OF_MONTH);

        String months = "";
        String days = "";

        if (!(String.valueOf(month).length() > 1)) {
            months = "0" + month;
        } else {
            months = String.valueOf(month);
        }
        if (!(String.valueOf(day).length() > 1)) {
            days = "0" + day;
        } else {
            days = String.valueOf(day);
        }
        String firstDay = "" + year + "-" + months + "-01";
        String lastDay = "" + year + "-" + months + "-" + days;

        String[] currentMonth = new String[2];
        currentMonth[0] = firstDay;
        currentMonth[1] = lastDay;

        // System.out.println(lastMonth[0] + "||" + lastMonth[1]);
        return currentMonth;
    }

    public static int getDateline() {

        return (int) (System.currentTimeMillis() / 1000);
    }

    public static int getDateline(String date) {
        return (int) (toDate(date, "yyyy-MM-dd").getTime() / 1000);
    }

    // lzf ，int2038-01-19，
    public static long getDatelineLong() {

        return (long) (System.currentTimeMillis() / 1000);
    }

    public static long getDatelineLong(String date) {
        return (long) (toDate(date, "yyyy-MM-dd").getTime() / 1000);
    }

    public static final String Format = "yyyy-MM-dd";

    /**
     * ，yyyy-MM-dd
     * 
     * @param format
     *            ，yyyy-MM-dd
     * @return 
     */
    public String getDate(String format) {

        if (format == null || format.trim().length() == 0)
            format = Format;

        SimpleDateFormat sdf = new SimpleDateFormat(format);

        return sdf.format(Calendar.getInstance().getTime());
    }

    /**
     * Date，yyyy-MM-dd
     * 
     * @param s
     *            
     * @param format
     *            ，yyyy-MM-dd
     * @return 
     */
    public static Date parse(String s, String format) {

        if (format == null || format.trim().length() == 0)
            format = Format;
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        try {
            return sdf.parse(s);
        } catch (Exception e) {

            return null;
        }
    }

    public static java.util.Date timeStr2Time(String aStr) throws ParseException {
        DateFormat sdf;
        if (aStr.length() >= 8) {
            sdf = new SimpleDateFormat("HH:mm:ss");
        } else {
            sdf = new SimpleDateFormat("HH:mm");
        }
        Date date = sdf.parse(aStr);
        return date;
    }

    public static java.util.Date timeStr2TimeHHMM(String aStr) throws ParseException {
        DateFormat sdf = new SimpleDateFormat("HH:mm");
        Date date = sdf.parse(aStr);
        return date;
    }

    /**
     * datestring yyyy-MM-dd HH:mm:ss
     * 
     * @return
     */
    public static String dateToString(Date date, String fmt) {

        SimpleDateFormat sdf = new SimpleDateFormat(fmt);
        return sdf.format(date);
    }

    public static String dateToString(Date date, String fmt, Locale locale) {
        SimpleDateFormat sdf = null;
        if ("en".equals(locale.getLanguage())) {
            sdf = new SimpleDateFormat(fmt, Locale.ENGLISH);
        } else {
            sdf = new SimpleDateFormat(fmt);
        }
        String temp = sdf.format(date);
        if (temp.indexOf("September") != -1) {
            temp = temp.replace("September", "Sept");
        }
        if (temp.indexOf("October") != -1) {
            temp = temp.replace("October", "Octo");
        }
        if (temp.indexOf("November") != -1) {
            temp = temp.replace("November", "Nove");
        }
        if (temp.indexOf("December") != -1) {
            temp = temp.replace("December", "Dece");
        }
        if (temp.indexOf("January") != -1) {
            temp = temp.replace("January", "Janu");
        }
        if (temp.indexOf("February") != -1) {
            temp = temp.replace("February", "Febr");
        }
        return temp;
    }

    /**
     * datestring yyyy-MM-dd HH:mm:ss
     * 
     * @return
     */
    public static String DateToString(Date date) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(date);
    }

    /**
     * datestring yyyy-MM-dd HH:mm:ss
     * 
     * @return
     */
    public static String DateToString(Date date, String format) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
    }

    /**
     * 
     * 
     * @param birthDay
     *            
     * @return
     * @throws Exception
     */
    public static int getAge(Date birthDay) throws Exception {
        Calendar cal = Calendar.getInstance();
        if (cal.before(birthDay)) {
            throw new IllegalArgumentException("The birthDay is before Now.It's unbelievable!");
        }
        int yearNow = cal.get(Calendar.YEAR);
        int monthNow = cal.get(Calendar.MONTH);
        int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);
        cal.setTime(birthDay);
        int yearBirth = cal.get(Calendar.YEAR);
        int monthBirth = cal.get(Calendar.MONTH);
        int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);
        int age = yearNow - yearBirth;
        if (monthNow <= monthBirth) {
            if (monthNow == monthBirth) {
                if (dayOfMonthNow < dayOfMonthBirth) {
                    age--;
                }
            } else {
                age--;
            }
        }
        return age;
    }

    /**
     * 
     * 
     * @param d1
     * @param d2
     * @return
     */
    public static long getGapOfDays(Date d1, Date d2) {
        long days = 0;
        long time1 = d1.getTime();
        long time2 = d2.getTime();
        long diff;
        if (time1 < time2) {
            diff = time2 - time1;
        } else {
            diff = time1 - time2;
        }
        days = diff / (1000 * 60 * 60 * 24);
        return days;
    }

    // 
    private static int getMondayPlus() {
        Calendar cd = Calendar.getInstance();
        // ，，......
        int dayOfWeek = cd.get(Calendar.DAY_OF_WEEK) - 1; // 1
        if (dayOfWeek == 1) {
            return 0;
        } else {
            return 1 - dayOfWeek;
        }
    }

    // （0）
    public static String getdayOFWeek(int weekvalue) {

        int mondayPlus = getMondayPlus();
        GregorianCalendar currentDate = new GregorianCalendar();
        currentDate.add(GregorianCalendar.DATE, mondayPlus + weekvalue);
        Date monday = currentDate.getTime();

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String preMonday = df.format(monday);
        return preMonday;
    }

    // 
    public static String getPreviousWeekday() {

        int mondayPlus = getMondayPlus();
        GregorianCalendar currentDate = new GregorianCalendar();
        currentDate.add(GregorianCalendar.DATE, mondayPlus - 7);
        Date monday = currentDate.getTime();
        DateFormat df = DateFormat.getDateInstance();
        String preMonday = df.format(monday);
        return preMonday;
    }

    // 
    public static String getNextMonday() {
        int mondayPlus = getMondayPlus();
        GregorianCalendar currentDate = new GregorianCalendar();
        currentDate.add(GregorianCalendar.DATE, mondayPlus + 7);
        Date monday = currentDate.getTime();
        DateFormat df = DateFormat.getDateInstance();
        String preMonday = df.format(monday);
        return preMonday;
    }

    // 
    public static String getNextWeek(Date date) {
        GregorianCalendar currentDate = new GregorianCalendar();
        currentDate.setTime(date);
        currentDate.add(GregorianCalendar.DATE, 7);
        DateFormat df = DateFormat.getDateInstance();
        Date day = currentDate.getTime();
        String preday = df.format(day);
        return preday;
    }

    // 
    public static Date getNextWeekDate(Date date) {
        GregorianCalendar currentDate = new GregorianCalendar();
        currentDate.setTime(date);
        currentDate.add(GregorianCalendar.DATE, 7);
        // DateFormat df = DateFormat.getDateInstance();
        Date day = currentDate.getTime();

        return day;
    }

    // 
    public static List<String> circulateWeekSGetDate(int years, int months, int week) {
        // Object name[] = {"","", "", "", "", "", ""};
        Calendar cd = new GregorianCalendar(years, months - 1, 1);
        int dateNumber = cd.getActualMaximum(Calendar.DATE);
        int firstDay = cd.get(Calendar.DAY_OF_WEEK) - 1;
        int count = 1;
        List<String> list = new ArrayList<String>();
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                if (count > dateNumber) {
                    break;
                } else {
                    if ((i * 7 + j) < firstDay) {
                        continue;
                    } else {
                        if (j == week) {
                            String dateStr = years + "-" + months + "-" + count;
                            list.add(dateStr);
                        }
                    }
                    count++;
                }
            }
        }
        return list;
    }

    public static List<String> getMaxMONTH(int year, int month) {

        List<String> monthofDate = new ArrayList<String>();
        Calendar cd = Calendar.getInstance();
        cd.set(Calendar.YEAR, year);// 
        cd.set(Calendar.MONTH, month - 1);// 。
        int maxMONTH = cd.getActualMaximum(Calendar.DATE);
        for (int i = 1; i < maxMONTH + 1; i++) {
            String dateStr = year + "-" + (month) + "-" + i;
            monthofDate.add(dateStr);

        }
        return monthofDate;

    }

    // yearmonthday
    public static String getDayOfWeek(int year, int month, int day, ResourceBundle bundle) {
        String[] name = new String[] { bundle.getString("eppmanage.common.date.day_SUN"), bundle.getString("eppmanage.common.date.day_MON"),
                bundle.getString("eppmanage.common.date.day_TUE"), bundle.getString("eppmanage.common.date.day_WED"),
                bundle.getString("eppmanage.common.date.day_THU"), bundle.getString("eppmanage.common.date.day_FRI"),
                bundle.getString("eppmanage.common.date.day_SAT") };
        Calendar c = Calendar.getInstance();
        c.set(year, month - 1, day);
        return name[c.get(Calendar.DAY_OF_WEEK) - 1];

    }

    public static String getDayOfWeek(Date pTime, ResourceBundle bundle) {

        String[] name = new String[] { bundle.getString("eppmanage.common.date.day_SUN"), bundle.getString("eppmanage.common.date.day_MON"),
                bundle.getString("eppmanage.common.date.day_TUE"), bundle.getString("eppmanage.common.date.day_WED"),
                bundle.getString("eppmanage.common.date.day_THU"), bundle.getString("eppmanage.common.date.day_FRI"),
                bundle.getString("eppmanage.common.date.day_SAT") };
        Calendar c = Calendar.getInstance();
        c.setTime(pTime);

        return name[c.get(Calendar.DAY_OF_WEEK) - 1];

    }

    public static String getDayOfWeek(int weekofday, ResourceBundle bundle) {
        String[] name = new String[] { bundle.getString("eppmanage.common.date.day_MON"), bundle.getString("eppmanage.common.date.day_TUE"),
                bundle.getString("eppmanage.common.date.day_WED"), bundle.getString("eppmanage.common.date.day_THU"),
                bundle.getString("eppmanage.common.date.day_FRI"), bundle.getString("eppmanage.common.date.day_SAT"),
                bundle.getString("eppmanage.common.date.day_SUN") };

        return name[weekofday];

    }

    public static int dayForWeek(String pTime) throws Throwable {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date tmpDate = format.parse(pTime);
        Calendar cal = new GregorianCalendar();
        cal.setTime(tmpDate);
        return cal.get(Calendar.DAY_OF_WEEK) - 1;

    }

    public static int dayForWeek(Date pTime) {
        Calendar cal = new GregorianCalendar();
        cal.setTime(pTime);
        return cal.get(Calendar.DAY_OF_WEEK) - 1;
    }

    public static String getNextOrBackYearMonth(Date date, int pre) {
        String str = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.add(Calendar.MONTH, pre);// 
        cd.set(Calendar.DATE, 1);

        str = sdf.format(cd.getTime());
//        System.out.println(str);
        return str;
    }
    
    /**
     * 
     * 
     * @param date
     *            
     * @param min
     *            
     * @return 
     */
    public static synchronized Date getMinAfterDate(Date date, int min) {
        GregorianCalendar gc = (GregorianCalendar) Calendar.getInstance();
        gc.setTime(date);
        gc.add(Calendar.MINUTE, min);
        return gc.getTime();
    }

    /**
     * method is used to check date form richmedia analysis report count
     * @param accessDate
     * @return
     */
    public static int checkDate(Date accessDate) {
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_FMT_2);
        String today = formatter.format(new Date());
        String dbDate = formatter.format(accessDate);
        return today.compareTo(dbDate);
    }

    public static String getDateFmt1(Date date){
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_FMT_1);
        return formatter.format(date);
    }

}

