package com.java.date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ThirtyDaysBefore {
	
	static String getOldDate(int i){
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -i);
        Date toDate = cal.getTime();    
        String fromDate = dateFormat.format(toDate);
        return fromDate;
	}
	
	
	public static void main(String args[]){
		String[] dates = new String[31];
		int k = 0 ;
        for(int i=0;i<=30;i++){
        	String date = getOldDate(i);
        	//System.out.println(date);
        	dates[k++] = date;
        }
        
        for(String s: dates){
        	System.out.println(s);
        }
       
	}

}
