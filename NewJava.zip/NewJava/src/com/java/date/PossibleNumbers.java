package com.java.date;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class PossibleNumbers {

	public static String mappings[][] = { { "0" }, { "1" }, { "A", "B", "C" }, { "D", "E", "F" }, { "G", "H", "I" },
			{ "J", "K", "L" }, { "M", "N", "O" }, { "P", "Q", "R", "S" }, { "T", "U", "V" }, { "W", "X", "Y", "Z" } };

	public static void generateCombosHelper(List<String> combos, String prefix, String remaining) {
		// The current digit we are working with
		int digit = Integer.parseInt(remaining.substring(0, 1));

		if (remaining.length() == 1) {
			// We have reached the last digit in the phone number, so add
			// all possible prefix-digit combinations to the list
			for (int i = 0; i < mappings[digit].length; i++) {
				combos.add(prefix + mappings[digit][i]);
			}
		} else {
			// Recursively call this method with each possible new
			// prefix and the remaining part of the phone number.
			for (int i = 0; i < mappings[digit].length; i++) {
				generateCombosHelper(combos, prefix + mappings[digit][i], remaining.substring(1));
			}
		}
	}

	public static List<String> generateCombos(String phoneNumber) {
		// This will hold the final list of combinations
		List<String> combos = new LinkedList<String>();

		// Call the helper method with an empty prefix and the entire
		// phone number as the remaining part.
		generateCombosHelper(combos, "", phoneNumber);

		return combos;
	}

	public static void main(String[] args) {
		String phone = "01";
		List<String> combos = generateCombos(phone);

		for (String s : combos) {
			//System.out.println(s);
		}
		
		System.out.println(letterCombinations("01"));
		
		
		String[] str = {"andrew", "3", "andrew", "-2", "mike", "5", "andrew", "2" }; 
		System.out.println(get(6, str));
	}
	
	
	static String get(int a, String[] b){
		Map<String, Integer> map1 = new LinkedHashMap<String, Integer>();
		
		int max = 0;
		String key = "";
		
		for(int i=0;i<a/2;i++){
			
			String name = b[2*i];
			int val = Integer.parseInt(b[2*i+1]);
			
			if(map1.containsKey(name)){
				int v = map1.get(name);
				val +=v;
				map1.put(name, v+val);
			}else{
				map1.put(name, val);
			}
			if(val>max){
				max = val;
				key = name;
			}
		}

		return key;
	}
	
	
	public static ArrayList<String> letterCombinations(String digits) {
        ArrayList<String> res = new ArrayList<String>();
        ArrayList<String> preres = new ArrayList<String>();
        res.add("");

        for(int i = 0; i < digits.length(); i++) {
            String letters = map.get(digits.charAt(i));
            if (letters.length() == 0)
                continue;
            for(String str : res) {
                for(int j = 0; j < letters.length(); j++)
                    preres.add(str + letters.charAt(j));
            }
            res = preres;
            preres = new ArrayList<String>();
        }      
        return res;
    }

    static final HashMap<Character,String> map = new HashMap<Character,String>(){{
        put('1', "1");
        put('2',"abc");
        put('3',"def");
        put('4',"ghi");
        put('5',"jkl");
        put('6',"mno");
        put('7',"pqrs");
        put('8',"tuv");
        put('9',"wxyz");
        put('0', "0");
    }} ;


}
