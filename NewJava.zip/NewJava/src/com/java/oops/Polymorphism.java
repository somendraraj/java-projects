package com.java.oops;

public class Polymorphism {

	public int sum(int a, int b) {
		return a + b;
	}

	public String sum(String a, String b) {
		return String.valueOf(a) + String.valueOf(b);
	}

	public int sum(int a, int b, int c) {
		return a + b + c;
	}

	public static void main(String args[]) {
		Polymorphism obj = new Polymorphism();
		System.out.println(obj.sum(1, 2));
		System.out.println(obj.sum(1, 2, 3));
		System.out.println(obj.sum("1", "2"));
	}

}