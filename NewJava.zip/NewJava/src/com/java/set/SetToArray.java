package com.java.set;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.util.SystemOutLogger;

/**
 * simple method to put value of set to array
 * 
 * @author Somendra1.Raj
 *
 */
public class SetToArray {

	public static void main(String args[]) {

		Set<String> set = new HashSet();
		set.add("abcd");
		set.add("bcde");
		String[] atr = {"123", "12344"};
		System.out.println(set.addAll(atr));

		String[] arr = new String[set.size()];
		int i = 0;
		for (String s : set) {
			arr[i++] = s;
		}

		for (String s : arr) {
			System.out.print(s + " ");
		}
		
		/*using to array method*/
		System.out.println();
		String[] arr1 = set.toArray(arr);
		for(String s : arr1){
			System.out.print(s+" ");
		}
		
		/**
		 * using stream method
		 */
		System.out.println();
		int n = set.size();
		String[] arr2 = set.stream().toArray(String[] ::new);
		for(String s: arr2){
			System.out.print(s+" ");
		}
		
		
		Map<Integer, Integer> map = new TreeMap<Integer, Integer>();
		long t1 = System.currentTimeMillis();
		System.out.println(t1);
		for(i=1;i<=4;i++){
			map.put(i, i);
		}
		long t2 = System.currentTimeMillis();
		System.out.println(t2-t1);
		System.out.println(map.size());
		for(Map.Entry<Integer, Integer> ent: map.entrySet()){
			System.out.print(ent.getValue()+", ");
		}
		long t3 = System.currentTimeMillis();
		System.out.println(t3-t2);
		System.out.println("\nDone!");
		
		
		
		int[] array = {20, 1, 2, 17, 41, 3, 4, 6, 9, 5};
		
		int[] arr3 = new int[100];
		for(i = 0;i<array.length;i++){
			arr3[array[i]] = array[i];
		}
		
		for(i=1;i<100;i++){
			if(arr3[i]==0){
				System.out.println(i);
				break;
			}
		}
		
	}

}
