package com.java.inheritence;

import java.util.ArrayList;
import java.util.List;

class Car {
	void move() {
		System.out.println("Car is moving");
	}
}

public class Inheritence extends Car {

	void move() {
		System.out.println("Overriden method!!!");
	}
	
	

	public static void main(String args[]) {
		Car c = new Car();
		c.move();
			
		Car b = new Inheritence();
		b.move();
		
		List<String> list = new ArrayList<>();
		System.out.println(System.currentTimeMillis());
		for(int i=0;i<=1000000;i++){
			list.add(String.valueOf(i));
		}
		System.out.println(System.currentTimeMillis());
		int rank = list.indexOf(String.valueOf(999999));
		
		System.out.println(System.currentTimeMillis());
		System.out.println(rank);

	}
}
