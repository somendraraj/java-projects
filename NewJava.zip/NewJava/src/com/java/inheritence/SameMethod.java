package com.java.inheritence;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class SameMethod {

	public static void print() {
		System.out.println("print");
	}

	public static void print(String str) {
		System.out.println("print " + str);
	}

	public static void print(String[] string) {
		for (String s : string) {
			System.out.println("print " + s);
		}
	}

	public static void main(String args[]) throws CloneNotSupportedException {

		print();
		print("params");

		String[] arr = { "apple", "ball", "cat", "dog" };

		print(arr);

		ArrayList<String> list = new ArrayList<>();
		list.add("1");
		list.add("2");
		list.add("3");
		System.out.println(list);

		ArrayList<String> clone = (ArrayList) list.clone();

		// System.out.println(clone);

	}

}
