package com.java.encryption;

import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import com.allstar.cinutil.CinConvert;
import com.allstar.crypto.CinBase64;

public class AESEncryption {

	public static void main(String[] args) {

		try {
			String msg = "hello123";
			System.out.println("Original Message:" + msg);
			String keyStr = "6E56EE75DC536C51E368BC9C9E0B789C";

			byte[] keyE = CinConvert.hexToBytes(keyStr);

			SecretKey aesKey1 = new SecretKeySpec(keyE, "AES");//AES/ECB/PKCS5Padding;new SecretKeySpec(keyE, "AES");

			// Encryption
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, aesKey1);
			byte[] enctext = cipher.doFinal(msg.getBytes());

			System.out.println("Encrypted Message:" + CinBase64.encode(enctext));

			SecretKey aesKey2 = new SecretKeySpec(keyE, "AES");

			cipher.init(Cipher.DECRYPT_MODE, aesKey2);
			byte[] decmsg = cipher.doFinal(enctext);

			String decmsgp = new String(CinConvert.bytes2String(decmsg));
			System.out.println(decmsgp);
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < decmsg.length; i++) {

				sb.append((char) decmsg[i]);

			}
			System.out.println("Decrypted Message:" + sb);
			String ss = decryptPass("LjumsmVYmbH8trgpzwxg6w;;", "6E56EE75DC536C51E368BC9C9E0B789C");
			
			System.out.println(ss);
			
			String xx = decryptRedisPassword("LjumsmVYmbH8trgpzwxg6w;;", "6E56EE75DC536C51E368BC9C9E0B789C");
			System.out.println(xx);
			
			
			byte[] pt = "hello123".getBytes();
			System.out.println(encrypt(pt, "6E56EE75DC536C51E368BC9C9E0B789C"));
			System.out.println(decrypt("7c1FR28iBDmYZBHsSB1gDQ==", "6E56EE75DC536C51E368BC9C9E0B789C"));

		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	private static String decryptPass(String pass, String key){
		try{
			byte[] keyE = CinConvert.hexToBytes(key);
			byte[] password = CinBase64.decode(pass);
			SecretKey aesKey = new SecretKeySpec(keyE, "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");

			cipher.init(Cipher.DECRYPT_MODE, aesKey);
			byte[] decMsg = cipher.doFinal(password);

			//String decmsgp = new String(CinConvert.bytes2String(decMsg));
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < decMsg.length; i++) {
				sb.append((char) decMsg[i]);
			}
			System.out.println("Decrypted Password:" + sb);
			return sb.toString();
		}catch(NoSuchAlgorithmException nex){
			nex.printStackTrace();
		}catch(NoSuchPaddingException ex){

			ex.printStackTrace();
		}catch (Exception e){
			
			e.printStackTrace();
		}
		return "";
		
	}
	
	
	private static String decryptRedisPassword(String pass, String SecretKey){
		try{
			byte[] keyE = CinConvert.hexToBytes(SecretKey);
			byte[] password = CinBase64.decode(pass);
			javax.crypto.SecretKey aesKey = new SecretKeySpec(keyE, "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");

			cipher.init(Cipher.DECRYPT_MODE, aesKey);
			byte[] decMsg = cipher.doFinal(password);

			//String decmsgp = new String(CinConvert.bytes2String(decMsg));
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < decMsg.length; i++) {
				sb.append((char) decMsg[i]);
			}
			//LOGGER.info("Decrypted Password:" + sb);
			return sb.toString();
		}catch(NoSuchAlgorithmException nex){
			//LOGGER.error("Error1 in Decrypt REDIS Password", nex);
		}catch(NoSuchPaddingException ex){
			//LOGGER.error("Error2 in Decrypt REDIS Password", ex);
		}catch (Exception e){
			//LOGGER.error("Error3 in Decrypt REDIS Password", e);
		}
		return "";
	}
	
	
	public static String encrypt(byte[] plainText, String secret) throws Exception {
        SecretKey key = new SecretKeySpec(Arrays.copyOf(secret.getBytes(), 16), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encryptedTextBytes = cipher.doFinal(plainText);
        return Base64.encodeBase64String(encryptedTextBytes);// .getEncoder().encodeToString(encryptedTextBytes);
    }
  
    public static String decrypt(String byteCipherText, String secret) throws Exception {
        SecretKey key = new SecretKeySpec(Arrays.copyOf(secret.getBytes(), 16), "AES");
        byte[] b = Base64.decodeBase64(byteCipherText);// getDecoder().decode(byteCipherText);
        Cipher aesCipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        aesCipher.init(Cipher.DECRYPT_MODE, key);
        return new String(aesCipher.doFinal(b), "UTF-8");
    }

}
