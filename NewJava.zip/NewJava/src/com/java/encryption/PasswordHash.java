package com.java.encryption;

import java.util.Scanner;

public class PasswordHash {
	
	private static final String str = "cdfffa1bab7b294f4d086fd21513acd4";
	
	public static void main(String args[] ){
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Username:");
		String username = sc.nextLine();
		System.out.println("Enter Password:");
		String password = sc.nextLine();
		
		System.out.println(username);
		System.out.println(password);
		
		
	}

}
