package com.java.encryption;

public class DoEncryptDecrypt {
	
	
	public static void main(String args[]){
		
	}

}
