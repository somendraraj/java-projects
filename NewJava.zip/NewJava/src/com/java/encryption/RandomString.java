package com.java.encryption;

import java.util.UUID;

public class RandomString {
	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	private static final String ALPHA_NUMERIC_STRING_1 = "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6";
	
	/**
	 * 
	 * main method
	 * 
	 * @param args
	 */
	public static void main(String args[]) {

		String str = randomAlphaNumeric(32);
		System.out.println(str);
		
		String str1 = randomAlphaNumeric1(32);
		System.out.println(str1);

		System.out.println("81ea240388415f2e7d9b20dadba416");

		System.out.println(createRandomSessionId());

	}
	
	
	/**
	 * 
	 * @param count
	 * @return
	 */

	public static String randomAlphaNumeric(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}
	
	
	
	/**
	 * 
	 * @param count
	 * @return
	 */
	public static String randomAlphaNumeric1(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING_1.length());
			builder.append(ALPHA_NUMERIC_STRING_1.charAt(character));
		}
		return builder.toString();
	}
	
	/**
	 * 
	 * @return
	 */
	private static String createRandomSessionId() {
		return UUID.randomUUID().toString();
	}

}
