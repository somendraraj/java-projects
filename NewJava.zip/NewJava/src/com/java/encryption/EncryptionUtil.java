package com.java.encryption;

import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionUtil {
	
	public static String encrypt(byte[] plainText, String secret) throws Exception {
        SecretKey key = new SecretKeySpec(Arrays.copyOf(secret.getBytes(), 16), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encryptedTextBytes = cipher.doFinal(plainText);
        return Base64.getEncoder().encodeToString(encryptedTextBytes);// .getEncoder().encodeToString(encryptedTextBytes);
    }
  
    public static String decrypt(String byteCipherText, String secret) throws Exception {
        SecretKey key = new SecretKeySpec(Arrays.copyOf(secret.getBytes(), 16), "AES");
        byte[] b = Base64.getDecoder().decode(byteCipherText);// getDecoder().decode(byteCipherText);
        Cipher aesCipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        aesCipher.init(Cipher.DECRYPT_MODE, key);
        return new String(aesCipher.doFinal(b), "UTF-8");
    }

    
    public static void main(String args[]) throws Exception{
    	String username = "ZonhnvKCfY81omSIWxRn/w==";
    	String password = "ir8B+Jooj2Ye+T3J4DiCgA==";
    	String secret = "4a1250d922a0a27ed49981532449b9b1";
    	String[] arr = new String[10000];
    	for(int i=0;i<1000;i++){
    		arr[i] = decrypt(username, secret);
    		System.out.println(i+" : "+arr[i]);
    	}
    	
    	
    	
    }
}
