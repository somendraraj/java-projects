package com.java.encryption;

public class Encryption {

	public class AesEncryptionAdvanceZLA {
		public static void main(String args[]) {
			Long startTime = System.currentTimeMillis();
			AdvanceZLADecription advanceZLADecription = new AdvanceZLADecription();
			String normalText = advanceZLADecription.doDecription(
					"AQIC5wM2LY4Sfcxgy_vy0jJ2iGqGAWHB3ExJJ-TwC-iqYgo.*AAJTSQACMDIAAlNLABQtNjU5NjU5NjE3MjUwNTA5NzkxOAACUzEAAjUz*",
					"7bhEqhMgR0+RXjkaQTEz6Q");
			System.out.println(normalText);
			System.out.println(System.currentTimeMillis() - startTime);
		}
	}

}
