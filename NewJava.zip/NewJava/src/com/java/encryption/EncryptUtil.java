package com.java.encryption;

import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.allstar.cinutil.CinConvert;
import com.allstar.crypto.CinBase64;

public class EncryptUtil {

	private static final Logger log = LoggerFactory.getLogger(EncryptUtil.class);
	
	private static String algorithm = "AES/ECB/PKCS5Padding";

	private static String decryptRedisPassword(String pass, String SecretKey) {
		try {
			byte[] keyE = CinConvert.hexToBytes(SecretKey);
			byte[] password = CinBase64.decode(pass);
			SecretKey aesKey = new SecretKeySpec(keyE, "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, aesKey);
			byte[] decMsg = cipher.doFinal(password);
			// String decmsgp = new String(CinConvert.bytes2String(decMsg));
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < decMsg.length; i++) {
				sb.append((char) decMsg[i]);
			}
			return sb.toString();
		} catch (NoSuchAlgorithmException nex) {
			nex.printStackTrace();
			log.error("Error1 in Decrypt REDIS Password", nex);
		} catch (NoSuchPaddingException ex) {
			log.error("Error2 in Decrypt REDIS Password", ex);
			ex.printStackTrace();
		} catch (Exception e) {
			log.error("Error3 in Decrypt REDIS Password", e);
			e.printStackTrace();
		}
		return "";
	}

	public static String encrypt(String plainText, String secretKey) throws Exception {
		Key key = generateKey(secretKey);
		Cipher chiper = Cipher.getInstance(algorithm);
		chiper.init(Cipher.ENCRYPT_MODE, key);
		byte[] encVal = chiper.doFinal(plainText.getBytes());
		String encryptedValue = CinBase64.encode(encVal);
		return encryptedValue;
	}

	private static Key generateKey(String secretKey) {

		Key key = new SecretKeySpec(CinConvert.hexToBytes(secretKey), "AES");
		return key;
	}

	public static void main(String args[]) throws Exception {

		String mobile = "pQK5eTEXfbY1H7W5OaFyhw;;";
		String key = "6E56EE75DC536C51E368BC9C9E0B789C";
		//String res = decryptRedisPassword(mobile, key);
		//System.out.println(res);
		//pQK5eTEXfbY1H7W5OaFyhw;;
		String pt = "1000018380";
		String enc = encrypt(pt, key);
		System.out.println(enc);
		
		System.out.println(decryptRedisPassword(enc, key));
		
		String s = "\u0001";
		
		//String sex = StringEscapeUtils.unescapeJava(String.valueOf(s));// escapeJava(s);
		
		
	
		
		
		
		
		//System.out.println(s.toCharArray());
		
		//System.out.println(Integer.parseInt("0001", 16));
	}

}
