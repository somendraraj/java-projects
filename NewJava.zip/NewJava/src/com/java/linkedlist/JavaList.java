package com.java.linkedlist;


import java.util.ArrayList;
import java.util.List;

public class JavaList {

	public static void main(String[] args) {
		
		List<String> list = new ArrayList<String>();
		
		list.add("asd");
		list.add("asdf");
		list.add("qerty");
		System.out.println(list);
		list.remove("asd");
		System.out.println(list);

	}

}
