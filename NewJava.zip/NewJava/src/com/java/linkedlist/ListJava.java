package com.java.linkedlist;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ListJava {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < n; i++) {
			list.add(sc.nextInt());
		}
		int q = sc.nextInt();
		while (q-- > 0) {
			sc.nextLine();
			String input = sc.nextLine();
			if (input.equals("Insert")) {
				int index = sc.nextInt();
				int val = sc.nextInt();
				list.add(index, val);
			} else {
				int index = sc.nextInt();
				list.remove(index);
			}

		}
		System.out.println(list);

	}

}
