package com.java.linkedlist;

import java.util.List;

class Node{
	int data;
	Node next;
	
	Node(int data){
		this.data = data;
		this.next = null;
	}
}

public class JavaLinkedList {
	
	
	
	
	
	

}
