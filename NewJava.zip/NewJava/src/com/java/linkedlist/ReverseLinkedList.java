package com.java.linkedlist;



public class ReverseLinkedList {
	
	static Node head;
	static class Node{
		int data;
		Node next;
		
		public Node(int data){
			this.data = data;
			this.next = null;
		}
	}
	
	/**
	 * iterative approach
	 * 
	 * @param node
	 * @return
	 */
	private static Node reverse(Node node){
		Node curr = node;
		Node prev = null;
		Node next = null;
		while(curr != null){
			next = curr.next;
			curr.next = prev;
			prev = curr;
			curr = next;
		}
		
		node = prev;
		return node;
		
	}
	
	
	static Node reverseUtil(Node curr, Node prev){
		if(curr.next == null){
			head = curr;
			curr = prev;
			return head;
		}
		
		Node newNext = curr.next;
		curr.next = prev;
		reverseUtil(newNext, curr);
		return head;
	}
	
	private static void printReverse(Node head){
		if(head==null)
			return;
		printReverse(head.next);
		System.out.print(head.data+" ");
	}
	
	
	private static void printLinkedList(Node node){
		while(node!=null){
			System.out.print(node.data+" ");
			node = node.next;
		}
	}
	
	public static void main(String args[]){
		
		/*ReverseLinkedList list = new ReverseLinkedList();
		list.head = new Node(1);
		list.head.next = new Node(2);
		list.head.next.next = new Node(3);
		list.head.next.next.next = new Node(4);*/
		
		
		
		Node node = new Node(5);
		node.next = new Node(10);
		node.next.next = new Node(15);
		node.next.next.next = new Node(20);
		node.next.next.next.next = new Node(25);
		node.next.next.next.next.next = new Node(30);
		
		printLinkedList(node);
		
		head = reverse(node);
		
		System.out.println("\nAfter Reverse:");
		
		printLinkedList(head);
		
		System.out.println();
		printReverse(head);
		
	}
	
}
