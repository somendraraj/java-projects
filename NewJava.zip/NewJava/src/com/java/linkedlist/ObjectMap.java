package com.java.linkedlist;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectMap {

	public static void main(String[] args) throws Exception {
		ObjectMapper mapper = new ObjectMapper();

		List<String> list = new ArrayList<>();
		list.add("a");
		list.add("b");
		list.add("c");
		try {
			//final String s = mapper.writeValueAsString(list);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
