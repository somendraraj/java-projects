package com.java.linkedlist;

public class TailRecurseLinkedList {

	static Node head;

	static class Node {
		Node next;
		int data;

		public Node(int data) {
			this.data = data;
			this.next = null;
		}
	}

	Node reverse(Node curr, Node prev) {
		if (curr.next == null) {
			head = curr;
			curr = prev;
			return head;
		}

		Node newNode = curr.next;
		curr.next = prev;
		reverse(newNode, curr);
		return head;
	}

	static void printList(Node curr) {
		if (curr == null)
			return;
		while (curr != null && curr.next != null) {
			System.out.print(curr.data+" ");
		}
	}

	public static void main(String args[]) {
		TailRecurseLinkedList obj = new TailRecurseLinkedList();
		obj.head = new Node(1);
		head.next = new Node(2);
		head.next.next = new Node(3);
		head.next.next.next = new Node(4);
		
	}

}
