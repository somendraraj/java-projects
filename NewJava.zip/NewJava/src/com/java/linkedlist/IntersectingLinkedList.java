package com.java.linkedlist;

public class IntersectingLinkedList {
	
	static class Node {
		Node next;
		int data;
		
		public Node(int data){
			this.data = data;
			this.next = null;
		}
	}
	
	static Node getIntersecting(Node h1, Node h2){
		Node n1 = h1;
		Node n2 = h2;
		int d1 = 0;
		int d2 = 0;
		while(n1!=null){
			n1=n1.next;
			d1++;
		}
		
		while(n2!=null){
			n2=n2.next;
			d2++;
		}
		
		n1 = h1;
		n2 = h2;
		int diff = Math.abs(d1-d2);
	
		int count = 0;
		while(n1!=null && n2!=null){
			n1 =n1.next;
			count++;
			if(count>diff){
				n2 = n2.next;
				if(n1 == n2){
					return n1;
				}
			}
		}
		return null;
	}
	
	
	static void printList(Node head){
		Node curr = head;
		while(curr!= null){
			System.out.print(curr.data+" ");
			curr = curr.next;
		}
	}
	
	public static void main(String args[]){
		Node h1 = new Node(1);
		h1.next = new Node(5);
		h1.next.next = new Node(12);
		h1.next.next.next = new Node(11);
		h1.next.next.next.next = new Node(14);
		
		Node h2 = new Node(10);
		h2.next = h1.next.next.next;
		
		//printList(h1);
		System.out.println();
		//printList(h2);
		
		Node ins = getIntersecting(h1, h2);
		System.out.println("\n"+ins.data);
	}

}
