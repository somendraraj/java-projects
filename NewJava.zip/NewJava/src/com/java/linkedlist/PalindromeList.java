package com.java.linkedlist;

import java.util.Stack;

import com.java.linkedlist.ReverseLinkedList.Node;

public class PalindromeList {
	
	//static Node head;
	static class Node{
		int data;
		Node next;
		
		//Public Constructor
		public Node(int data){
			this.data = data;
			this.next = null;
		}
	}
	
	
	static boolean isPalindromeList(Node head){
		Stack<Integer> stack = new Stack<Integer>();
		Node curr = head;
		while(curr != null){
			stack.push(curr.data);
			curr = curr.next;
		}
		curr = head;
		while(curr != null){
			int d = stack.pop();
			if(d != curr.data){
				return false;
			}
			curr = curr.next;
		}
		return true;
	}
	
	static int getLength(Node node){
		Node curr = node;
		int length = 0;
		while(curr != null){
			length++;
			curr = curr.next;
		}
		return length;
	}
	
	static int getMax(Node node){
		Node curr = node;
		int max = 0;
		while(curr != null){
			if(max<curr.data){
				max = curr.data;
			}
			curr = curr.next;
		}
		return max;
	}
	
	
	static void sort(Node node){
		int len = getMax(node);//getLength(node);

		int[] arr = new int[len+1];
		Node head = node;
		while(head !=  null){
			arr[head.data] = head.data;
			head = head.next;
		}
		
		for(int ii=1;ii<arr.length-1;ii++){
			if(arr[ii]!=0){
				System.out.print(arr[ii]+"->");
			}
		}
		System.out.print(arr[arr.length-1]);
	}
	
	
	private static void printLinkedList(Node node){
		while(node!=null){
			System.out.print(node.data+" ");
			node = node.next;
		}
	}
	
	public static void main(String args[]){
		
		Node node = new Node(1);
		node.next = new Node(600);
		node.next.next = new Node(30000);
		node.next.next.next = new Node(700);
		node.next.next.next.next = new Node(5000);
		
		boolean bool = isPalindromeList(node);
		System.out.println(bool);
		
		//printLinkedList(node);
		
		sort(node);
		
		
	}
	

}
