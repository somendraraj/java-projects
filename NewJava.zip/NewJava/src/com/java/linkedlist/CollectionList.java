package com.java.linkedlist;

import java.util.LinkedList;
import java.util.List;

public class CollectionList {
	
	public static void main(String rgas){
		
		
		List<String> list = new LinkedList<String>();
		
		Object[] obj = new Object[10];
		
		list.add("12345");
		
		System.out.println(list);
		
		
 	}

}
