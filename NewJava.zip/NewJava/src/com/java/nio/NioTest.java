package com.java.nio;

public class NioTest {

	static String str = "{{\"keys\":\"value\"},{\"keys1\":\"values2\"}}";

	public static void main(String args[]) {

		System.out.println(str);

	}
}
