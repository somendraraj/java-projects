package com.java.vector;

import java.util.Iterator;
import java.util.Vector;

@SuppressWarnings("rawtypes")
public class VectorClass {

	public static void main(String args[]) {

		Vector v = new Vector();
		for (int i = 0; i < 10; i++) {
			v.add(i);
		}

		for (char c : "abcdefghijklmnopqrstuvwxyz".toCharArray()) {
			v.add(c);
		}

		Iterator itr = v.iterator();
		while (itr.hasNext()) {
			System.out.print(itr.next() + " ");
		}

	}

}
