package com.java.json;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

public class Test {

	public static void main(String[] args) {
		int i=1, j=10;
		do{
			if(j%i>0){
				System.out.println(j);
			}
			j--;
		}while(++i==j);
		
		
		JSONObject json = new JSONObject();
		
		json.put("touser", "1234567");
		json.put("msgType", "text");
		
		JSONObject text = new JSONObject();
		JSONObject content = new JSONObject();
		String[] str = new String[4];
		str[0] = "a";
		str[1] = "b";
		str[2] = "c";
		str[3] = "d";
		content.put("balance_details", str);
		text.put("content", content);
		json.put("text",text);
		
		
		System.out.println(json);
		
		String mobile = "9089620677";
		String mobileNo = mobile.substring( mobile.length()-10, mobile.length());
		System.out.println(mobileNo);
		
		long t1 = System.currentTimeMillis();
		System.out.println(t1);
		i=0;
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		for(i=0;i<=7500000;i++){
			map.put(i, i);
		}
		long t2 = System.currentTimeMillis();
		System.out.println(t2-t1);
		
		System.out.println(map.get(700000));
		System.out.println(map.get(12345));
		System.out.println(map.get(5060125));
		
	}

}
