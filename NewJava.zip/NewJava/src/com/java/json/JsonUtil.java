package com.java.json;

import java.util.Map;

import java.lang.reflect.Type;
import com.google.gson.Gson;
/**
 * 
 * @author Somendra1.Raj
 *
 */
public class JsonUtil {
	
	private Gson gson = null;
	
	public JsonUtil() {
		this.gson = new Gson();
	}
	
	/**
	 * 
	 * @param ob
	 * @return
	 */
	public String objectToJson(Object ob){
		String json = null;
		if(gson!=null){
			json = gson.toJson(ob);
		}
		return json;
	}
	
	/**
	 * json to map
	 * 
	 * @param json
	 * @return
	 */
	public Map<?,?> jsonToMap(String json){
		Map<?,?> map = null;
		if(gson!=null){
			Type type = new com.google.gson.reflect.TypeToken<Map<?,?>>(){
			}.getType();
			map = gson.fromJson(json, type);
		}
		return map;
	}
	
	/**
	 * parse json into bean object
	 * 
	 * @param json
	 * @param clazz
	 * @return
	 */
	public Object jsonToBean(String json, Class<?> clazz){
		Object obj = null;
		if(gson!=null){
			obj = gson.fromJson(json, clazz);
		}
		return obj;
	}
	
	/**
	 * get value from json
	 * 
	 * @param key
	 * @param json
	 * @return
	 */
	public Object getValuefromJson(String key, String json){
		Object obj = null;
		Map<?,?> map = jsonToMap(json);
		if(map!=null && map.size()>0){
			obj = map.get(key);
		}
		return obj;
	}

}
