package com.java.json;

import java.lang.reflect.Type;
import java.util.Map;

import org.json.JSONObject;

import com.google.gson.Gson;

public class JsonTest {

	private Gson gson = null;

	public JsonTest() {
		gson = new Gson();
	}

	public static void main(String args[]) {

		JsonTest obj = new JsonTest();
		obj.test();
		
		String str = obj.test1();
		System.out.println(str);

	}

	private String test1() {
		try {
			System.out.println("try");
			//int a = 10/0;
			return "test";
		} catch (Exception e) {
			System.out.println("catch");
			e.printStackTrace();
		} finally {
			System.out.println("finally");
		}
		return "qwert";
	}

	public void test() {
		JSONObject json = new JSONObject();
		json.put("key1", "value1");
		json.put("key2", "key3");
		// json.put("key3", true);
		String str = json.toString();

		// boolean bool = (Boolean) getJsonValue(str, "key3");
		if (json.has("key3")) {
			System.out.println("Inside Bool");
			System.out.println("yes");
		} else {
			System.out.println("No");
		}
	}

	/**
	 * 
	 * 
	 * @param jsonStr
	 * @param key
	 * @return
	 */
	public Object getJsonValue(String jsonStr, String key) {
		Object rulsObj = null;
		Map<?, ?> rulsMap = jsonToMap(jsonStr);
		if (rulsMap != null && rulsMap.size() > 0) {
			rulsObj = rulsMap.get(key);
		}
		return rulsObj;
	}

	/**
	 * jsonmap
	 * 
	 * @param jsonStr
	 * @return
	 */
	public Map<?, ?> jsonToMap(String jsonStr) {
		Map<?, ?> objMap = null;
		if (gson != null) {
			Type type = new com.google.gson.reflect.TypeToken<Map<?, ?>>() {
			}.getType();
			objMap = gson.fromJson(jsonStr, type);
		}
		return objMap;
	}

}
