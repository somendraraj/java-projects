package com.java.image;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ImageConverter {

	public static void main(String args[]) throws IOException {

		System.out.println("Conversion starts");
		BufferedImage inputImage = null;

		inputImage = ImageIO.read(new File("lena_gray.bmp"));

		File outputfile = new File("output.jpg");
		File outputfile1 = new File("output.png");

		ImageIO.write(inputImage, "jpg", outputfile);
		ImageIO.write(inputImage, "png", outputfile1);

		System.out.println("Conversion end");
	}

}
