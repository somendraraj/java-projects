package com.java.http;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.java.util.HttpClientUtil.IdleConnectionMonitorThread;

import jdk.nashorn.internal.objects.Global;

public class HttpConnection {
	
	private static final Logger logger = LoggerFactory.getLogger(HttpConnection.class);

	static PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();

	public static void getHttpClient() {
		connManager.setMaxTotal(200);
		connManager.setDefaultMaxPerRoute(20);
		connManager.close();
		
	}

	private static ThreadSafeClientConnManager cm = null;
	static {
		try {
			SSLContext ctx = null;
			try {
				ctx = SSLContext.getInstance("TLSv1.2");
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				logger.error(e.toString());
			}
			X509TrustManager tm = new X509TrustManager() {
				@Override
				public void checkClientTrusted(X509Certificate[] x509Certificates, String s)
						throws CertificateException {
				}

				@Override
				public void checkServerTrusted(X509Certificate[] x509Certificates, String s)
						throws CertificateException {
				}

				@Override
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return new java.security.cert.X509Certificate[0];
				}
			};
			try {
				ctx.init(null, new TrustManager[] { tm }, null);
			} catch (KeyManagementException e) {
				logger.error(e.toString());
				// TODO Auto-generated catch block
			}
			SSLSocketFactory ssf = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
			cm = new ThreadSafeClientConnManager();
			SchemeRegistry sr = cm.getSchemeRegistry();
			sr.register(new Scheme("https", 443, ssf));
			// max conn
			cm.setMaxTotal(Integer.parseInt("200"));
		} catch (NumberFormatException e) {
			logger.error("Key[MaxTotalConnections] Not Found in httpsConfig.xml", e);
		}
		// max conn of per host
		try {
			cm.setDefaultMaxPerRoute(Integer.parseInt("20"));
		} catch (NumberFormatException e) {
			logger.error("Key[MaxConnectionsPerRoute] Not Found in httpsConfig.xml", e);
		}
		IdleConnectionMonitorThread thread = new IdleConnectionMonitorThread(cm);
		thread.start();
	}
	
	public static HttpClient getHttpClient() {  
		 HttpParams params = new BasicHttpParams();  
		 params.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, Integer.parseInt("10000"));
	     params.setParameter(CoreConnectionPNames.SO_TIMEOUT, Integer.parseInt("5000"));
	     return new DefaultHttpClient(cm, params);  
	 }
	
	class IdleConnectionMonitorThread extends Thread {

		private final HttpClientConnectionManager connMgr;
		private volatile boolean shutdown;

		public IdleConnectionMonitorThread(PoolingHttpClientConnectionManager connMgr) {
			super();
			this.connMgr = connMgr;
		}

		@Override
		public void run() {
			try {
				while (!shutdown) {
					synchronized (this) {
						wait(1000);
						connMgr.closeExpiredConnections();
						connMgr.closeIdleConnections(30, TimeUnit.SECONDS);
					}
				}
			} catch (InterruptedException ex) {
				shutdown();
			}
		}

		public void shutdown() {
			shutdown = true;
			synchronized (this) {
				notifyAll();
			}
		}

	}

}
