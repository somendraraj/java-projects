package com.java.cache;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

import weka.clusterers.SimpleKMeans;
import weka.core.Instances;

public class Cluster {
	
	
	public static BufferedReader readData(String fileName){
		
		BufferedReader inputReader = null;
		
		try{
			inputReader = new BufferedReader(new FileReader(fileName));
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
		
		return inputReader;
	}
	
	public static void main(String args[]) throws Exception {
		
		SimpleKMeans kmeans = new SimpleKMeans();
		
		kmeans.setSeed(10);
		
		//preserver order, number of cluster
		kmeans.setPreserveInstancesOrder(true);
		kmeans.setNumClusters(5);
		
		BufferedReader datafile = readData("D:/test/data.txt");
		
		Instances data = new Instances(datafile);
		
		kmeans.buildClusterer(data);
		
		int[] assignments = kmeans.getAssignments();
		int i=0;
		for(int clusterNum: assignments){
			 System.out.printf("Instance %d -> Cluster %d \n", i, clusterNum);
			 i++;
		}
		
	}

}
