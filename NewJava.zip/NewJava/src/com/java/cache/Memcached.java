package com.java.cache;

import java.net.InetSocketAddress;
import java.util.concurrent.Future;

import net.spy.memcached.MemcachedClient;

public class Memcached {
	
	public static void main(String args[]){
		try{
			MemcachedClient mcc = new MemcachedClient(new InetSocketAddress("127.0.0.1", 11211));
			System.out.println("Memcached started successfully");
			
			
			Future fu = mcc.set("mem.key", 900, "value");
			
			System.out.println(fu.get());
			
			System.out.println(mcc.get("mem.key"));
			
			//shutdown memcached
			mcc.shutdown();
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
