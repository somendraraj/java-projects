package com.java.tree;

public class PrintLeftView {

	Node4 root;

	public void printLeftView(Node4 root) {
		if (root == null)
			return;
		else {
			System.out.println(root.data);
			printLeft(root.left);
		}

	}

	public void printLeft(Node4 root) {
		if (root == null)
			return;
		else {
			System.out.println(root.data);
			printLeft(root.left);
			printLeft(root.rigth);
		}
	}

	public static void main(String arg[]) {
		PrintLeftView pw = new PrintLeftView();

		pw.root = new Node4(1);
		pw.root.left = new Node4(2);
		pw.root.rigth = new Node4(3);

		pw.root.left.left = new Node4(4);
		pw.root.left.rigth = new Node4(5);
		pw.root.rigth.rigth = new Node4(6);
		pw.root.rigth.rigth.rigth = new Node4(7);
		pw.root.rigth.rigth.rigth.left = new Node4(7);

		pw.printLeftView(pw.root);

	}

}

class Node4 {
	int data;
	Node4 left;
	Node4 rigth;

	Node4(int data) {
		this.data = data;
		left = rigth = null;
	}
}