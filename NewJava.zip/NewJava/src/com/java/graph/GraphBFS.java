package com.java.graph;

import java.util.Iterator;
import java.util.LinkedList;

public class GraphBFS {
	
	private int V; //No of vertices
	private LinkedList<Integer> adj[];
	
	//Constructor
	GraphBFS(int v){
		this.V = v;
		adj = new LinkedList[V];
		
		for(int i=0;i<v;++i){
			this.adj[i] = new LinkedList<Integer>();
		}
	}
	
	//Function to add an Edge into graph
	void addEdge(int v, int w){
		adj[v].add(w);
	}
	
	//Print BFS Traverse 
	void BFS(int s){
		
		// By Default mark all node to unvisited
		boolean visited[] = new boolean[V];
		
		//Create queue for BFS
		LinkedList<Integer> queue = new LinkedList<Integer>();
		
		//start node is visitedput it into queue
		visited[s] = true;
		queue.add(s);
		
		while(queue.size() != 0){
			
			//Dequeue a vertex from queue and print
			s = queue.poll();
			System.out.print(s+ " ");
			
			Iterator<Integer> itr = adj[s].listIterator();
			while(itr.hasNext()){
				int n = itr.next();
				if(!visited[n]){
					visited[n] = true;
					queue.add(n);
				}
			}
		}
	}
	
	
	public static void main(String args[]){
		
		GraphBFS graph = new GraphBFS(4);
		
		graph.addEdge(0, 1);
		graph.addEdge(0, 2);
		graph.addEdge(1, 2);
		graph.addEdge(2, 0);
		graph.addEdge(2, 3);
		graph.addEdge(3, 3);
		
		graph.BFS(2);
	}
}
