package com.java.pattern.searching;

/**
 * Pattern searching algorithm
 * @author Somendra1.Raj
 *
 */
public class KMPAlgorithm {
	
	static void search(String txt,String pat){
		
	}
	
	static void computeLPS(){
		
	}

}
