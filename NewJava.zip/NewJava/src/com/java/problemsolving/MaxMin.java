package com.java.problemsolving;

class Pair {
	int min;
	int max;

	Pair(int min, int max) {
		this.min = min;
		this.max = max;
	}
}

public class MaxMin {
	
	static void findMinMax(int[] arr, int low, int high, Pair p){
		if(low==high){
			if(p.max<arr[low])
				p.max = arr[low];
			if(p.min>arr[high])
				p.min = arr[high];
			return;
		}else{
			
		}
	}
	
	public static void main(String args[]){
		
	}
	
}
