package com.java.problemsolving;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class BigDecimalNumber {

	static {

	}

	public static void main(String args[]) {
		/*Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();

		String[] str = new String[n + 2];

		for (int i = 0; i < n; i++) {
			str[i] = sc.next();
		}
		sc.close();

		Arrays.sort(str, Collections.reverseOrder(new Comparator<String>() {
			@Override
			public int compare(String s1, String s2) {
				if (s1 == null || s2 == null) {
					return 0;
				}
				BigDecimal b1 = new BigDecimal(s1);
				BigDecimal b2 = new BigDecimal(s2);
				return b1.compareTo(b2);
			}
		}));*/
		
		
		
		String str1 = "https://49.40.14.60:8080/group1/M00/00/AC/CoxiJlt7yaKATtTyAAH4FKAzTqs047.mp3#https://49.40.14.60:8080/group1/M00/00/AC/CoxiJlt7yaKAKDlHAAIxjGFccjY723.amr#https://49.40.14.60:8080/group1/M00/00/AC/CoxiJlt7yaKARzulAAGWTMuZUuI445.ogg";
		
		String[] st = str1.split("#");
		System.out.println(st[0]);
		System.out.println("str");
		

	}

}
