package com.java.problemsolving;

import java.util.HashMap;
import java.util.Map;

public class FindFrequency {

	static void findFrequency(int[] arr, int n) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (int i = 0; i < n; i++) {
			if (map.containsKey(arr[i])) {
				map.put(arr[i], map.get(arr[i]) + 1);
			} else {
				map.put(arr[i], 1);
			}
		}

		for (Map.Entry<Integer, Integer> e : map.entrySet()) {
			System.out.println(e.getKey() + " " + e.getValue());
		}

		map.forEach((k, v) -> System.out.println(k + " " + v));
	}

	static void findFrequencyRec(int[] arr, int left, int right, Map<Integer, Integer> map) {
		if (left > right)
			return;

		if (arr[left] == arr[right]) {
			Integer count = map.get(arr[left]);
			if (count == null)
				count = 0;
			map.put(arr[left], count + (right - left) + 1);
			return;
		}
		int mid = (left + right) / 2;
		findFrequencyRec(arr, left, mid, map);
		findFrequencyRec(arr, mid + 1, right, map);

	}

	static void findFrequencyIte(int[] arr, Map<Integer, Integer> map) {
		int left = 0;
		int right = arr.length - 1;

		while (left <= right) {

			if (arr[left] == arr[right]) {
				if (map.get(arr[left]) == null) {
					map.put(arr[left], 0);
				}

				map.put(arr[left], map.get(arr[left]) + right - left + 1);

				left = right + 1;
				right = arr.length - 1;
			} else {
				right = (right + left) / 2;
			}

		}

	}

	public static void main(String args[]) {
		int[] arr = { 2, 2, 2, 3, 3, 4, 4, 4, 4, 5, 5, 6, 6, 6 };

		findFrequency(arr, arr.length);

		Map<Integer, Integer> map = new HashMap<Integer, Integer>();

		System.out.println();
		findFrequencyRec(arr, 0, arr.length - 1, map);

		System.out.println(map);
		
		Map<Integer, Integer> freq = new HashMap<Integer, Integer>();
		findFrequencyIte(arr, freq);

		System.out.println(freq);

	}

}
