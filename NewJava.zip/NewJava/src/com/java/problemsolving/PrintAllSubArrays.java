package com.java.problemsolving;

public class PrintAllSubArrays {

	static void printSubArray(int[] arr, int start, int end) {
		System.out.print("{ ");
		for (int i = start; i <= end; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.print("}");
		System.out.println();

	}

	static void printAllSubArrays(int[] arr, int n) {
		for (int i = 0; i < n; i++) {
			for (int j = i; j < n; j++) {
				printSubArray(arr, i, j);
			}
		}
	}

	static void printAllSubstring(String str, int n) {
		for (int i = 0; i < n; i++) {
			for (int j = i; j < n; j++) {
				System.out.print(str.substring(i, j - i + 1) + ", ");
			}
		}
	}
	
	static void printSubsequence(String str, int n){
		int N = (int) Math.pow(2, n);
		
		for(int i=0;i<N;i++){
			for(int j=0;j<n;j++){
				if((i&(1<<j) )==0)
					System.out.print(str.charAt(j));
			}
			System.out.println();
		}
	}
	
	public static void main(String args[]) {
		int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8 };

		printAllSubArrays(arr, arr.length);

		String str = "string";
		//printAllSubstring(str, str.length());
		
		printSubsequence(str, str.length());

	}

}
