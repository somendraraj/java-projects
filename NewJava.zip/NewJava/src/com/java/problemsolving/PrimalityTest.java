package com.java.problemsolving;

import java.math.BigInteger;

public class PrimalityTest {

	static boolean isPrime(int n) {
		if (n <= 1) {
			return false;
		}
		if (n == 2)
			return true;
		for (int i = 2; i * i <= n; i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}

	public static BigInteger randomPrime(BigInteger x) {
		BigInteger i;

		for (i = BigInteger.valueOf(2); i.compareTo(x) < 0; i = i.add(i)) {
			if ((x.remainder(i).equals(BigInteger.ZERO))) {
				x.divide(i).equals(x);
				i = i.subtract(i);
			}
		}
		return i;
	}


	public static void main(String args[]) {
		for (int i = 2; i < 5; i++) {
			System.out.println(i + " " + isPrime(i));
			long ll = i;
			BigInteger big =  BigInteger.valueOf(i); 
			System.out.println(i + " " + randomPrime(big));
		}

	}

}
