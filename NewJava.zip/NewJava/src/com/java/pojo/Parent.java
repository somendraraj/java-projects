package com.java.pojo;

import java.util.List;

public class Parent {

	private Integer id;
	private String firstName;
	private String lastName;
	private String gender;
	private List<Spouse> spouses = null;
	private List<Child> children = null;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public List<Spouse> getSpouses() {
		return spouses;
	}

	public void setSpouses(List<Spouse> spouses) {
		this.spouses = spouses;
	}

	public List<Child> getChildren() {
		return children;
	}

	public void setChildren(List<Child> children) {
		this.children = children;
	}

}