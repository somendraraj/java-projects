package com.java.string;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PalindromeCount {

	static int palindrome(String str) {
		char[] strArray = str.toCharArray();
		List<String> list = new ArrayList();
		for (char c : strArray) {
			list.add(String.valueOf(c));
		}
		Set<String> palindromeSet = new HashSet<>(list);
		System.out.println(palindromeSet);
		String palindromeStr = null;
		for (int i = 0; i < list.size(); i++) {
			palindromeStr = list.get(i);
			for (int j = i + 1; j < list.size(); j++) {
				palindromeStr = palindromeStr + list.get(j);
				if (isPalindrome(palindromeStr)) {
					palindromeSet.add(palindromeStr);
				}
			}
		}
		System.out.println(palindromeSet);	
		return palindromeSet.size();
	}

	static boolean isPalindrome(String str) {
		char[] chars = str.toCharArray();
		for (int i = 0; i < (chars.length / 2); i++) {
			if (chars[i] != chars[chars.length - 1 - i]) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) throws IOException {
		System.out.println(palindrome("abaaa"));
	}

}
