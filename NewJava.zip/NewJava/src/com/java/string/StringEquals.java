package com.java.string;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

import javax.xml.bind.DatatypeConverter;

public class StringEquals {
	
	
	public static void main(String args[]) throws UnsupportedEncodingException{
		
		String str1 = new String("1234");
		String str2 = new String("1234");
		
		System.out.println(str1==str2);
		
		String str3 = str2;
		System.out.println(str2==str3);
		
		System.out.println(str1.equals(str2));
		
		System.out.println(str2.equals(str3));
		
		System.out.println(str3.equals(str1));
		
		String s1 = "abcd";
		String s2 = "abcd";
		System.out.println(s1.equals(s2));
		
		System.out.println(s1==s2);
		
		String s = "4139333830433231384638323938304336374636354332443139324434454235";
		String st = "A9380C218F82980C67F65C2D192D4EB5";
		
		String stt = "34313339333333383330343333323331333834363338333233393338333034333336333734363336333534333332343433313339333234343334343534323335";
		
		
		byte[] bytes = DatatypeConverter.parseHexBinary(s);
        String result = new String(bytes, Charset.forName("UTF-8"));
        System.out.println(result);
        
        byte[] bytes1 = DatatypeConverter.parseHexBinary(st);
        String result1 = new String(bytes1, Charset.forName("UTF-8"));
        System.out.println(result1);
        
        byte[] bytes2 = DatatypeConverter.parseHexBinary(stt);
        String result2 = new String(bytes2, Charset.forName("UTF-8"));
        
        byte[] bytes3 = DatatypeConverter.parseHexBinary(result2);
        String result3 = new String(bytes3, Charset.forName("UTF-8"));
        System.out.println(result3);
        
        
        String s3 = "data:image/png;base64,iVBORw0KGgoAAAAN";
        System.out.println(s3.substring(s3.indexOf(",")+1, s3.length()));
        
        System.out.println(java.net.URLDecoder.decode("a6c89c98-f9a5-42a4-9f00-0df36dfbb294%7C0%7C0%7C3.2.5.1","UTF-8"));
		
	}

}
