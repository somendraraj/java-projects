package com.java.string;

import java.util.UUID;

public class RandomString {

	public static void main(String args[]) {
		String randomString = UUID.randomUUID().toString();
		System.out.println(randomString.replaceAll("-", ""));

		System.out.println(UUID.randomUUID());
		
		int x = get();
		System.out.println(x);
	}

	static int get() {
		try {
			System.out.println("this");
			return 1/1;
		} catch (Exception e) {
			e.printStackTrace();
			return 2;
		} finally {
			return 3;
		}
	}

}
