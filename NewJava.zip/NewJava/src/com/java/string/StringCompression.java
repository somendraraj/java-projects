package com.java.string;

public class StringCompression {

	static String compressString(String str) {
		if (str == null)
			return null;
		if (str.isEmpty()) {
			return "";
		}

		String sb = str.substring(0, 1);
		int count = 1;
		for (int i = 1; i < str.length(); i++) {
			if (str.charAt(i - 1) == str.charAt(i)) {
				count++;
			} else {
				if (count > 1) {
					sb += count;
				}
				count = 1;
				sb += str.charAt(i);
			}

		}
		if (count > 1) {
			sb += count;
		}
		return sb;
	}

	public static void main(String args[]) {
		String str = "abaaabcddebeee";
		System.out.println(compressString(str));
	}
}
