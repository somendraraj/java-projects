package com.java.string;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class GroupAnagram {

	public static List<List<String>> getAllAnagrams(String[] str) {
		List<List<String>> res = new ArrayList<List<String>>();

		HashMap<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();

		for (String s : str) {
			char[] ch = new char[26];
			for (int i = 0; i < s.length(); i++) {
				ch[s.charAt(i) - 'A']++;
			}

			String ns = new String(ch);

			if (map.containsKey(ns)) {
				map.get(ns).add(s);
			} else {
				ArrayList<String> al = new ArrayList<String>();
				al.add(s);
				map.put(ns, al);
			}
		}
		res.addAll(map.values());

		return res;
	}

	public static void main(String[] args) {
		String[] str = { "BAC", "ABC", "ACB", "ABC", "CAD", "DAC", "TAR", "RAT" };
		System.out.println(getAllAnagrams(str));

	}

}
