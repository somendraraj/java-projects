package com.java.string;

import java.util.HashMap;
import java.util.Map;

public class StringToken {

	static String key = "Reference ID for this interaction is:";

	public static void main(String args[]) {
		String msg = "Reference ID for this interaction is:00019aDHGN8T005S";

		Map<String, String> map = new HashMap<String, String>();

		if (msg.startsWith(key)) {
			msg = msg.replace(key, "").trim();
			System.out.println(msg.replace(key, ""));
			map.put(msg, "12345");
			System.out.println(map);
		} else {
			System.out.println("No");
		}

	}

}
