package com.java.string;

public class TwoPalindromicSubSequences {

	static int maxPalindromicSubsequence(String s, int left, int right) {
		// could include defensive exception throwing for nonsense indices.
		if (left > right)
			return 0;
		if (left == right)
			return 1;
		if (s.charAt(left) == s.charAt(right))
			return maxPalindromicSubsequence(s, left + 1, right - 1) + 2;
		int incLeftResult = maxPalindromicSubsequence(s, left + 1, right);
		int decRightResult = maxPalindromicSubsequence(s, left, right - 1);
		if (incLeftResult > decRightResult)
			return incLeftResult;
		return decRightResult;
	}

	public static void main(String args[]) {
		String s = "acdapmpomp";
		System.out.println(maxPalindromicSubsequence(s, 0, s.length() - 1));
		
		System.out.println(getScore(s));
	}

	static int[][] longestPalindromicSubsequence(String seq) {
		int n = seq.length();
		int i, j, cl;
		int table[][] = new int[n][n];

		for (i = 0; i < n; i++)
			table[i][i] = 1;

		for (cl = 2; cl <= n; cl++) {
			for (i = 0; i < n - cl + 1; i++) {
				j = i + cl - 1;
				if (seq.charAt(i) == seq.charAt(j) && cl == 2)
					table[i][j] = 2;
				else if (seq.charAt(i) == seq.charAt(j))
					table[i][j] = table[i + 1][j - 1] + 2;
				else
					table[i][j] = Math.max(table[i][j - 1], table[i + 1][j]);
			}
		}

		return table;
	}

	static int getScore(String s) {
		int prodMax = -1;
		int resArr[][] = longestPalindromicSubsequence(s);
		for (int i = 0; i < s.length() - 1; i++) {
			int tempProd = resArr[0][i] * resArr[i + 1][s.length() - 1];
			if (prodMax <= tempProd)
				prodMax = tempProd;
		}
		return prodMax;
	}

}
