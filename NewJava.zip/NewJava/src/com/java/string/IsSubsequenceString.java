package com.java.string;

public class IsSubsequenceString {

	static boolean isSubsequence(String str, String tar) {
		if (str == null || str.length() == 0) {
			return true;
		}
		if (tar == null)
			return false;

		int i = 0, j = 0;

		while (i < str.length() && j < tar.length()) {
			if (str.charAt(i) == tar.charAt(j)) {
				i++;
			}
			j++;

			if (str.length() == i)
				return true;
		}
		return false;
	}

	public static void main(String args[]) {
		System.out.println(isSubsequence("cdh", "abcdefghi"));
	}

}
