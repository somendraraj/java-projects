package com.java.string;

public class ReplaceString {
	

	static String s = "http://10.140.98.38:8200/eventpush/clickmenu.action?ToUserName=600000000513&FromUserName=1000018380&Event=LIVEAGENT&EventKey=1&Content=Somendra Ril Corp : Hibot : 1. Check out great new Jio offers�for you.- Hurry up! Grab exciting latest offers from Jio..2. Want to know about your Data Balance, Bill Dues, Current Plan, Vouchers etc?- Your Data Balance, Vouchers, Recharge History etc.�are now�at one stop..";
	
	public static void main(String args[]){
		System.out.println(s);
		String q = s.replace(" ", "%20%");
		System.out.println(q);
	}

}
