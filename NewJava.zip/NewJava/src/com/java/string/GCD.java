package com.java.string;

public class GCD {

	static int gcd(int a, int b) {
		if (a == 0 || b == 0)
			return 0;
		if (a == b)
			return a;
		if (a > b)
			return gcd(a - b, b);
		return gcd(a, b - a);
	}
	
	public static void main(String args[]){
		int g = 98;
		int d = 14;
		System.out.println(gcd(g,d));
	}

}