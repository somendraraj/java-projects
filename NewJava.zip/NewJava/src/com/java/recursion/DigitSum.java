package com.java.recursion;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class DigitSum {

	// Complete the superDigit function below.
	static int superDigit(String n, int k) {
		int sum = 0;
		
		// System.out.println(d+" "+k);
		int res = getSum(sum, n, k);
		return res;
	}

	static int getSum(int sum, String d, int k) {
		if (d.length() == 1) {
			return k*Integer.parseInt(d);
		}
		for (char c : d.toCharArray()) {
			sum += (int) c - '0';
			//System.out.println(sum);
		}

		return getSum(0, String.valueOf(sum), k);
	}
	
	static Random rand = new Random();
	
	public static void main(String args[]) {
		String n = "148";
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		int k = 10000;
		for(int i=1;i<=10;i++){
			map.put(i, superDigit(n, i));
		}
		
		
		for(int i=0;i<100;i++){
			k = rand.nextInt(100);
			int x = superDigit(n, k);
			int y = map.get(k%9==0?9:k%9);
			System.out.println(i+" "+x+"  "+y);
		}
		
	}

}
