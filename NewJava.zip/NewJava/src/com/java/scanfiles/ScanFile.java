package com.java.scanfiles;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ScanFile {
	
	//private static final Logger log = LoggerFactory.getLogger(ScanFile.class);

	static int count = 0;
	
	static File logFile = new File("D:/logs/public_message.out");
	static StringBuilder sb = new StringBuilder();

	private static void scan(String directoryName) {
		File directory = new File(directoryName);
		// get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList) {
			if (file.isFile()) {
				// System.out.println(file.getAbsolutePath());
				//System.out.println(count++ + ":" + file.getName());
				readFile(file.getAbsolutePath());
				//scanContents(file.getAbsolutePath());
				
			} else if (file.isDirectory()) {
				scan(file.getAbsolutePath());
			}
		}
	}
	
	private static void readFile(String file){
		sb.append(file+": ");
		BufferedReader br = null;
		String line = "";
		try{
			br = new BufferedReader(new FileReader(file));
			while((line = br.readLine()) !=null ){
				scanContents(line , file);
			}
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException ex){
			ex.printStackTrace();
		}finally{
			if(br!=null){
				try{
					br.close();
				}catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}

	private static void scanContents(String s, String file) {
		//System.out.println(containsHanScript("xxx已下架xxx"));
		
		for (int i = 0; i < s.length();) {
			int codepoint = s.codePointAt(i);
			i += Character.charCount(codepoint);
			if (Character.UnicodeScript.of(codepoint) == Character.UnicodeScript.HAN) {
				sb.append("true ");
			}
		}
		//
	}
	
	private static void writeIntoFile(String str){
		 BufferedWriter writer = null;
	        try {
	            //create a temporary file
	            
	            writer = new BufferedWriter(new FileWriter(logFile));
	            writer.write(str);
	            writer.write("\n");
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                // Close the writer regardless of what happens...
	                writer.close();
	            } catch (Exception e) {
	            }
	        }
	}

	public static void main(String[] args) {
		final String directoryWindows = "D:/test/rmc/public_message/";

		ScanFile.scan(directoryWindows);
		
		writeIntoFile(sb.toString());
		
		System.out.println("Done!");

	}

}
