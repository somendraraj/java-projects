package com.java.collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashMapClass {
	
	
	
	public static void main(String args[]){
		
		List<String> list = new ArrayList<>();
		
		Map<String, String> map = new HashMap<>();
		map.put("1", "1");
		Map<String, String> map1 = new HashMap<>();
		map1.put("2", "1");
		Map<String, String> map2 = new HashMap<>();
		map2.put("3", "1");
		Map<String, String> map3 = new HashMap<>();
		map3.put("4", "1");
		
		list.add(map.toString());
		list.add(map1.toString());
		list.add(map2.toString());
		list.add(map3.toString());
		
		System.out.println(list);
		
		for(String s: list){
			String k = s;
			System.out.println(k);
		}
		
	}

}
