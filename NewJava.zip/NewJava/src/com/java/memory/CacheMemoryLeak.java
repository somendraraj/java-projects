package com.java.memory;

public class CacheMemoryLeak {
	
	public static void main(String args[]){
		
		for(int i=0;i<=10;i++){
			Cache.map.put(String.valueOf(i), String.valueOf(i));
		}
		
		System.out.println(Cache.map);
		
		Cache.map.clear();
		
		//System.out.println(Cache.map);
		
		for(int i=0;i<5;i++){
			Person per = new Person(new String("abe"), i);
			Cache.person.put(i, per);
		}
		
		System.out.println(Cache.person.get(0).getName());
		System.out.println(Cache.person.get(0).getAge());
	}
}
