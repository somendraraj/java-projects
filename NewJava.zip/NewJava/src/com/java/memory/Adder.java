package com.java.memory;

public class Adder {
	
	private long add(long l){
		Long sum = 0L;
		sum +=l;
		return sum;
	}
	
	public static void main(String args[]){	
		Adder ad = new Adder();
		System.out.println("Start....!");
		for(long i=0;i<1000000000;i++){
			ad.add(i);
		}
		System.out.println("Done.....!");
		System.exit(0);
	}
}