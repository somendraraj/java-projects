package com.java.memory;

public class JavaTest {
	
	
	public static void main(String args[]){
		
		SecondClass obj = new SecondClass();
		obj.createString();
		System.out.println(obj.getString());
		System.out.println(SecondClass.str);
		
		String content = "Location:5, Shree Nateshwar Mahadev Mandir Marg, Singh Nagar, Ganeshwadi, Thane West, Thane, Maharashtra 400601, India,";
		
		content = content.substring(9, content.length());
		System.out.println(content);
		
	}

}
