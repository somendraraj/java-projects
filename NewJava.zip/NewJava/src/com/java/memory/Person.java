package com.java.memory;

import java.io.Serializable;

public class Person implements Serializable{
	
	private static final long serialVersionUID = -1889324202453272938L;
	private String name;
	private int age;

	Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

}
