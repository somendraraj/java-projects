package com.java.memory;

public class Student {
	
	private String name;
	private String id;
	
	//Constructor with two parameters
	Student(String name, String id){
		this.name=name;
		this.id=id;
	}
	
	//getters setters for student id and name
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}
	
	@Override
	public int hashCode(){
		return (5*id.length()/10);
	}

	@Override
	public boolean equals(Object obj){
		if(this==obj)
			return true;
		Student student = (Student)obj;
		if(this.getId().equalsIgnoreCase(""))
			return true;
		return false;
	}

}
