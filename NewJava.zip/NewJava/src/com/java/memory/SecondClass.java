package com.java.memory;

public class SecondClass {
	
	
	public static String str = null;
	
	
	public static String createString(){
		str = new String("This is new str");
		return str;
	}
	
	
	public static String getString(){
		return str;
	}

}
