package com.java.memory;

import java.util.HashMap;
import java.util.Map;

import redis.clients.util.SafeEncoder;

public class Cache {

	public static Map<String, String> map = new HashMap<String, String>();

	public static Map<Integer, Person> person = new HashMap<Integer, Person>();

	public enum RedisKeysExpire {
		ONEDAY(86400), ONE_WEEK(604800), FIFTEEN_DAYS(1296000), ONE_MONTH(2592000);
		private final int value;

		public int getValue() {
			return value;
		}

		RedisKeysExpire(int value) {
			this.value = value;
		}
	}

	public static void main(String args[]) {
		System.out.println(RedisKeysExpire.ONEDAY.getValue());
		System.out.println(RedisKeysExpire.ONE_WEEK.getValue());
		System.out.println(RedisKeysExpire.FIFTEEN_DAYS.getValue());
		System.out.println(RedisKeysExpire.ONE_MONTH.getValue());

		System.out.println(SafeEncoder.encode("followId_" + 12345));
		System.out.println("followId_" + 12345);
		int i = 0;
		while (i < 10) {
			System.out.println(System.nanoTime());
			i++;
		}
		System.out.println(System.nanoTime());
		System.out.println(System.nanoTime());
		System.out.println(System.nanoTime());
		System.out.println(System.currentTimeMillis());
		System.out.println(System.currentTimeMillis());
		System.out.println(System.currentTimeMillis());
	}

}
