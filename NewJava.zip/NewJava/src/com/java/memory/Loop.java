package com.java.memory;

public class Loop {
	
	static long i = 0l;
	public static void main(String args[]){
		
		
		while(i<Long.MAX_VALUE){
			System.out.println("0000");
			try{
				Thread.sleep(1000);
				i++;
			}catch(Exception e){
				
			}
		}
		
	}

}
