package com.java.memory;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.util.SafeEncoder;

import com.allstar.cintracer.CinTracer;

public class RedisLock {
	private final static CinTracer LOGGER = CinTracer.getInstance(RedisLock.class);

	private final static byte[] lockValue = SafeEncoder.encode("1");

	private static final int TRY_TIMES = 3;

	private JedisPool pool;

	private String lockName;

	private byte[] lockKey;

	/*public RedisLock(String lockName, byte[] lockKey, WrapJedisPool pool) {
		this.lockName = lockName;
		this.lockKey = lockKey;
		this.pool = pool.getPool();
	}*/
	
	public RedisLock() {
		
	}

	private static String getCurrentCallStackTrace() {
		StringBuilder sb = new StringBuilder();
		sb.append("Current call stack trace is \r\n[");
		for (StackTraceElement trace : Thread.currentThread().getStackTrace()) {
			sb.append(trace.toString());
			sb.append("\t");
		}

		sb.append("\r\n]");
		return sb.toString();
	}

	public boolean lock(int timeoutMs) {
		return lock(timeoutMs, true);
	}

	public boolean lock(int timeoutMs, boolean deleteLockOnTImeout) {
		int tryTimes = 0;
		boolean lock = false;
		long waitTimeMs = 0;
		final long sleepMs = 5;
		while (true) {
			Jedis jedis = null;
			try {
				jedis = pool.getResource();

				if (jedis.setnx(lockKey, lockValue) == 1) {
					lock = true;
					if (LOGGER.InfoTrace()) {
						LOGGER.info(String.format("OK %s wait %s ms to get lock \r\nCurrentCallStackTrace \r\n%s",
								this.lockName, waitTimeMs, getCurrentCallStackTrace()));
					}
					break;
				}

				if (waitTimeMs > timeoutMs) {
					if (deleteLockOnTImeout) {
						jedis.del(lockKey);
					}
					LOGGER.error(
							String.format("error %s wait %s ms to get lock timeout \r\nCurrentCallStackTrace \r\n%s",
									this.lockName, waitTimeMs, getCurrentCallStackTrace()));
					break;
				} else {
					try {
						Thread.sleep(sleepMs);
					} catch (Exception e) {
					}
					waitTimeMs += sleepMs;
				}
			} catch (Exception e) {
				if (tryTimes >= TRY_TIMES) {
					throw e;
				}
			} finally {
				pool.returnResource(jedis);
			}
		}

		return lock;
	}

	public void unlock() {
		int tryTimes = 0;
		while (true) {
			tryTimes++;
			Jedis jedis = null;
			try {
				jedis = pool.getResource();
				jedis.del(lockKey);
				return;
			} catch (Exception e) {
				if (tryTimes >= TRY_TIMES) {
					throw e;
				}
			} finally {
				pool.returnResource(jedis);
			}
		}
	}
}
