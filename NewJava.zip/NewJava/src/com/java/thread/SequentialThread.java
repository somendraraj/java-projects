package com.java.thread;

class T1 extends Thread {

	@Override
	public void run() {
		System.out.println("Thread 1");
	}
}

class T2 extends Thread {

	@Override
	public void run() {
		System.out.println("Thread 2");
	}
}

class T3 extends Thread {

	@Override
	public void run() {
		System.out.println("Thread 3");
	}
}

public class SequentialThread {

	public static void main(String args[]) throws InterruptedException {

		final Thread t1 = new Thread(new T1());
		t1.start();
		t1.join();
		final Thread t2 = new Thread(new T2());
		t2.start();
		t2.join();
		final Thread t3 = new Thread(new T3());
		t3.start();
		t3.join();

		final Thread th1 = new Thread(new Th1());
		th1.start();

		final Thread th2 = new Thread(new Th2());
		th2.start();

		final Thread th3 = new Thread(new Th3());
		th3.start();

	}

	final Object lock2 = new Object();
	final Object lock3 = new Object();
	boolean ready2;
	boolean ready3;

	class Th1 implements Runnable {

		@Override
		public void run() {

			synchronized (lock2) {
				// notify the T2 class that it should start
				ready2 = true;
				lock2.notify();
			}
		}
	}

	class Th2 implements Runnable {

		@Override
		public void run() {
			// the while loop takes care of errant signals
			synchronized (lock2) {
				while (!ready2) {
					try {
						lock2.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

			// notify the T3 class that it should start
			synchronized (lock3) {
				ready3 = true;
				lock3.notify();
			}
		}
	}

	class Th3 implements Runnable {

		@Override
		public void run() {
			// the while loop takes care of errant signals
			synchronized (lock3) {
				while (!ready3) {
					try {
						lock3.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

		}
	}

}
