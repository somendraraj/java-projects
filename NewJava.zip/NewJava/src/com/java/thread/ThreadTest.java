package com.java.thread;

import java.util.ArrayList;
import java.util.List;

class Sam  implements Runnable{
	private Thread t;
	private String threadName;
	
	Sam(String threadName){
		this.threadName = threadName;
	}
	
	public void run(){
		while(true){
			System.out.println(threadName);
		}
	}
	
	public void start(){
		if(t==null){
			t = new Thread(this, threadName);
			t.start();
		}
	}
}

public class ThreadTest {
	
	static int divide(int a, int b){
		int c= -1;
		try{
			c= a/b;
		}catch(Exception e){
			System.out.print("Exception ");
		}finally{
			System.out.println("Finnaly ");
		}
		return c;
	}
	
	public static void main(String args[]){
		Sam a = new Sam("A");
		Sam b = new Sam("B");
		
		//a.start();
		//b.start();
		divide(4, 0);
		
		List<String> list = new ArrayList<>();
		list.add("");
	}
}
