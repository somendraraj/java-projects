package com.java.thread;

import java.util.Arrays;
import java.util.Comparator;

public class Compares {
	
	public static void main(String args[]){
		String[] cities = {"Banglore", "Pune", "San Fransisco", "New York"};
		MySort ms = new MySort();Arrays.sort(cities, ms);
		System.out.println(Arrays.binarySearch(cities, "New York"));
		
	}
	
	/*static class MySort implements Comparator{
		public int compare(String a, String b){
			return b.compareTo(a);
		}
	}
*/
}
