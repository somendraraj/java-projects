package com.java.thread;

public class SumNumberThread {
	static int sum = 0; 
	public void sumNum() {
		ThreadPoolManager.initialize(5);
		for(int i=0;i<=10;i++){
			ThreadPoolManager.execute(new Worker(i));
		}
		
	}

	private class Worker implements Runnable {
		
		private int i;
		
		
		public Worker(int i){
			this.i = i;
		}
		
		@Override
		public void run() {
			sum+=i;
		}
	}
	
	public static void main(String args[]){
		SumNumberThread obj = new SumNumberThread();
		obj.sumNum();
		System.out.println(sum);
	}

}
