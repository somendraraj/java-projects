package com.java.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ThreadPool Executor 
 * @author Somendra1.Raj
 *
 */
public class ThreadPoolManager {

	private static ExecutorService executor = null;

	public static void initialize(int size) {
		if (executor == null) {
			executor = Executors.newFixedThreadPool(size);
		}
	}

	public static void execute(Runnable worker) {
		executor.execute(worker);
	}

}
