package com.java.optimization;

public class CodeOptimization {
	
	/*Strength reduction*/
	
	private static void strengthReduction(int val1, int val2){
		/*Optimization for multiply*/
		int mul1 = val1*val2;
		int mul2 = val1<<(val2>>1);
		System.out.println(mul1 + " "+mul2);
		
		/*Optimization for divide*/
		int div1 = val1/val2;
		int div2 = val1>>(val2>>1);
		System.out.println(div1+" "+div2);
		
		/*Optimization for mod*/
		int mod1 = val1%val2;
		int mod2 = val1&(val2-1);
		System.out.println(mod1+" "+mod2);
	}
	
	/*Common sub expression elimination*/
	private static void commaonSubExpression(){
		/*double x = d * (lim / max) * sx;
		double y = d * (lim / max) * sy;*/
		double x = 10 * (112 / 12) * 15;
		double y = 10* (112 / 12) * 5;
		
		System.out.println(x+" "+y);
		
		
		double d = 10*(112/12);
		double x1 = d*15;
		double y1 = d*5;
		System.out.println(x1+" "+y1);
	}
	
	/*calculates an expression whose result doesn't change*/
	private static void codeMotion(){
		int[] x = new  int[5];
		double y = 60;
		for (int i = 0; i < x.length; i++)
		    x[i] *= (int) (Math.PI * Math.cos(y));
		
	}
	public static void main(String args[]){
		
		
		
		strengthReduction(16, 4);
		
		commaonSubExpression();
		
		codeMotion();
	}
}
