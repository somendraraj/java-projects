package com.java.hackerrank.euler;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Euler22 {
	
	static Map<String, Integer> scoresMap = new HashMap<>(); 
	
	static void addToMap(String[] names){
		for(int i=0;i<names.length;i++){
			String str = names[i];
			int cnt = getCharCount(str);
			scoresMap.put(str, cnt*(i+1));
		}
	}
	
	static int getCounts(String name){
		return (int) scoresMap.get(name);
	}
	
	static int getCharCount(String str){
		char[] ch = new char[26];
		int count = 0;
		for(Character c: str.toCharArray()){
			count += (int) (c - 'A' +1);
			//System.out.println((int) c - 64);
		}
		return count;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		String[] names = new String[n];
		sc.nextLine();
		for(int i=0;i<n;i++){
			names[i] = sc.nextLine();
		}
		
		//As per question
		Arrays.sort(names);
		
		addToMap(names);
		
		//System.out.println(scoresMap);
		int q = sc.nextInt();
		sc.nextLine();
		for(int i=0;i<q;i++){
			String st = sc.nextLine();
			int res = getCounts(st);
			System.out.println(res);
		}
	}

}
