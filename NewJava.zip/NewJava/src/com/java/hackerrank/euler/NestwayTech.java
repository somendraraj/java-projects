package com.java.hackerrank.euler;

import java.util.Scanner;

public class NestwayTech {
	
	
	public static void main(String arge[]){
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		while(n-->0){
			String booking = sc.nextLine();
			String bed = sc.nextLine();
			String inc = sc.nextLine();
			sc.nextLine();
			System.out.println(booking);
			System.out.println(bed);
			System.out.println(inc.trim());
		}
		System.exit(0);
	}

}
