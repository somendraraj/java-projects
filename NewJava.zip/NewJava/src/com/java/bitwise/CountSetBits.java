package com.java.bitwise;

import java.util.Comparator;

public class CountSetBits implements Comparator<Integer>{

	/**
	 * 
	 * @param n
	 * @return
	 */
	static int countSetBits(int n) {
		int count = 0;
		while (n > 0) {
			count += n & 1;
			n >>= 1;
		}
		return count;

	}
	
	
	/**
	 * Brian Kernighan�s Algorithm
	 * 
	 * @param n
	 * @return
	 */
	static int countSetBits1(int n){
		int count = 0;
		while(n>0){
			n&=(n-1);
			count++;
		}
		return count;
	}

	public static void main(String args[]) {
		int n = 1023;
		System.out.println(countSetBits(n));
		System.out.println(countSetBits1(n));
		
		System.out.println(new CountSetBits().compare(3,2));
	}

	@Override
	public int compare(Integer o1, Integer o2) {
		if(o1!=o2)
			return o1-o2;
		return o1.compareTo(o2);
	}

}
