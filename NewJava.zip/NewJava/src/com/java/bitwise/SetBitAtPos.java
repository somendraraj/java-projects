package com.java.bitwise;

public class SetBitAtPos {
	
	static int setBitAtPos(int n, int pos){
		return n|(1<<pos);
	}
	
	public static void main(String args[]){
		
		int n = 10;
		int pos = 0;
		System.out.println(setBitAtPos(n, pos));
	}

}
