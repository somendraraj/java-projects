package com.java.stack;

import java.util.Stack;

class MyStack{
	
	Stack<Integer> stack;
	int min;
	
	public MyStack() {
		this.stack = new Stack<Integer>();
	}
	
	/*Print minimum element of stack*/
	void getMin(){
		if(stack.isEmpty()){
			System.out.println("Stack is empty");
		}
		System.out.println("Min element: "+min);
	}
	
	public void peek(){
		if(stack.isEmpty()){
			System.out.println("Stack is empty");
			return;
		}
		int top = stack.peek();
		System.out.print("Top element: ");
		if(top<min){
			System.out.println(min);
		}else{
			
			System.out.println(top);
		}
	}
	
	public void pop(){
		if(stack.isEmpty()){
			System.out.println("Stack is empty");
			return;
		}
		
		int top = stack.pop();
		System.out.print("Poped Element: ");
		if(top<min){
			System.out.println(min);
			min = 2*min - top;
		}else{
			System.out.println(top);
		}
	}
	
	
	public void push(int x){
		System.out.print("Pushed Element: ");
		if(stack.isEmpty()){
			min = x;
			stack.push(x);
			System.out.println(x);
			return;
		}
		
		if(x<min){
			int i = 2*x - min;
			stack.push(i);
			System.out.println(i);
			min = x;
		}else{
			stack.push(x);
			System.out.println(x);
		}
	}
	
	
};

public class GetMinStack {
	
	public static void main(String args[]){
		MyStack stack = new MyStack();
		stack.push(4);
		stack.pop();
		stack.push(2);
		stack.push(2);
		stack.getMin();
		stack.push(5);
		stack.push(8);
		stack.push(1);
		stack.peek();
		stack.getMin();
	}
}
