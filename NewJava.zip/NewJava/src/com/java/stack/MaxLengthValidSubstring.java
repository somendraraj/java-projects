package com.java.stack;

import java.util.Stack;

public class MaxLengthValidSubstring {
	
	private static int findMaxLength(String str){
		int n = str.length();
		Stack<Integer> stack = new Stack<Integer>();
		stack.push(-1);
		int res = 0;//initialize result
		for(int i=0;i<n;i++){
			if(str.charAt(i)=='('){
				stack.push(i);
			}else{
				stack.pop();
				
				if(!stack.isEmpty()){
					res = Math.max(res, i-stack.peek());
				}else{
					stack.push(i);
				}
			}
		}
		return res;
	}
	
	public static void main(String args[]){
		String str = "()(()))))";
		System.out.println(findMaxLength(str));
	}

}
