package com.java.stack;

import java.util.Scanner;
import java.util.Stack;

public class BalancedBracket {
	
	private static boolean isBalancedBracket(String str){
		
		char[] ch = str.toCharArray();
		
		Stack<Character> stack = new Stack<Character>(); 
		
		for(int i=0;i<str.length();i++){
			if(ch[i]=='(' ){
				stack.push(')');
			}else if( ch[i]=='{'){
				stack.push('}');
			}else if ( ch[i]=='['){
				stack.push(']');
			}else{
				if(stack.isEmpty() || stack.lastElement()!=ch[i]){
					return false;
				}
				stack.pop();
			}
		
		}
		
		if(stack.isEmpty()){
			return true;
		}
		return false;
	}
	
	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		
		String str = sc.nextLine();
		
		System.out.println(isBalancedBracket(str));
		
	}

}
