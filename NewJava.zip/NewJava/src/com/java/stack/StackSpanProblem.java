package com.java.stack;

public class StackSpanProblem {
	
	private static void span(int[] arr, int n, int[] s){
		s[0] = 1;
		
		for(int i=1;i<n;i++){
			s[i] = 1;
			for(int j=i-1;(j>=0)&&(arr[i]>=arr[j]);j--)
				s[i]++;
		}
	}
	
	public static void printArray(int[] arr){
		for(int i: arr){
			System.out.print(i+" ");
		}
		System.out.println();
	}
	
	public static void main(String args[]){
		int price[] = {10, 4, 5, 90, 120, 80};
        int n = price.length;
        int S[]= new int[n];
         
        // Fill the span values in array S[]
        span(price, n, S); 
         
        // print the calculated span values
        printArray(S);
	}

}
