package com.java.stack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;


public class Snippet {
	static float getMedian(List<Integer> arr) {
		int size = arr.size();
		if(size==1){return (float)arr.get(0);}
		if(size==2){return (float)(arr.get(0)+arr.get(1))/2;}
		Map<Integer, Integer> map = new TreeMap<Integer, Integer>();
		int key = 0;
		System.out.println(arr);
		for (Integer i : arr) {
			map.put(key++, i);
			System.out.println(map);
			float val = computeMedian(map);
			System.out.println(val);
		}
		return 0;
	}
	
	static float computeMedian(Map<Integer, Integer> map){
		int size = map.size();
		if(map.size()%2==0){
			return (float)(map.get(size/2)+map.get(size/2-1));
		}else{
			return (float) map.get(size/2);
		}	
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		List<Integer> a = new ArrayList<Integer>();
		for (int a_i = 0; a_i < n; a_i++) {
			a.add(in.nextInt());
			float med = getMedian(a);
			System.out.println(med);
		}
		
	}
}
