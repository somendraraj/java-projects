package com.java.stack;

import java.util.LinkedList;
import java.util.Queue;

public class StackUsingQueue {
	
	Queue<Integer> q = new LinkedList<Integer>();
	
	public void push(int val){
		int size = q.size();
		q.add(val);
		for(int i=0;i<size;i++){
			int x = q.remove();
			q.add(x);
		}
	}
	
	
	public int pop(){
		if(q.isEmpty()){
			System.out.println("Stack is empty");
			return -1;
		}
		int x = q.remove();
		return x;
	}
	
	public int top(){
		if(q.isEmpty()){
			System.out.println("Stack is empty");
			return -1;
		}
		return q.peek();
	}
	
	public static void main(String args[]){
		
		StackUsingQueue s = new StackUsingQueue();
		s.push(1);
		s.push(2);
		s.push(3);
		s.push(4);
		s.push(5);
		System.out.println(s.top());
		System.out.println(s.pop());
		System.out.println(s.pop());
		System.out.println(s.top());
	
		
	}

}
