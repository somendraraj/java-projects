package com.java.stack;

import java.util.HashMap;
import java.util.Map;

public class NextGreaterElement {
	
	
	private static void nextGreaterElements(int[] arr, int n){
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		for(int i=0;i<n-1;i++){
			int count = 0;
			for(int j=i+1;j<n;j++){
				if(arr[i]<arr[j]){
					System.out.println(arr[i]+"->"+arr[j]);
					count++;
					break;
				}
			}
			if(count==0){System.out.println(arr[i]+"->"+-1);}
		}
		System.out.println(arr[n-1]+"->"+-1);
	}
	
	public static void main(String args[]){
		
		int arr[] = {4, 5, 2, 25};
		nextGreaterElements(arr, 4);
	}

}
