package com.java.stack;

import java.util.Scanner;
import java.util.Stack;

public class TextEditor {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		Stack<String> stack = new Stack<>();
		while (n-- > 0) {
			int key = sc.nextInt();
			String s;
			int val = 0;
			if (key == 1) {
				s = sc.nextLine();
				if (!stack.isEmpty()) {
					String str = stack.peek();
					stack.pop();
					if(str.isEmpty()){stack.push(str);}
						stack.push(s.trim());
				} else {
					stack.push(s.trim());
				}
			} else if (key == 2) {
				val = sc.nextInt();
				String st = stack.peek();
				// stack.pop();
				st = st.substring(0, st.length()-val);
				stack.push(st);
			} else if (key == 3) {
				val = sc.nextInt();
				System.out.println(stack.size());
				if(!stack.isEmpty()){
					System.out.println(stack.peek().charAt(val - 1));
				}else{
					System.out.println("");
				}
					
			} else if (key == 4) {
				if (!stack.isEmpty())
					stack.pop();
				else
					stack.push("");
			}
			//System.out.println(stack);
		}
	}

}
