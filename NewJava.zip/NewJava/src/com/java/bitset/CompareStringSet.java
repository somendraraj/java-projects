package com.java.bitset;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class CompareStringSet {
	
	
	private static void printResult(int n, String[] str, String cStr){
		Set<Integer> integerSet = new TreeSet<Integer>();
		Set<String> stringSet = new TreeSet<String>();
		Map<String, String> map = new HashMap<String, String>();
		Map<Integer, String> imap = new HashMap<Integer, String>();
		String[] keys = cStr.split(" ");
		int key = Integer.parseInt(keys[0]);
		if(key==0){
			key = key+1;
		}
		System.out.println(key);
		for(int i=0;i<n;i++){
			String[] val = str[i].split(" ");
			if(keys[2].equals("lexicographic")){
				stringSet.add(val[key-1]);
				map.put(val[key-1], str[i]);
			}else{
				integerSet.add(Integer.parseInt(val[key-1]));
				imap.put(Integer.parseInt(val[key-1]), str[i]);
			}
		}
		//System.out.println(integerSet);
		//System.out.println(map);
		if(keys[1].equals("false")){
			if(keys[2].equals("lexicographic")){
				for(String i: stringSet ){
					System.out.println(map.get(i));
				}
			}else{
				for(int i: integerSet ){
					System.out.println(imap.get(i));
				}
			}
		}else{
			if(keys[2].equals("lexicographic")){
				List<String> list = new ArrayList<String>();
				list.addAll(stringSet);
				stringSet.clear();
			    Collections.reverse(list);
				for(String i: list ){
					System.out.println(map.get(i));
				}
			}else{
				List<Integer> list = new ArrayList<Integer>();
				list.addAll(integerSet);
				integerSet.clear();
			    Collections.reverse(list);
				for(int i: integerSet ){
					System.out.println(imap.get(i));
				}
			}
		}
	}
	
	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.nextLine();
		String[] str = new String[n];
		for(int i=0;i<n;i++){
			str[i] = sc.nextLine();
		}
		String ss = sc.nextLine();
		
		printResult(n, str, ss);
		
	}

}
