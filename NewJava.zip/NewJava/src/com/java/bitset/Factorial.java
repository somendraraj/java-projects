package com.java.bitset;

import java.math.BigInteger;
import java.util.Scanner;

public class Factorial {

	static int countPairs(String n) {
		
		
		return 1;
		

	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String n = in.next();
		int result = countPairs(n);
		System.out.println(result);
		in.close();
	}

}
