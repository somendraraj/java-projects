package com.java.bitset;

public class IntegerSum {

	public static void main(String[] args) {
		
		
		int sum = 0;
		int val1 = Integer.MAX_VALUE;
		int val2 = Integer.MAX_VALUE;
		
		sum = val1+val2;
		int sum1 = 0;
		int sum2 = 0;
		
		sum1 = val1+1;
		sum2 = val1+0;
		System.out.println(sum);
		System.out.println(sum1);
		System.out.println(sum2);

	}

}
