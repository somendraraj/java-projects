package com.java.bitset;

import java.util.BitSet;

public class BitSetDemo {

	private static Character m = '1';
	private static Character n = '0';

	private static void check(Character c) {
		if (c == m) {
			System.out.println("One");
		} else {
			System.out.println("Zero");
		}
	}

	private static void bitSet() {
		BitSet bits = new BitSet(16);
		BitSet bits1 = new BitSet(16);

		// set some bits
		for (int i = 0; i < 16; i++) {
			if ((i % 2) == 0){
				bits.set(i);
			}
			if ((i % 5) != 0){
				bits1.set(i);
			}		
		}
		System.out.println(bits);
		System.out.println(bits1);
		
		//bits.and(bits1);
		
		//bits1.and(bits);
		
		bits.or(bits);
		
		System.out.println(bits);
	}

	public static void main(String[] args) {

		System.out.println("this is test");

		Character c = '1';

		check(c);
		bitSet();

	}

}
