package com.java.numbers;

public class MaxRainWater {

	public int maxArea(int[] height) {
		int result = 0;
		int leftMax = 0, rightMax = 0;
		int lo = 0, hi = height.length - 1;
		int li = 0, ri = hi;
		while (lo <= hi) {
			if (height[lo] < height[hi]) {
				if (height[lo] > leftMax) {
					leftMax = height[lo];
					li = lo;
				} else {
					result += leftMax - height[lo];
					lo++;
				}

			} else {
				if (height[hi] > rightMax) {
					rightMax = height[hi];
					ri = hi;
				} else {
					result += rightMax - height[hi];
					hi--;
				}

			}
		}
		// System.out.println(li+" "+ri+" "+leftMax+" "+rightMax);
		result = (rightMax - leftMax) * (ri - li + 1);
		return result;
	}

	public static void main(String args[]) {

	}

}
