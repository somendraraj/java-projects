package com.java.numbers;

public class PalindromeNumbers {

	public static boolean isPalindrome(int x) {

		if (x < 0) {
			return false;
		}
		int low = 0;
		char[] ch = String.valueOf(x).toCharArray();
		int high = ch.length - 1;

		while (low < high) {
			if (ch[low] != ch[high]) {
				return false;
			}
			low++;
			high--;
		}
		return true;
	}

	public static void main(String args[]){
		int x = 121;
		System.out.println(isPalindrome(x));
	}
}
