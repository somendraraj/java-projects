package com.java.numbers;

public class ZigZagConversion {
	
	public static String zigZagConversion(String str, int n){
		if(str==null)
			return str;
		int gap = (n-1)<<1;
		if(n==1)
			return str;
		StringBuilder sb = new StringBuilder();
		for(int i=0;i<n;i++){
			int c= i;
			int offset = gap-(i<<1);
			while(c<str.length()){
				if(offset != 0){
					sb.append(str.charAt(c));
					c +=offset;
				}
				offset = gap-offset;
			}
		}
		return sb.toString();
	}
	
	
	public static void main(String args[]){
		String str = "PAYPALISHIRING";
		int n = 4;
		System.out.println(zigZagConversion(str, n));
	}

}
