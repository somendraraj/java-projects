package com.java.numbers;

import java.util.Stack;

public class DecodeString {

	public String decode(String s) {
		Stack<Integer> intStack = new Stack();
		Stack<Character> charStack = new Stack<Character>();
		String temp = "", res = "";
		for (int i = 0; i < s.length(); i++) {
			int count = 0;
			if (Character.isDigit(s.charAt(i))) {
				while (Character.isDigit(s.charAt(i))) {
					count = count * 10 + s.charAt(i) - '0';
					i++;
				}
				i--;
				intStack.push(count);

			} else if (s.charAt(i) == ']') {
				temp = "";
				count = 0;

				if (!intStack.isEmpty()) {
					count = intStack.peek();
					intStack.pop();
				}

				while (!charStack.isEmpty() && charStack.peek() != '[') {
					temp = charStack.peek() + temp;
					charStack.pop();
				}

				if (!charStack.empty() && charStack.peek() == '[')
					charStack.pop();

				for (int j = 0; j < count; j++) {
					res = res + temp;
				}

				for (int j = 0; j < res.length(); j++)
					charStack.push(res.charAt(j));

				res = "";

			} else if (s.charAt(i) == '[') {
				if (Character.isDigit(s.charAt(i - 1)))
					charStack.push(s.charAt(i));

				else {
					charStack.push(s.charAt(i));
					intStack.push(1);
				}
			} else {
				charStack.push(s.charAt(i));
			}
		}

		while (charStack.isEmpty()) {
			res = charStack.peek() + res;
			charStack.pop();
		}
		return res;
	}

	public String decodeString(String s) {

		Stack<Integer> intStack = new Stack();
		Stack<Character> charStack = new Stack();
		String temp = "", res = "";
		for (int i = 0; i < s.length(); i++) {
			int count = 0;
			if (Character.isDigit(s.charAt(i))) {
				while (Character.isDigit(s.charAt(i))) {
					count = count * 10 + s.charAt(i) - '0';
					i++;
				}
				i--;
				intStack.push(count);
			}
			// If closing bracket ']', pop elemment until
			// '[' opening bracket is not found in the
			// character stack.
			else if (s.charAt(i) == ']') {
				temp = "";
				count = 0;

				if (!intStack.isEmpty()) {
					count = intStack.peek();
					intStack.pop();
				}

				while (!charStack.isEmpty() && charStack.peek() != '[') {
					temp = charStack.peek() + temp;
					charStack.pop();
				}

				if (!charStack.empty() && charStack.peek() == '[')
					charStack.pop();

				// Repeating the popped string 'temo' count
				// number of times.
				for (int j = 0; j < count; j++)
					res = res + temp;

				// Push it in the character stack.
				for (int j = 0; j < res.length(); j++)
					charStack.push(res.charAt(j));

				res = "";
			}

			// If '[' opening bracket, push it into character stack.
			else if (s.charAt(i) == '[') {
				if (Character.isDigit(s.charAt(i - 1)))
					charStack.push(s.charAt(i));

				else {
					charStack.push(s.charAt(i));
					intStack.push(1);
				}
			}

			else
				charStack.push(s.charAt(i));
		}

		// Pop all the elmenet, make a string and return.
		while (!charStack.isEmpty()) {
			res = charStack.peek() + res;
			charStack.pop();
		}

		return res;

	}

}
