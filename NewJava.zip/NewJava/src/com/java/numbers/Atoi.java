package com.java.numbers;

import java.util.Scanner;

public class Atoi {

	static int zero = 0;
	static int min = Integer.MIN_VALUE;
	static int max = Integer.MAX_VALUE;

	public static int myAtoi(String str) {
		str = str.replaceFirst("^\\s+(?!$)", "");
		System.out.println(str);
		StringBuilder sb = new StringBuilder();
		boolean isNegative = false;
		if (str.length() == 0)
			return 0;
		int start = 0;
		if (str.charAt(0) == '-') {
			isNegative = true;
			start = 1;
		} else if (str.charAt(0) == '+') {
			start = 1;
		}

		for (int i = start; i < str.length(); i++) {
			if (Character.isDigit(str.charAt(i)))
				sb.append(str.charAt(i));
			else
				break;
		}

		return processString(sb.toString(), isNegative);

	}

	public static String removeZero(String str) {
		int i = 0;
		while (str.charAt(i) == '0')
			i++;

		StringBuffer sb = new StringBuffer(str);
		sb.replace(0, i, "");

		return sb.toString();
	}

	static int processString(String str, boolean isNegative) {
		System.out.println(str);
		if (str.trim().length() == 0) {
			return zero;
		}
		
		str = str.replaceFirst("^0+(?!$)", "");
		//str = removeZero(str);
		
		if (str.length() == 0) {
			return zero;
		}
		
		if (str.length() > 10) {
			if (isNegative) {
				return min;
			} else {
				return max;
			}
		}
		System.out.println("ten"+str);
		if (str.length() == 10) {
			if (isNegative && Long.parseLong(str) >= max ) {
				return min;
			} else if (!isNegative && Long.parseLong(str) >= max) {
				return max;
			}
		}

		int i = Integer.parseInt(str);
		if (isNegative) {
			return -i;
		}
		return i;
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		System.out.println("Res: "+myAtoi(s));

		System.out.println("Max: "+max);
		System.out.println("Min: "+min);
		System.out.println(Integer.parseInt("0000000000012345678"));

	}

}
