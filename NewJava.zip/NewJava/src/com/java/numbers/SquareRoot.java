package com.java.numbers;

public class SquareRoot {

	static int getSquareRoot(int n) {

		if (n == 0 || n == 1) {
			return n;
		}
		int i = 1, result = 1;
		while (result <= n) {
			if (result == n)
				return i;
			i++;
			result = i * i;
		}
		return i - 1;
	}

	public static void main(String args[]) {
		int n = 36;
		System.out.println(getSquareRoot(n));
	}

}
