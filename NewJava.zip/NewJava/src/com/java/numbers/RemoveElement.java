package com.java.numbers;

public class RemoveElement {
	
	static int removeElement(int[] arr, int val){
		if(arr.length==0)
			return 0;
		int length = 0;
		for(int i=0;i<arr.length;i++){
			if(arr[i]!=val)
				arr[length++] = arr[i];
		}
		return length;
	}
	
	public static void main(String args[]){
		
		int[] arr = {1, 2,2,2,3,3,4};
		int val = 2;
		int len = removeElement(arr, val);
		System.out.println(len);
		print(arr, len);
	}
	
	static void print(int[] arr, int len){
		for(int i=0;i<len;i++)
			System.out.print(arr[i]+" ");
	}

}
