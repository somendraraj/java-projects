package com.java.numbers;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class AccessToken {
	
	public static Set<String> commandSet = new HashSet<String>();

	public static void main(String args[]) {

		String time = Long.valueOf(new Date().getTime()).toString();

		System.out.println(time);
		
		String str = "";
		
		
		
		
		
		addCommandsIntoSet(str);
		System.out.println(commandSet);

	}
	
	private static void addCommandsIntoSet(String commands){
		String[] str = commands.split(",");
		for(String s: str){
			commandSet.add(s);
		}
	}
}
