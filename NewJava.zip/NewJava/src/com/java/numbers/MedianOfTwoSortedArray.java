package com.java.numbers;

import java.util.Arrays;

public class MedianOfTwoSortedArray {

	static int max(int a, int b) {
		return a > b ? a : b;
	}

	static int min(int a, int b) {
		return a < b ? a : b;
	}

	static float mo2(int a, int b) {
		return (float) ((a + b) / 2.0);
	}

	// A utility function to find median of three integers
	static float mo3(int a, int b, int c) {
		return a + b + c - max(a, max(b, c)) - min(a, min(b, c));
	}

	// A utility function to find median of four integers
	static float mo4(int a, int b, int c, int d) {
		int Max = max(a, max(b, max(c, d)));
		int Min = min(a, min(b, min(c, d)));
		return (float) ((a + b + c + d - Max - Min) / 2.0);
	}

	// Utility function to find median of single array
	static float medianSingle(int arr[], int n) {
		if (n == 0)
			return -1;
		if (n % 2 == 0)
			return (float) ((double) (arr[n / 2] + arr[n / 2 - 1]) / 2);
		return arr[n / 2];
	}

	// This function assumes that N is smaller than or equal to M
	// This function returns -1 if both arrays are empty

	static float findMedian(int A[], int N, int B[], int M) {
		if (N > M)
			return findMedianUtil(B, M, A, N);

		return findMedianUtil(A, N, B, M);
	}

	static float findMedianUtil(int a[], int n, int[] b, int m) {
		if (n == 0) {
			return medianSingle(b, m);
		}
		if (n == 1) {
			if (m == 1) {
				return mo2(a[0], b[0]);
			}

			if ((m & 1) == 1) {
				return mo2(b[m / 2], (int) mo3(a[0], b[m / 2 - 1], b[m / 2 + 1]));
			}

			return mo3(b[m / 2], b[m / 2 - 1], a[0]);
		} else if (n == 2) {
			if (m == 2) {
				return mo4(a[0], a[1], b[0], b[1]);
			}

			if ((m & 1) == 1) {
				return mo3(b[m / 2], max(a[0], b[m / 2 - 1]), min(a[1], b[m / 2 + 1]));
			}

			return mo4(b[m / 2], b[m / 2 - 1], max(a[0], b[m / 2 - 1]), min(a[1], b[m / 2 + 1]));

		}

		int idxA = (n - 1) / 2;
		int idxB = (m - 1) / 2;

		if (a[idxA] <= b[idxB]) {
			Arrays.copyOfRange(a, idxA, a.length);
			return findMedianUtil(a, n / 2 + 1, b, m - idxA);
		} else {
			Arrays.copyOfRange(b, idxB, b.length);
		}
		return findMedianUtil(a, n / 2 + 1, b, m - idxA);
	}

	public static void main(String arg[]) {
		int[] a = { 1, 2, 2 };
		int[] b = { 1, 2, 3 };
		int n = a.length;
		int m = b.length;
		float res = findMedian(a, n, b, m);

		System.out.println(res);
		System.out.println(findMedianSortedArrays(a, b));
		
		int min = Integer.MIN_VALUE;
		int max = Integer.MAX_VALUE;
		String x = "2147483648";
		String y = "2147483647";
		System.out.println(min +" "+max);
		System.out.println(Integer.parseInt(y));
	}

	public static double findMedianSortedArrays(int[] nums1, int[] nums2) {
		// nums1 and nums2 are not empty
		int m = nums1.length;
		int n = nums2.length;
		boolean isEven = ((m + n) % 2 == 0);
		if (m > n)
			return findMedian(nums1, nums2, isEven);
		else
			return findMedian(nums2, nums1, isEven);
	}

	public static double findMedian(int[] a, int[] b, boolean isEven) {
		int m = b.length;
		int n = a.length;
		int imin = 0;
		int imax = m;
		double left_max;
		double right_min;
		while (imin <= imax) {
			int i = (imin + imax) / 2;
			int j = (m + n) / 2 - i;
			if (i < m && a[j - 1] > b[i])
				imin = i + 1;
			else if (i > 0 && b[i - 1] > a[j])
				imax = i - 1;
			else {
				if (i == m)
					right_min = a[j];
				else if (j == n)
					right_min = b[i];
				else
					right_min = Math.min(b[i], a[j]);

				if (!isEven)
					return right_min;

				if (i == 0)
					left_max = a[j - 1];
				else if (j == 0)
					left_max = b[i - 1];
				else
					left_max = Math.max(b[i - 1], a[j - 1]);

				return (right_min + left_max) / 2;
			}
		}
		return 0;
	}
	
	
}
