package com.java.numbers;

import java.util.ArrayList;
import java.util.List;

public class GenerateAllParenthesis {

	public static List<String> generateParanthesis(int n) {
		char[] str = new char[2 * n];
		List<String> list = new ArrayList<String>();
		if (n > 0)
			_printParenthesis(str, 0, n, 0, 0, list);
		System.out.println(list.size());
		return list;
	}

	static void _printParenthesis(char[] str, int pos, int n, int open, int close, List<String> list) {
		if (close == n) {
			String s = "";
			for (int i = 0; i < str.length; i++)
				s += str[i];
			list.add(s);
			return;
		} else {
			if (open > close) {
				str[pos] = ')';
				_printParenthesis(str, pos + 1, n, open, close + 1, list);
			}
			if (open < n) {
				str[pos] = '(';
				_printParenthesis(str, pos + 1, n, open + 1, close, list);
			}
		}
	}

	public static void main(String args[]) {
		int n = 5;
		System.out.println(generateParanthesis(n));
	}

}
