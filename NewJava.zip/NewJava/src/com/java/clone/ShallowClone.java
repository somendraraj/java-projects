package com.java.clone;

import java.util.Arrays;

/**
 * clone or copy the one object to another
 * @author Somendra1.Raj
 *
 */
public class ShallowClone {
	
	private int[] data;
	
	public ShallowClone(int[] value){
		this.data = value;
	}
	
	public void showData(){
		System.out.println(Arrays.toString(this.data));
	}
	
	
	public static void main(String args[]){
		int[] val = {1,2,3,4,5};
		int[] val2 = {5,4,3,2,1};
		//new ShallowClone(val);
		
		new ShallowClone(val).showData();
		new ShallowClone(val2).showData();
		
	}
}
