package com.java.queue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import com.java.thread.ThreadPoolManager;

public class FileReaderUtil {

	public static volatile boolean finished = false;

	static File TARGET_FILE = new File("jiochat_sample.txt");

	public void generateReport() throws InterruptedException {

		BlockingQueue<String[]> queue = new LinkedBlockingQueue<String[]>(11);

		final Thread readerThread = new Thread("File Reader Thread") {
			public void run() {
				try {
					System.out.println("Run Method Inside Reader Thread");
					FileReader fileWriter = new FileReader(TARGET_FILE);
					BufferedReader br = new BufferedReader(fileWriter);
					String input = "";
					try {
						while ((input = br.readLine()) != null) {
							System.out.println("Line:" + input);
							String[] line = input.split("\\|");
							// queue.add(line);
							if (queue.size() <= 10) {
								queue.add(line);
							} else { // if queue is full
								// then sleep for 50 // millisecond
								Thread.sleep(50);
								queue.add(line);
								continue;
							}
						}
					} catch (IOException e) {
						e.printStackTrace();
						return;
					} finally {
						try {
							if (br != null)
								br.close();

							if (fileWriter != null)
								fileWriter.close();

						} catch (Exception e) {

						}
					}
					finished = true;
				} catch (Throwable e) {
					e.printStackTrace();
					return;
				}
			}
		};

		// thread to read data from queue and put into redis as well as send
		// mesage to customer
		final Thread writerThread = new Thread("Writer Thread") {
			public void run() {
				try {
					System.out.println("Run Method Inside Writer Thread");
					ArrayList<String[]> list = new ArrayList<>();
					while (!finished) {
						String[] str = queue.poll(100, TimeUnit.MILLISECONDS);
						if (str != null && str.length > 0) {
							// System.out.println(Arrays.toString(str));
							list.add(str);
						} else {
							Thread.sleep(20);
							continue;
						}
						// System.out.println("List: " + list);
						if (list.size() >= 10) {
							// query db and persist it to redis
							ArrayList<String[]> newList = new ArrayList<>();
							newList.addAll(list);// = (ArrayList<String[]>) list.clone();
							System.out.println("New List: " + newList);
							ThreadPoolManager.execute(new Worker(newList));
							Thread.sleep(10);
							list.clear();
							// ThreadPoolManager.exec(new
							// GetUserIdByMobileNumber(items));
						}
					}

					// remaining part
					ArrayList<String[]> newList = new ArrayList<>();
					newList.addAll(list);// = (ArrayList<String[]>) list.clone();
					System.out.println("New List1: " + newList);
					ThreadPoolManager.execute(new Worker(list));
					Thread.sleep(10);
					list.clear();

				} catch (Throwable e) {
					System.out.println("Error in reader thread...");
					e.printStackTrace();
					return;
				}
			}
		};
		long startTime = System.currentTimeMillis();
		System.out.println(
				"**************" + readerThread.getName() + " Thread Started************" + new Date().getDate());
		
		readerThread.start();
		writerThread.start();
		System.out.println("Waiting for join...");
		//readerThread.join();
		writerThread.join();
		System.out.println("Exit:" + (System.currentTimeMillis() - startTime));
		System.out.println("**************Writer Thread Ended************" + new Date().getDate());

	}

	private class Worker implements Runnable {
		private List<String[]> items;

		public Worker(List<String[]> items) {
			this.items = items;
		}

		@Override
		public void run() {
			System.out.println("Worker Thread Started\n");
			for (String[] s : items) {
				String[] str = s;
				count++;
				for (String i : str) {
					System.out.print(i + " ");
				}
				System.out.println();
			}
		}

	}

	static int count = 0;

	public static void main(String args[]) {
		FileReaderUtil obj = new FileReaderUtil();

		ThreadPoolManager.initialize(10);

		try {
			obj.generateReport();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Count: " + count);
	}

}
