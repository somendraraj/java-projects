package com.java.queue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class BlockingQueueTest {

	static final BlockingQueue<String[]> queue = new LinkedBlockingQueue<String[]>(100000);
	
	public static void main(String args[]) throws InterruptedException{
		
		String st = "7021780510||MRP 399|18-03-2018";
		String[] input = st.split("\\|");
				
		for(String s: input){
			System.out.println(s);
		}
		for(int i=0;i<100000;i++){
			queue.add(input);
		}
		int k =0;
		while(!queue.isEmpty()){
			String[] str = queue.poll(100, TimeUnit.MILLISECONDS);
			for(String s: str){
				System.out.print(s+" ");
			}
			System.out.println(k++ +"");
		}


		
	}
	
}
