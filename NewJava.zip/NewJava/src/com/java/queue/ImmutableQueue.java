package com.java.queue;

import java.util.NoSuchElementException;

public class ImmutableQueue<E> {

	// Two stacks are used. One is to add items to the queue(enqueue) and
	// other is to remove them(dequeue)

	private ReversableStack<E> order;

	private ReversableStack<E> reverse;

	private ImmutableQueue(ReversableStack<E> order, ReversableStack<E> reverse) {
		this.order = order;
		this.reverse = reverse;
	}

	// Initially both stack are empty
	public ImmutableQueue() {
		this.order = ReversableStack.emptyStack();
		this.reverse = ReversableStack.emptyStack();
	}

	// Enque
	public ImmutableQueue<E> enqueue(E e){
		if(null == e)
			throw new IllegalArgumentException();
		return new ImmutableQueue<E>(this.order.push(e), this.reverse);
	}

	// DEqueue
	public ImmutableQueue<E> dequeue() {
		if (this.isEmpty()) {
			throw new NoSuchElementException();
		}
		if (!this.reverse.isEmpty()) {
			return new ImmutableQueue<E>(this.order, this.reverse.tail);
		} else {

			return new ImmutableQueue<E>(ReversableStack.emptyStack(), this.order.getReverseStack().tail);
		}
	}

	private static class ReversableStack<E> {
		private E head;
		private ReversableStack<E> tail;
		private int size;

		// Initialize stack parameters
		private ReversableStack(E obj, ReversableStack<E> tail) {
			this.head = obj;
			this.tail = tail;
			this.size = tail.size + 1;
		}

		// return new empty stack
		public static ReversableStack emptyStack() {
			return new ReversableStack();
		}

		private ReversableStack() {
			this.head = null;
			this.tail = null;
			this.size = 0;
		}

		// Reverses the original stack
		public ReversableStack<E> getReverseStack() {
			ReversableStack<E> stack = new ReversableStack<E>();
			ReversableStack<E> tail = this;
			while (!tail.isEmpty()) {
				stack = stack.push(tail.head);
				tail = tail.tail;
			}
			return stack;
		}

		public boolean isEmpty() {
			return this.size == 0;
		}

		public ReversableStack<E> push(E obj) {
			return new ReversableStack<E>(obj, this);
		}
	}

	private void normaliseQueue() {
		this.reverse = this.order.getReverseStack();
		this.order = ReversableStack.emptyStack();
	}

	public E peek() {
		if (this.isEmpty())
			throw new NoSuchElementException();
		if (this.reverse.isEmpty())
			normaliseQueue();
		return this.reverse.head;
	}

	public boolean isEmpty() {
		return size() == 0;
	}

	// returns the number of items currently in the queue
	public int size() {
		return this.order.size + this.reverse.size;
	}

	public static void main(String args[]) {
		ImmutableQueue<Integer> newQueue = new ImmutableQueue<Integer>();
		newQueue = newQueue.enqueue(5);
		newQueue = newQueue.enqueue(10);
		newQueue = newQueue.enqueue(15);
		int x = newQueue.size();
		// ImmutableQueue<Integer> x = newQueue.dequeue();
		System.out.println(x);
	}

}
