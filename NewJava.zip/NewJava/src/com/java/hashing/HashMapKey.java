package com.java.hashing;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class HashMapKey {

	public static void main(String args[]) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		map.containsValue(1);
		map.put(null, null);
		map.put(1, null);
		
		
		map.put(2, null);
		
		System.out.println(map);
		
		Map<Integer, Integer> map1 = new Hashtable<>();
		map1.put(1, 1);
		//map1.put(null,null);
		System.out.println(map1);
		
	}

}
