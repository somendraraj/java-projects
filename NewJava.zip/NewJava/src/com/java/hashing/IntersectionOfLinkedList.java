package com.java.hashing;

/*This class is used to find the intersection of two linkedlist */

public class IntersectionOfLinkedList {

	Node head;// head node

	class Node {
		Node next;
		int data;

		public Node(int data) {
			this.data = data;
			this.next = null;
		}
	}

	private void getUnion(Node head1, Node head2) {
		Node t1 = head1, t2 = head2;

		while (t1 != null) {
			pushNode(t1.data);
			t1 = t1.next;
		}
		
		while(t2 != null){
			if(!isPresent(head2, t2.data)){
				pushNode(t2.data);
			}
			t2=t2.next;
		}
	}
	
	private void getIntersection(Node head1, Node head2){
		
	}

	private void pushNode(int data) {
		Node newNode = new Node(data);
		newNode.next = head;
		head = newNode;
	}
	
	private boolean isPresent(Node head, int data){
		Node temp = head;
		while(temp != null){
			if((temp.data)==data)
				return true;
			temp  = temp.next;
		}
		return false;
	}

	public static void main(String args[]) {

	}

}