package com.java.hashing;

import java.util.HashMap;
import java.util.Random;

public class URLShortener {

	private HashMap<String, String> keyMap; // key-url map
	private HashMap<String, String> valueMap; // url-key map to check whether an
												// url is
	// already entered in our system;

	// use this to generate custom url
	private String domain;

	// char array is used to character to number
	private char[] myChar;

	// used to generate random number
	private Random rand;

	// key length in url
	private int keyLength;

	// Default constructor
	public URLShortener() {
		keyMap = new HashMap<String, String>();
		valueMap = new HashMap<String, String>();
		rand = new Random();
		keyLength = 8;
		myChar = new char[62];
		for (int i = 0; i < 62; i++) {
			int j = 0;
			if (i < 10) {
				j = i + 48;
			} else if (i > 9 && i <= 35) {
				j = i + 55;
			} else {
				j = i + 61;
			}
			myChar[i] = (char) j;
		}

		domain = "http://google.co.in";

	}

	// constructor which enables you to define the tiny url
	URLShortener(int length, String newDomain) {
		this();
		this.keyLength = length;
		if (!newDomain.isEmpty()) {
			newDomain = sanitizeURL(newDomain);
			domain = newDomain;
		}
	}

	/**
	 * shortenURL the public method which can be called to shorten a given URL
	 * 
	 * @param longURL
	 * @return
	 */
	public String shortenURL(String longURL) {
		String shortURL = "";
		if (validateURL(longURL)) {
			longURL = sanitizeURL(longURL);
			if (valueMap.containsKey(longURL)) {
				shortURL = domain + "/" + valueMap.get(longURL);
			} else {
				shortURL = domain + "/" + getKey(longURL);
			}
		}
		// add http part
		return shortURL;
	}

	/**
	 * validate url
	 * 
	 * @param longURL
	 * @return
	 */
	private boolean validateURL(String longURL) {
		return true;
	}

	/**
	 * 
	 * public method which returns back the original URL given the shortened url
	 * 
	 * @param shortURL
	 * @return
	 */
	public String expandURL(String shortURL) {
		String longURL = "";
		String key = shortURL.substring(domain.length() + 1);
		longURL = keyMap.get(key);
		return longURL;
	}

	/**
	 * This method should take care various issues with a valid url e.g.
	 * www.google.com,www.google.com/, http://www.google.com,
	 * http://www.google.com/ all the above URL should point to same shortened
	 * URL There could be several other cases like these.
	 * 
	 * @param url
	 * @return
	 */
	String sanitizeURL(String url) {
		if (url.substring(0, 7).equals("http://"))
			url = url.substring(7);

		if (url.substring(0, 8).equals("https://"))
			url = url.substring(8);

		if (url.charAt(url.length() - 1) == '/')
			url = url.substring(0, url.length() - 1);
		return url;
	}

	/**
	 * 
	 * @param longURL
	 * @return
	 */
	private String getKey(String longURL) {
		String key;
		key = generateKey();
		keyMap.put(key, longURL);
		valueMap.put(longURL, key);
		return key;
	}

	/**
	 * 
	 * @return
	 */
	private String generateKey() {
		String key = "";
		boolean flag = true;
		while (flag) {
			key = "";
			for (int i = 0; i <= keyLength; i++) {
				key += myChar[rand.nextInt(62)];
			}
			// System.out.println("Iteration: "+ counter + "Key: "+ key);
			if (!keyMap.containsKey(key)) {
				flag = false;
			}
		}
		return key;
	}

	// test the code
	public static void main(String args[]) {
		URLShortener u = new URLShortener(5, "www.tinyurl.com/");
		String urls[] = new String[1000000];
		for(int i=0;i<1000000;i++){
			urls[i] = "www.goole.com"+"/path/"+i;
		}

		for (int i = 0; i < urls.length; i++) {
			System.out.println("URL:" + urls[i] + "\tTiny: " + u.shortenURL(urls[i]) + "\tExpanded: "
					+ u.expandURL(u.shortenURL(urls[i])));
		}
	}

}
