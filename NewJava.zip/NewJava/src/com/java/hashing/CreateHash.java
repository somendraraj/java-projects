package com.java.hashing;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class CreateHash {

	public static String makeSHA1Hash(String input) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		MessageDigest md = MessageDigest.getInstance("SHA1");
		md.reset();
		byte[] buffer = input.getBytes("UTF-8");
		md.update(buffer);
		byte[] digest = md.digest();
		StringBuilder hexStr = new StringBuilder();
		for (int i = 0; i < digest.length; i++) {
			hexStr.append(Integer.toString((digest[i] & 0xff) + 0x100, 16).substring(1));
		}
		return hexStr.toString();
	}

	public static String sha512(String passwordToHash, String salt) {
		String generatedPassword = null;
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(salt.getBytes(StandardCharsets.UTF_8));
			byte[] bytes = md.digest(passwordToHash.getBytes(StandardCharsets.UTF_8));
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < bytes.length; i++) {
				sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
			}
			generatedPassword = sb.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return generatedPassword;
	}

	public static void main(String args[]) throws NoSuchAlgorithmException, UnsupportedEncodingException {

		String inp = "hello";
		String hashCode = makeSHA1Hash(inp);
		System.out.println(hashCode);

		
		
		String hashCode1 = sha512(inp, "1234567890112345");
		System.out.println(hashCode1);

		// aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d
		// aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d

	}
}
