package com.java.hashing;

import java.util.HashMap;
import java.util.Map;

public class ItenaryList {

	private static void printItenaryList(Map<String, String> data) {
		String start = "";
		for(Map.Entry<String, String> map: data.entrySet()){
			String key = map.getKey();
			if(!data.containsValue(key))
				start = key;
		}
		int i=0;
		while(i!=data.size()){
			String val = data.get(start);
			if(val!=null && !(val.equals(""))){
				val = data.get(start);
				System.out.println(start+"->"+val);
				start = val;
				i++;
			}
		}
		
		/*for(Map.Entry<String, String> map: data.entrySet()){
			//String key = map.getKey();
			//String value = map.getValue();
			String val = data.get(start);
			System.out.println(start+"->"+val);
			
		}*/
		
		
		System.out.println(start);
	}

	public static void main(String args[]) {

		Map<String, String> data = new HashMap<String, String>();
		data.put("Chennai", "Banglore");
		data.put("Bombay", "Delhi");
		data.put("Goa", "Chennai");
		data.put("Delhi", "Goa");
		
		Long index = 0L;
		
		int ind = index.intValue();

		printItenaryList(data);

	}

}
