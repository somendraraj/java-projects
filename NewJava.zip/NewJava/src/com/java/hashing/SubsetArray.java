package com.java.hashing;

import java.util.HashMap;
import java.util.Map;

public class SubsetArray {

	private static boolean isSubsetArray(int[] arr1, int[] arr2) {
		int len1 = arr1.length;
		int len2 = arr2.length;
		int count = 0;
		for (int i = 0; i < len1; i++) {
			for (int j = 0; j < len2; j++) {
				if (arr2[j] == arr1[i]) {
					count++;
				}
			}
		}
		if (count == len2)
			return true;
		return false;
	}
	
	private static boolean isSubset(int[] arr1, int[] arr2){
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		for(int i=0;i<arr1.length;i++){
			map.put(arr1[i], 1);
		}
		int count = 0;
		for(int i=0;i<arr2.length;i++){
			if(map.containsKey(arr2[i])){
				count++;
			}
		}
		if(count ==arr2.length)
			return true;
		
		return false;
	}
	
	public static void main(String args[]) {
		int arr1[] = { 1, 2, 3, 4, 9, 6, 5, 8, 7 };
		int arr2[] = { 1, 3, 7, 5, 4 };
		System.out.println(isSubsetArray(arr1, arr2));
		System.out.println(isSubset(arr1, arr2));
	}

}
