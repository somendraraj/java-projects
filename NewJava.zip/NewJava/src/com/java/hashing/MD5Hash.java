package com.java.hashing;

import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

public class MD5Hash {

	public static void main(String args[]) throws NoSuchAlgorithmException, IOException {

		MessageDigest md = MessageDigest.getInstance("MD5");

		Date curr = new Date();
		long lo = curr.getTime();
		System.out.println(lo);
		int lo1 = curr.hashCode() + curr.hashCode();
		System.out.println(lo1);

		String date = String.valueOf(System.currentTimeMillis());

		byte[] dataBytes = new byte[1024];

		dataBytes = date.getBytes();
		md.update(dataBytes, 0, dataBytes.length);

		byte[] mdbytes = md.digest();

		// convert the byte to hex format method 1
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < mdbytes.length; i++) {
			sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
		}

		System.out.println("Digest(in hex format):: " + sb.toString());

		// convert the byte to hex format method 2
		StringBuffer hexString = new StringBuffer();
		for (int i = 0; i < mdbytes.length; i++) {
			String hex = Integer.toHexString(0xff & mdbytes[i]);
			if (hex.length() == 1)
				hexString.append('0');
			hexString.append(hex);
		}
		System.out.println("Digest(in hex format):: " + hexString.toString());
		
		System.out.println(makeMD5("test@123"));
		
		hash16("3089");
	}

	public static String makeMD5(String password) {
		if (password == null || password.equals("")) {
			return password;
		}
		MessageDigest md;
		try {
			// MD5
			md = MessageDigest.getInstance("MD5");
			// md5
			md.update(password.getBytes());
			// digest()md5 hash，8。md5 hash16hex，8
			// BigInteger816hex，；hash
			String pwd = new BigInteger(1, md.digest()).toString(16);
			return pwd;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return password;
	}
	
	
	public static void hash16(String str){
		try {
            String text = str;
            MessageDigest msg = MessageDigest.getInstance("MD5");
            msg.update(text.getBytes(), 0, text.length());
            String digest1 = new BigInteger(1, msg.digest()).toString(16);
            System.out.println("MD5: " + digest1.length());
            System.out.println("MD5: " + digest1);
        } catch (NoSuchAlgorithmException ex) {
           ex.printStackTrace();
        }
	}

}
