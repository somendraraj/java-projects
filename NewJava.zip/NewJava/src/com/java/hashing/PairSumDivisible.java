package com.java.hashing;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;

public class PairSumDivisible {
	
	
	/*Check if an array can be divided into pairs whose sum is divisible by k*/
	
	private static boolean isPairSum(int[] arr, int k){
		
		if((arr.length%1) != 0)
			return false;
		
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		
		for(int i=0;i<arr.length;i++){
			int rem = arr[i]%k;
			if(!map.containsKey(rem)){
				map.put(rem, 0);
			}
			map.put(rem, map.get(rem)+1);
		}
		return false;
	}
	
	public static void main(String args[]) throws DecoderException, UnsupportedEncodingException{
		
		String str = "0x3FF";
		String hexString = "FF";    
		byte[] bytes = Hex.decodeHex(hexString.toCharArray());
		System.out.println(new String(bytes, "UTF-8"));
		
		System.out.println(str.getBytes());
		
	}

}
