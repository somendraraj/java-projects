package com.java.arrays;

public class TransposeMatrix {

	public static int[][] transpose(int[][] mat) {
		int trans[][] = new int[3][3];
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				trans[j][i] = mat[i][j];
			}
		}
		return trans;

	}

	public static void main(String args[]) {

		int mat[][] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };

		int[][] res = transpose(mat);

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				System.out.print(res[i][j] + " ");
			}
			System.out.println();
		}

	}

}
