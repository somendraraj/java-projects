package com.java.arrays;

import java.util.HashSet;

public class IsArraySubsetArray {

	/**
	 * O(m*n)
	 * 
	 * @param arr1
	 * @param arr2
	 * @param m
	 * @param n
	 * @return
	 */

	static boolean isSubSet(int[] arr1, int[] arr2, int m, int n) {
		int i = 0;
		int j = 0;

		for (i = 0; i < n; i++) {

			for (j = 0; j < m; j++) {
				if (arr1[j] == arr2[i])
					break;
			}

			if (j == m)
				return false;
		}
		return true;
	}

	/**
	 * use sort and do binary search
	 * 
	 * O(mlogm + nlogm)
	 * 
	 * @param arr1
	 * @param arr2
	 * @param m
	 * @param n
	 */
	static boolean isSubset1(int[] arr1, int[] arr2, int m, int n) {
		sort(arr1, 0, m - 1);

		for (int i = 0; i < n; i++) {
			if (binarySearch(arr1, 0, m - 1, arr2[i]) == -1)
				return false;
		}
		return true;
	}

	static int binarySearch(int[] arr, int low, int high, int x) {
		if (low <= high) {
			int mid = low + (high - low) / 2;// mid index
			if ((mid == 0 || x > arr[mid - 1]) && (arr[mid] == x))
				return mid;
			else if (x > arr[mid])
				return binarySearch(arr, mid + 1, high, x);
			else
				return binarySearch(arr, low, mid - 1, x);
		}
		return -1;
	}

	static void sort(int[] arr, int low, int high) {
		if (low < high) {
			int pi = partition(arr, low, high);

			sort(arr, low, pi - 1);
			sort(arr, pi + 1, high);
		}
	}

	static int partition(int[] arr, int low, int high) {
		int pivot = arr[high];
		int i = (low - 1);// index of smaller element
		for (int j = low; j < high; j++) {
			if (arr[j] <= pivot) {
				i++;
				swap(arr, i, j);
			}
		}
		swap(arr, i + 1, high);
		return i + 1;
	}

	static void swap(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	/**
	 * sort and merge approach
	 * 
	 * O(mlogm + nlogn)
	 * 
	 * @param arr1
	 * @param arr2
	 * @param m
	 * @param n
	 * @return
	 */
	static boolean isSubset2(int[] arr1, int[] arr2, int m, int n) {

		// base case
		if (m < n)
			return false;

		sort(arr1, 0, m - 1);
		sort(arr2, 0, n - 1);

		int i = 0, j = 0;
		while (i < n && j < m) {
			if (arr1[j] < arr2[i])
				j++;
			else if (arr1[j] == arr2[i]) {
				j++;
				i++;
			} else if (arr1[j] > arr2[i])
				return false;
		}
		if (i < n)
			return false;
		else
			return true;
	}
	
	
	static boolean isSubSet3(int[] arr1, int[] arr2, int m, int n){
		HashSet<Integer> hs = new HashSet<Integer>();
		for(int i: arr1){
			hs.add(i);
		}
		
		for(int i: arr2){
			if(!hs.contains(i))
				return false;
		}
		return true;
	}

	public static void main(String args[]) {
		int[] arr1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		int[] arr2 = { 3, 4, 5, 6, 9 };

		int m = arr1.length;
		int n = arr2.length;

		System.out.println(isSubSet(arr1, arr2, m, n));

		System.out.println(isSubset1(arr1, arr2, m, n));
		
		System.out.println(isSubset2(arr1, arr2, m, n));
		
		System.out.println(isSubSet3(arr1, arr2, m, n));

	}

}
