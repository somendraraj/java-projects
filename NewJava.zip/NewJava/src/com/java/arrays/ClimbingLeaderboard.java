package com.java.arrays;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class ClimbingLeaderboard {
	
	static int[] climbingLeaderboard(int[] scores, int[] alice) {
        Set<Integer> set = new TreeSet<Integer>();
        for(int i=0;i<scores.length;i++){
        	set.add(scores[i]);
        }
        int res[] = new int[alice.length];
        for(int i=0;i<alice.length;i++){
        	set.add(alice[i]);
        	res[i] = getValue(set, alice[i]);
        	set.remove(alice[i]);
        }
        
        return res;
    }
	
	static int getValue(Set<Integer> set, int alice){
		Iterator<Integer> iter = set.iterator();
        int count = 0;
        while(iter.hasNext()){
        	int val = iter.next();
        	count++;
        	if(val == alice){
        		return set.size()-count+1;
        	}
        }
        return 0;
	}
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int scores[] = new int[n];
		for(int i=0;i<n;i++){
			scores[i] = sc.nextInt();
		}
		
		int m = sc.nextInt();
		int alice[] = new int[m];
		for(int i=0;i<m;i++){
			alice[i] = sc.nextInt();
		}
		
		int res[] = climbingLeaderboard(scores, alice);
		System.out.println(Arrays.toString(res));
	}
	

}
