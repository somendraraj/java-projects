package com.java.arrays;

public class FloodFillAlgorithm {
	static int M = 8, N = 8;

	static void floodFill(int[][] mat, int x, int y, int newC) {
		int prevC = mat[x][y];
		floodFillUtil(mat, x, y, prevC, newC);
	}

	static void floodFillUtil(int[][] mat, int x, int y, int prevC, int newC) {

		// Base case
		if (x < 0 || x >= M || y < 0 || y >= N)
			return;

		// color of screen is not same as prevC
		if (mat[x][y] != prevC)
			return;

		// fill color at x y position
		mat[x][y] = newC;

		// recur for all adjacent side
		floodFillUtil(mat, x + 1, y, prevC, newC);
		floodFillUtil(mat, x - 1, y, prevC, newC);
		floodFillUtil(mat, x, y + 1, prevC, newC);
		floodFillUtil(mat, x, y - 1, prevC, newC);
	}

	public static void main(String args[]) {

		int screen[][] = { { 1, 1, 1, 1, 1, 1, 1, 1 }, { 1, 1, 1, 1, 1, 1, 0, 0 }, { 1, 0, 0, 1, 1, 0, 1, 1 },
				{ 1, 2, 2, 2, 2, 0, 1, 0 }, { 1, 1, 1, 2, 2, 0, 1, 0 }, { 1, 1, 1, 2, 2, 2, 2, 0 },
				{ 1, 1, 1, 1, 1, 2, 1, 1 }, { 1, 1, 1, 1, 1, 2, 2, 1 }, };
		int x = 4, y = 4, newC = 3;
		floodFill(screen, x, y, newC);

		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				System.out.print(screen[i][j]);
			}
			System.out.println();
		}

	}

}
