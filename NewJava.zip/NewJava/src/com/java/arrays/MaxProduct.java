package com.java.arrays;

public class MaxProduct {

	static int min(int a, int b) {
		return a > b ? b : a;
	}

	static int max(int a, int b) {
		return a > b ? a : b;
	}

	static int getMaxProduct(int[] arr) {
		int[] min = new int[arr.length];
		int[] max = new int[arr.length];

		min[0] = max[0] = arr[0];
		int res = min[0];

		for (int i = 1; i < arr.length; i++) {
			if (arr[i] > 0) {
				max[i] = max(arr[i], max[i - 1] * arr[i]);
				min[i] = min(arr[i], min[i - 1] * arr[i]);
			} else {
				max[i] = max(arr[i], min[i - 1] * arr[i]);
				min[i] = min(arr[i], max[i - 1] * arr[i]);
			}
			res = max(res, max[i]);
		}

		print(min);
		print(max);
		return res;
	}

	static void print(int[] arr) {
		for (int a : arr) {
			System.out.print(a + " ");
		}
		System.out.println();
	}

	public static void main(String args[]) {
		int[] arr = { 2, 3, -2, 4, 7, 9 };
		System.out.println(getMaxProduct(arr));

	}
}
