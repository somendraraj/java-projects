package com.java.designpattern.abstractfactory;

public interface Color {
	void fill();
}
