package com.java.designpattern.abstractfactory;

public interface Shape {
	public void draw();
}
