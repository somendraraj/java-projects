package com.java.designpattern.builder;

public interface Packing {
	public String pack();
}
