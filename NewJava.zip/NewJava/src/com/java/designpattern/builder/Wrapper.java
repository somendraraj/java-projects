package com.java.designpattern.builder;

public class Wrapper implements Packing {

	@Override
	public String pack() {

		return "Wrapper";
	}

}
