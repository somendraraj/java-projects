package com.java.designpattern.adapter;

public class VLCPlayer implements AdvancedMediaPlayer {

	@Override
	public void playVLC(String fileName) {
		System.out.println("VLC Playing: " + fileName);
	}

	@Override
	public void playMP4(String fileName) {
		//do nothing
		//System.out.println("MP4 Playing: " + fileName);
		
	}
}
