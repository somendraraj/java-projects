package com.java.designpattern.adapter;

public interface MediaPlayer {
	
	public void play(String audioType, String fileName);

}
