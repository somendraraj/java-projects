package com.java.designpattern;

import java.io.Serializable;

public class Singleton implements Cloneable, Serializable {

	private volatile static Singleton singleton;

	static Object obj = new Object();

	// keep the constructor private
	private Singleton() {
	}

	// thread safe
	public static Singleton getInstance() {
		if (singleton == null) {
			synchronized (obj) {
				if (singleton == null) {
					singleton = new Singleton();
				}
			}
		}
		return singleton;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	protected Object readResolve() {
		return singleton;
	}

	// without thread safe
	public static Singleton getInstance1() {
		if (singleton == null) {

			singleton = new Singleton();
		}

		return singleton;
	}

}