package com.java.comparator;

public class Employee implements Comparable<Employee> {

	private int id;
	private String name;

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public Employee(int id, String name) {
		this.name = name;
		this.id = id;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Integer)
			if (this.id == (Integer) obj)
				return true;
		return false;
	}

	@Override
	public int compareTo(Employee emp) {
		return (this.id - emp.id);
	}

}
