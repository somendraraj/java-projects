package com.java.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

class SortByName implements Comparator<Employee> {
	public int compare(Employee e1, Employee e2) {
		return e1.getId() - e2.getId();
	}
}

public class Implementation {

	public static void main(String[] args) {
		Employee emp1 = new Employee(1, "emp1");
		Employee emp2 = new Employee(1, "emp2");
		Employee emp3 = new Employee(2, "emp3");

		Set<Employee> set = new HashSet<Employee>();

		if (emp1.equals(emp2)) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}

		if (!set.contains(emp1)) {
			set.add(emp1);
		}

		if (!set.contains(emp2)) {
			set.add(emp2);
		}
		if (!set.contains(emp3)) {
			set.add(emp3);
		}
		
		List<Employee> list = new ArrayList<>();
		list.addAll(set);
		
		Collections.sort(list, new SortByName());
		
		System.out.println(set);
		System.out.println(list);

	}

}
