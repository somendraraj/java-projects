package com.java.util;

public class StringUtil {
	
	
	public static void main(String args[]){
		String str = "http%3A%2F%2Ftiny.cc%2Fuho9oy";
		System.out.println(str);
		str = java.net.URLDecoder.decode(str);
		System.out.println(str);
	}

}
