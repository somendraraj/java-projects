package com.java.util;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
@SuppressWarnings("deprecation")
public class HttpClientUtil {

	private static final Log logger = LogFactory.getLog(HttpClientUtil.class);

	private static ThreadSafeClientConnManager cm = null;
	static {
		try {
			SSLContext ctx = null;
			try {
				ctx = SSLContext.getInstance("TLSv1.2");
			} catch (NoSuchAlgorithmException e) {
				logger.error(e.toString());
			}
			X509TrustManager tm = new X509TrustManager() {
				@Override
				public void checkClientTrusted(X509Certificate[] x509Certificates, String s)
						throws CertificateException {
				}

				@Override
				public void checkServerTrusted(X509Certificate[] x509Certificates, String s)
						throws CertificateException {
				}

				@Override
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return new java.security.cert.X509Certificate[0];
				}
			};
			try {
				ctx.init(null, new TrustManager[] { tm }, null);
			} catch (KeyManagementException e) {
				logger.error(e.toString());
				// TODO Auto-generated catch block
			}
			SSLSocketFactory ssf = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
			cm = new ThreadSafeClientConnManager();
			SchemeRegistry sr = cm.getSchemeRegistry();
			sr.register(new Scheme("https", 443, ssf));
			// max conn
			cm.setMaxTotal(Integer.parseInt("50"));
		} catch (NumberFormatException e) {
			logger.error("Key[MaxTotalConnections] Not Found in httpsConfig.xml", e);
		}
		// max conn of per host
		try {
			cm.setDefaultMaxPerRoute(Integer.parseInt("30"));
		} catch (NumberFormatException e) {
			logger.error("Key[MaxConnectionsPerRoute] Not Found in httpsConfig.xml", e);
		}
		IdleConnectionMonitorThread thread = new IdleConnectionMonitorThread(cm);
		thread.start();
	}

	/*
	 * <Https_Support_Protocol>TLSv1.2</Https_Support_Protocol>
	 * <Http_Socket_Timeout>5000</Http_Socket_Timeout>
	 * <Http_Connection_Timeout>10000</Http_Connection_Timeout>
	 * <MaxTotalConnections>200</MaxTotalConnections>
	 * <MaxConnectionsPerRoute>20</MaxConnectionsPerRoute>
	 * <IdleConnection_Monitor_interval>10000</IdleConnection_Monitor_interval>
	 * <Close_IdleConnections_interval>30</Close_IdleConnections_interval>
	 */

	/**
	 * monitor thread:Regularly clean up the useless and idle connection from
	 * the pool
	 * 
	 * @author lzd
	 *
	 */
	public static class IdleConnectionMonitorThread extends Thread {
		
		private final ThreadSafeClientConnManager connMgr;
		private volatile boolean shutdown;

		public IdleConnectionMonitorThread(ThreadSafeClientConnManager clientManger) {
			super();
			this.connMgr = clientManger;
		}

		@Override
		public void run() {
			try {
				while (!this.shutdown) {
					synchronized (this) {
						wait(Long.parseLong("30"));
						// close expiredConnctions
						this.connMgr.closeExpiredConnections();
						// clear up the useless connection for over 30s
						this.connMgr.closeIdleConnections(Long.parseLong("30"),
								TimeUnit.SECONDS);
					}
				}
			} catch (InterruptedException ex) {
				logger.error(ex.toString());
			}
		}

		public void shutdown() {
			this.shutdown = true;
			synchronized (this) {
				notifyAll();
			}
		}

	}

}
