package com.java.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

public class HttpTest {

	public void httpConnection() {
		PoolingHttpClientConnectionManager pool = new PoolingHttpClientConnectionManager();
		pool.setDefaultMaxPerRoute(1);
		pool.setMaxTotal(1);
		pool.closeIdleConnections(30, TimeUnit.SECONDS);
		final CloseableHttpClient httpclient = HttpClients.custom().setConnectionManager(pool).build();
	}

	public static void main(String[] args) throws ClientProtocolException, IOException, InterruptedException {
		final String url = "http://localhost:8080/";
		final CloseableHttpClient httpclient = HttpClients.createSystem();
		JSONObject json = new JSONObject();
		// {"ToUserName":"600000000720","FromUserName":"1258954586","CreateTime":1529932756542,"MsgType":"text","Content":"Hi","MsgId":"6f2f2de4-790b-375c-8909-b0c9b72d8c3f"}
		json.put("ToUserName", "600000000569");
		json.put("FromUserName", "1000018380");
		json.put("CreateTime", "1529932756542");
		json.put("MsgType", "text");
		json.put("Content", "Hi");
		json.put("MsgId", UUID.randomUUID());
		final String CONTENT_TYPE = "application/json";
		for (int i = 0; i < 3; i++) {
			new Thread(new Runnable() {

				public void run() {
					try {
						HttpPost httpPost = new HttpPost("http://10.140.98.38:8083/rcv/msg/message");
						HttpEntity entity = new StringEntity(json.toString(), CONTENT_TYPE, "UTF-8");
						httpPost.setEntity(new StringEntity(json.toString(), CONTENT_TYPE, "UTF-8"));
						CloseableHttpResponse response = httpclient.execute(httpPost);

						int status = response.getStatusLine().getStatusCode();
						System.out.println(status);
						if (status == 200) {
							HttpEntity resEntity = response.getEntity();
							// EntityUtils.consume(resEntity);
							InputStream is = resEntity.getContent();

							BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
							StringBuilder sb = new StringBuilder();
							String line = null;
							while ((line = reader.readLine()) != null) {
								sb.append(line + "\n");
							}
							is.close();
							String result = sb.toString();
							result = result.trim();
							System.out.println(result);
						}

						response.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}).start();

		}

		Thread.sleep(100000);
	}

}
