package com.java.util;

import java.lang.reflect.Type;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class JsonUtil {

	private Gson gson = null;
	static JsonParser jsonParser = new JsonParser();

	public JsonUtil() {
		gson = new Gson();
	}
	
	public JsonObject objectToJsonObject(Object ob){
		JsonObject json = null;
		if(this.gson!=null){
			json = (JsonObject) jsonParser.parse(ob.toString());
		}
		return json;
	}
	
	public String objectToJson(Object ts) {
		String jsonStr = null;
		if (this.gson != null) {
			jsonStr = this.gson.toJson(ts);
		}
		return jsonStr;
	}

	private Map<?, ?> jsonToMap(String jsonStr) {
		Map<?, ?> objMap = null;
		if (gson != null) {
			Type type = new com.google.gson.reflect.TypeToken<Map<?, ?>>() {
			}.getType();
			objMap = gson.fromJson(jsonStr, type);
		}
		return objMap;
	}

	public Object jsonToBean(String jsonStr, Class<?> cl) {
		Object obj = null;
		if (gson != null) {
			obj = gson.fromJson(jsonStr, cl);
		}
		return obj;
	}

	public Object getJsonValue(String jsonStr, String key) {
		Object rulsObj = null;
		Map<?, ?> rulsMap = jsonToMap(jsonStr);
		if (rulsMap != null && rulsMap.size() > 0) {
			rulsObj = rulsMap.get(key);
		}
		return rulsObj;
	}

}
