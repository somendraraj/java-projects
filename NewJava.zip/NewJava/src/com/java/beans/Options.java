package com.java.beans;

import java.io.Serializable;

public class Options implements Serializable {

	private static final long serialVersionUID = 1L;

	private String title;
	private String content;
	private String kind;
	private String type;
	private String text;
	private String value;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/*
	 * @SuppressWarnings("unchecked") public void maper() throws IOException{
	 * 
	 * String json = null;
	 * 
	 * ObjectMapper mapper = new ObjectMapper();
	 * 
	 * Map<String,Object> map = (Map<String, Object>) mapper.readValue(json,
	 * Map.class);
	 * 
	 * JsonNode node = mapper.readTree(json);
	 * 
	 * String title = node.get("title").toString(); String content =
	 * node.get("content").toString(); String kind =
	 * node.get("kind").toString(); String type = node.get("type").toString(); }
	 */

}
