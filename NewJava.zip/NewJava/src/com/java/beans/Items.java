package com.java.beans;

import java.io.Serializable;
import java.util.List;

public class Items implements Serializable {

	private static final long serialVersionUID = 1L;

	private String title;
	private String subtitle;
	private String imageUrl;
	private List<Options> optionsBean;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public List<Options> getOptionsBean() {
		return optionsBean;
	}

	public void setOptionsBean(List<Options> optionsBean) {
		this.optionsBean = optionsBean;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "ItemsBean [title=" + title + ", subtitle=" + subtitle + ", imageUrl=" + imageUrl + ", optionsBean="
				+ optionsBean + "]";
	}

}
