package com.array;

public class ArrangeAlternate {
	
	public static void arrangeAlternate(int arr[], int n){
		int arr1[] = new int[12];
		for(int i=0,j=0;i<n;i++){
			if(arr[i]>=0){
				arr1[j] = arr[i];
				j+=2;
			}/*else if(arr[i]<0){
				arr1[j] = arr[i];
			}*/
		}
	}
	
	
	public static void main(String args[]){
		int arr[] = {1, 2, -3, -5 , 7, -2};
		//arrangeAlternate(arr, 6);
		/*for(Integer i: arr){
			System.out.print(arr[i]+" ");
		}*/
	}

}
