package com.array;

public class ReflexiveRelation {
	
	static long count(int n){
		return 1<<(n*n-n);
	}
	
	public static void main(String args[]){
		int n = 2;
		System.out.println(count(n));
	}

}
