package com.array;

import java.util.HashMap;
import java.util.Map;

public class OrderedMap {
	
	
	public static void main(String args[]){
		Map<String, String> map = new HashMap<String, String>();
		map.put("1", "This is pne");
		map.put("3", "this is test three");
		map.put("2", "thsi is two");
		map.put("11", "This is pne");
		map.put("31", "this is test three");
		map.put("20", "thsi is two");
		
		
		
		System.out.println(map);
		
		
	}

}
