package com.array;

import java.util.Arrays;

public class ContigousArray {
	
	//Sort and traverse the array
	private static void isContigousArray(int[] arr){
		System.out.print("Before Sorting: \n");
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+ " ");
		}
		Arrays.sort(arr);
		System.out.print("\nAfter Sorting: \n");
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+ " ");
		}
		int count=0;
		for(int i=0;i<arr.length-1;i++){
			if(arr[i]!=arr[i+1] && arr[i]+1==arr[i+1]){
				count++;
			}
		}
		if(count+arr[0]==arr[arr.length-1]){
			System.out.println("\nYES");
		}else{
			System.out.println("\nNO");
		}
		
	}
	
	
	//2nd solution 
	private static void isContigousArray1(int[] arr){
		Arrays.sort(arr);
		for(int i=1;i<arr.length;i++){
			if(arr[i]-arr[i-1]>1){
				System.out.println("NO");
				return;
			}
		}
		System.out.println("YES");
	}
	
	//creating axuliary array
	private static void isContigousArray(int[] arr, int n){
		int min = 0, max = 0;
		for(int i=0;i<n;i++){
			if(arr[i]<min){
				min = arr[i];
			}
			if(arr[i]>max){
				max = arr[i];
			}
		}
		
		boolean[] aux = new boolean[max-min+1];
		Arrays.fill(aux, false);
		
		for(int i=0;i<n;i++){
			aux[arr[i]-min] = true;
		}
		
		for(int i=0;i<aux.length;i++){
			if(aux[i]==false){
				System.out.println("NO");
				return;
			}
		}
		System.out.println("YES");
	}
	
	
	//we can store all the values in hashset
	
	
	public static void main(String args[]){
		int[] arr = {5,2,3,6,4,4,6,6};
		isContigousArray(arr);
		isContigousArray1(arr);
		isContigousArray(arr, arr.length);
	}

}
