package com.array;

import java.util.Arrays;
import java.util.List;

public class ArrayLists {
	
	static List<String> list = Arrays.asList("1","2","3","4");
	
	
	public static void main(String args[]){
		System.out.println(list);
	}

}
