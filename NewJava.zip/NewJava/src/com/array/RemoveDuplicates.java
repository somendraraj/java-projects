package com.array;

import java.util.Arrays;

public class RemoveDuplicates {

	static int[] removeDuplicates(int[] arr) {
		
		Arrays.sort(arr);
		
		int[] res = new int[arr.length];

		int prev = arr[0];

		res[0] = prev;
		for (int i = 1; i < arr.length; i++) {
			int val = arr[i];
			if (prev != val) {
				res[i] = val;
			}// else {
				prev = val;
			//}

		}
		return res;
	}

	public static void main(String args[]) {
		int[][] test = new int[][] { { 1, 1, 2, 2, 3, 4, 5 }, { 1, 1, 1, 1, 1, 1, 1 }, { 1, 2, 3, 4, 5, 6, 7 },
				{ 1, 2, 1, 1, 1, 1, 1 } };

		for (int[] input : test) {
			System.out.println("Array with Duplicates       : " + Arrays.toString(input));
			System.out.println("After removing duplicates   : " + Arrays.toString(removeDuplicates(input)));
		}
	}

}
