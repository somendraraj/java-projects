package com.array;

import java.util.HashSet;
import java.util.Set;

public class MaximumInversionCount {

	static int getMaximumInversionCount(int[] arr) {
		int count = 0;
		Set<Integer> sb = new HashSet<>();
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] > arr[j]) {
					for (int k = j + 1; k < arr.length; k++) {
						if (arr[j] > arr[k]) {
							count++;
							sb.add(arr[i]);
							sb.add(arr[j]);
							sb.add(arr[k]);
						}
					}
				}
			}
		}
		System.out.println(sb.toString());
		return sb.size();
	}

	static int getInvCount(int[] arr, int n) {
		int inv_count = 0;
		for (int i = 0; i < n - 1; i++)
			for (int j = i + 1; j < n; j++) {
				if (arr[i] > arr[j])
					inv_count++;
				break;
			}

		return inv_count;
	}

	public static void main(String args[]) {
		int arr[] = { 10, 7, 5, 3, 2, 1 };
		System.out.println(getMaximumInversionCount(arr));
		System.out.println(getInvCount(arr, arr.length));
	}
}
