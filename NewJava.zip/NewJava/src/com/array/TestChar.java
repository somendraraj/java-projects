package com.array;

import java.util.Scanner;

public class TestChar {

	private static void print(int n) {
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j < i + 1; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
		for (int i = 1; i < n; i++) {
			for (int j = 1; j < n - i + 1; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
	}

	void add(int a, int b) {
		a = a + b;
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		print(n);

		String s = "myjio;jiochat;hellojio";

		String[] arr = s.split("\\;", 4);

		System.out.println(arr.length);

		for (String ss : arr) {
			System.out.println(ss);
		}

		System.out.println(arr.length);

	}
}
