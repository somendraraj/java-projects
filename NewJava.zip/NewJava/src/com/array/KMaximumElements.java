package com.array;

public class KMaximumElements {

	static void kMaximumElements(int[] arr, int k) {
		int max1 = 0;
		int max2 = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > max1) {
				max2 = max1;
				max1 = arr[i];
			}
		}

		System.out.println(max2 + " " + max1);

	}

	/*
	 * find maximum elements k times and replace max elements with -1 each time
	 */
	static void getKMaxElements(int[] arr, int k) {
		int[] max = new int[k];
		for (int i = 0; i < k; k++) {
			max[i] = getMax(arr);
			System.out.println(max[i]);
		}

		for (int i = 2; i >= 0; i--) {
			System.out.print(max[i] + " ");
		}
	}

	static int getMax(int[] arr) {
		int max = 0;
		int pos = -1;
		for (int i = 0; i < arr.length; i++) {
			if (max < arr[i]) {
				max = arr[i];
				pos = i;
			}
		}
		arr[pos] = -1;
		return max;
	}

	public static void main(String args[]) {
		int arr[] = { 10, 50, 30, 15, 70 };
		int k = 2;

		// kMaximumElements(arr, 2);

		getKMaxElements(arr, k);
	}

}
