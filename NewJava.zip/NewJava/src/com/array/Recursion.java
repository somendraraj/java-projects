package com.array;

public class Recursion {
	
	private static void print(int n){
		if(n>=1){
			print(n-1);
			System.out.println(n);
			
		}
	}
	
	public static void main(String args[]){
		print(100);
	}

}
