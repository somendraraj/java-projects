package com.bit;


/*Check given number is even or odd*/
public class EvenOdd {
	
	static int diffSign(int a, int b){
		return ((a^b)<0)?1:0;
	}
	
	static int evenOdd(int n){
		return (n&1)==0?1:0;
	}
	
	public static void main(String args[]){
		int n = 5;
		int res = evenOdd(n);
		if(res==1){
			System.out.println("Even Number");
		}else{
			System.out.println("Odd Number");
		}
		
		System.out.println(diffSign(5, -5));
	}
}
