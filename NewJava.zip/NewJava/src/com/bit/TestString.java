package com.bit;

public class TestString {
	
	public static void main(String args[]){
		String str = "Question 5000 5000 wsdfguh 456789";
		String str1 = "[Information] This question is for 5000";
		
		
		str1 = str1.substring(13).trim();
		System.out.println(str1);
		System.out.println(str1.length());
		String strArr[] = str.split(" ");
		System.out.println(strArr[1]);
	}

}
