package com.bit;

public class SwapNibble {
	
	static int swap(int x){
		return ((x&0x0f)<<4 | (x&0xf0)>>4);
	}
	
	public static void main(String args[]){
		int x = 15;
		System.out.println(swap(x));
	}

}
