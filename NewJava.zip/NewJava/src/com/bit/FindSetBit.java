package com.bit;

public class FindSetBit {

	static int findSetBit(int n) {

		for (int i = 0; i < 32; i++) {
			int num = i << i;
			if ((num & n) != 0)
				return i;
		}
		return -1;
	}

	public static void main(String[] args) {
		System.out.println(findSetBit(1));
		System.out.println(findSetBit(2));
		System.out.println(findSetBit(3));
		System.out.println(findSetBit(4));
	}

}
