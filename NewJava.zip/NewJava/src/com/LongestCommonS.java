package com;

import java.io.*;
import java.util.*;

public class LongestCommonS {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int m = sc.nextInt();
		int n = sc.nextInt();
		int A[] = new int[m];
		int B[] = new int[n];
		for (int i = 0; i < m; i++) {
			A[i] = sc.nextInt();
		}
		for (int i = 0; i < n; i++) {
			B[i] = sc.nextInt();
		}
		LCS(A, B, m, n);
	}

	static void LCS(int X[], int Y[], int m, int n) {
		int dp[][] = new int[m + 1][n + 1];
		// first row is zero
		for (int j = 0; j < n; j++)
			dp[0][j] = 0;
		// first column is zero
		for (int i = 0; i < m; i++)
			dp[i][0] = 0;
		// traverse the strings and fill the table
		int i, j;
		for (i = 1; i <= m; i++) {
			for (j = 1; j <= n; j++) {
				if (X[i - 1] == Y[j - 1]) {
					dp[i][j] = dp[i - 1][j - 1] + 1;
				} else {
					dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
				}
			}
		}
		i = m;
		j = n;
		List<Integer> cs = new ArrayList<Integer>();
		while (i > 0 && j > 0) {
			if (X[i - 1] == Y[j - 1]) {
				cs.add(X[i - 1]);
				i--;
				j--;
			} else {
				if (dp[i][j] == dp[i - 1][j])
					i--;
				else
					j--;
			}
		}
		Collections.reverse(cs);
		for (Integer num : cs) {
			System.out.print(num + " ");
		}
	}
}
