package com.algo.dp;

public class SubsetSumProblem {

	static boolean isSubsetSum(int[] set, int n, int sum) {
		if (sum == 0)
			return true;
		if (n == 0 && sum != 0)
			return false;
		if (sum < set[n - 1])
			return isSubsetSum(set, n - 1, sum);
		return isSubsetSum(set, n - 1, sum) || isSubsetSum(set, n - 1, sum - set[n - 1]);
	}

	static boolean isSubSetSum(int[] set, int n, int sum) {

		// create a boolean table
		boolean[][] table = new boolean[sum + 1][n + 1];

		// if sum is 0
		for (int i = 0; i <= n; i++) {
			table[0][i] = true;
		}

		// if n = 0 and set is empty
		for (int i = 1; i <= sum; i++) {
			table[i][0] = false;
		}

		for (int i = 1; i <= sum; i++) {
			for (int j = 1; j <= n; j++) {
				table[i][j] = table[i][j - 1];
				if (i >= set[j - 1])
					table[i][j] = table[i][j] || table[i - set[j - 1]][j - 1];
			}
		}

		return table[sum][n];
	}

	public static void main(String args[]) {
		int[] set = { 3, 34, 4, 12, 5, 2, 1, 13, 17, 30, 54, 23, 88, 164, 19 };
		int sum = 160;
		int n = set.length;
		System.out.println(System.currentTimeMillis());
		if (isSubsetSum(set, n, sum)) {
			System.out.println(true);
		} else {
			System.out.println(false);
		}
		System.out.println(System.currentTimeMillis());
		System.out.println(isSubSetSum(set, n, sum));
		System.out.println(System.currentTimeMillis());
	}

}
