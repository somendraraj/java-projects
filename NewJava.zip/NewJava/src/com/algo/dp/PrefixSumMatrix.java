package com.algo.dp;

public class PrefixSumMatrix {
	
	public static void prefixSum(int[][] arr){
		int R = arr.length;
		int C = arr[0].length;
		
		int[][] psa = new int[R][C];
		
		//psa[0][0] = arr[0][0]
		psa[0][0] = arr[0][0];
		
		//fill first row and first column
		for(int i=1;i<R;i++){
			psa[i][0] = psa[i-1][0]+arr[i][0];
		}
		
		for(int i=1;i<C;i++){
			psa[0][i] = psa[0][i-1]+arr[0][i];
		}
		
		//fill the psa matrix
		for(int i=1;i<R;i++){
			for(int j=1;j<C;j++){
				psa[i][j] = psa[i-1][j]+psa[i][j-1]-psa[i-1][j-1]+arr[i][j];
			}
		}
		
		printMatrix(psa, R, C);
	}
	
	private static void printMatrix(int[][] arr, int r, int c){
		for(int i=0;i<r;i++){
			for(int j=0;j<c;j++){
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public static void main(String args[]){
		int mat[][] = { { 1, 1, 1, 1, 1 },
                	{ 1, 1, 1, 1, 1 },
                	{ 1, 1, 1, 1, 1 },
                	{ 1, 1, 1, 1, 1 } };
		
		prefixSum(mat);
	}

}
