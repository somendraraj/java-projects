package com.algo.dp;

import java.util.Arrays;

public class BoxStackingProblem {

	static class Box implements Comparable<Box> {
		private int height;
		private int length;
		private int width;
		private int area;

		public Box(int height, int width, int length) {
			this.height = height;
			this.width = width;
			this.length = length;
		}

		@Override
		public int compareTo(Box b) {
			return b.area - this.area;
		}
	}

	static int max(int a, int b) {
		return (a > b) ? a : b;
	}

	static int min(int a, int b) {
		return (b > a) ? a : b;
	}

	static int getMaxHeight(Box[] arr, int n) {
		Box[] b = new Box[3 * n];

		for (int i = 0; i < n; i++) {
			Box box = arr[i];
			b[3 * i] = new Box(box.length, max(box.width, box.height), min(box.width, box.height));
			b[3 * i + 1] = new Box(box.width, max(box.height, box.length), min(box.height, box.length));
			b[3 * i + 2] = new Box(box.height, max(box.length, box.width), min(box.length, box.width));
		}

		// claculate the base area for each n=box
		for (int i = 0; i < b.length; i++) {
			b[i].area = b[i].width * b[i].length;
		}

		int count = 3 * n;

		Arrays.sort(b);
		int[] res = new int[count];

		for (int i = 0; i < count; i++)
			res[i] = b[i].height;
		for (int i = 0; i < count; i++) {
			Box box = b[i];
			res[i] = 0;
			int val = 0;
			for (int j = 0; j < i; j++) {
				Box prev = b[j];
				if (box.width < prev.width && box.length < prev.length) {
					val = max(val, res[j]);
				}
			}
			res[i] = box.height + val;
		}

		int max = 0;
		for (Integer i : res) {
			if (max < i)
				max = i;
		}
		return max;
	}

	public static void main(String[] args) {

		Box[] arr = new Box[2];
		arr[0] = new Box(23, 28, 35);
		arr[1] = new Box(76, 36, 3);
		
		System.out.println(getMaxHeight(arr, 2));
	}

}
