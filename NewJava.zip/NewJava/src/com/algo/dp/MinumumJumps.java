package com.algo.dp;

/**
 * 
 * @author Somendra1.Raj
 *
 */
public class MinumumJumps {

	/**
	 * recursive solution minJumps(start, end) = Min(minJumps(k, end))
	 * 
	 * @param arr
	 * @param start
	 * @param end
	 * @return
	 */
	static int minJumps(int[] arr, int start, int end) {
		// Base case
		if (start == end)
			return 0;

		// can't reach any position
		if (arr[start] == 0)
			return Integer.MAX_VALUE;

		int min = Integer.MAX_VALUE;
		for (int i = start + 1; i <= end && i <= start + arr[start]; i++) {
			int jumps = minJumps(arr, i, end);
			if (jumps != Integer.MAX_VALUE && jumps + 1 < min) {
				min = jumps + 1;
			}
		}
		return min;
	}

	/**
	 * dymanic programming approach O(n^2)
	 * @param arr
	 * @param n
	 * @return
	 */
	static int minJumps(int[] arr, int n) {
		int jumps[] = new int[n];
		if (n == 0 || arr[0] == 0)
			return Integer.MAX_VALUE;

		jumps[0] = 0;
		for (int i = 1; i < n; i++) {
			jumps[i] = Integer.MAX_VALUE;
			for (int j = 0; j < i; j++) {
				if (i <= j + arr[j] && jumps[j] != Integer.MAX_VALUE) {
					jumps[i] = Math.min(jumps[i], jumps[j] + 1);
				}
			}
		}
		return jumps[n - 1];
	}

	public static void main(String args[]) {
		int arr[] = { 1, 3, 6, 3, 2, 3, 6, 8, 9, 5 };
		int n = arr.length;
		int minJumps = minJumps(arr, 0, n - 1);
		System.out.println(minJumps);

		int minJump = minJumps(arr, n);
		System.out.println(minJump);

	}

}
