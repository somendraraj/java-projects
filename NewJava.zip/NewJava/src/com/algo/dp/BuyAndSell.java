package com.algo.dp;

public class BuyAndSell {
	
	
	
	public static void main(String args[]){
		
	}

}
