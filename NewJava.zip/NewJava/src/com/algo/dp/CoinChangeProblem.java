package com.algo.dp;

import java.util.Arrays;

public class CoinChangeProblem {

	static int countWays(int[] s, int m, int n) {
		if (n == 0)
			return 1;

		if (n < 0)
			return 0;

		if (m <= 0 && n >= 1)
			return 0;

		return countWays(s, m - 1, n) + countWays(s, m, n - s[m - 1]);
	}

	static long countWaysUsingDp(int[] coin, int m, int n) {
		long[] table = new long[n + 1];

		Arrays.fill(table, 0);

		table[0] = 1;

		for (int i = 0; i < m; i++) {
			for (int j = coin[i]; j <= n; j++) {
				table[j] += table[j - coin[i]];
			}
		}
		return table[n];
	}
	
	static long countWaysUsingDpOptimum(int[] coin, int m, int n) {
		long[] table = new long[n + 1];

		Arrays.fill(table, 0);

		table[0] = 1;

		for (int i = 0; i < m; i++) {
			for (int j = coin[i]; j <= n; j++) {
				table[j] += table[j - coin[i]];
			}
		}
		return table[n];
	}

	public static void main(String args[]) {

		int[] coin = { 2, 5, 3, 6 };
		int m = coin.length;
		int n = 10;
		int ways = countWays(coin, m, n);
		System.out.println(ways);

		long ways1 = countWaysUsingDp(coin, m, n);
		System.out.println(ways1);

	}

}
