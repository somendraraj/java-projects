package com.algo.dp;

public class EggDrop {
	
	public static void main(String args[]){
		int sum =0;
		for(int i=1;i<=14;i++){
			sum+=i;
			//System.out.println(i);
		}
		//System.out.println(sum);
		int res = eggDropFloor(2, 36);
		System.out.println(res);
	}
	
	
	static int eggDropFloor(int n, int k){
		
		if(k==0||k==1){return k;}
		if(n==1){return k;}
		
		int res = 0;
		int min = -1;
		for(int i=1;i<=k;i++){
			res = Math.max(eggDropFloor(n-1, k-1), eggDropFloor(n, k-i));
			if(min>res){
				min = res;
			}
		}
		return min+1;
	}
}
