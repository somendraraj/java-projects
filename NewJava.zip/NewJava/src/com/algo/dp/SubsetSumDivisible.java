package com.algo.dp;

/**
 * Given a set of non-negative distinct integers, and a value m, determine if
 * there is a subset of the given set with sum divisible by m.
 * 
 * @author Somendra1.Raj
 *
 */
public class SubsetSumDivisible {

}
