package com.algo.dp;

import java.util.Arrays;
import java.util.Scanner;

public class FindTwoMissingNumber {

	private static void getMissingNumber(int[] arr) {

		// Arrays.sort(arr);

		Arrays.sort(arr);
		int pos = 0;
		for (int i = 0; i < 10 - 2; i++) {
			if (arr[i] != i + 1) {
				System.out.println(i + 1);
				pos = i + 1;
				break;
			}
		}
		int finalSum = 0;
		for (int i = pos + 1; i <= 10; i++) {
			finalSum += i;
		}
		System.out.println(finalSum);
		int sum = 0;
		for (int i = arr.length - 1; i >= pos - 1; i--) {
			System.out.print(arr[i] + " ");
			finalSum = finalSum - arr[i];
		}
		System.out.println(finalSum);

		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}

		int temp[] = new int[10];
		Arrays.fill(temp, 0);
		int k = 0;
		for (int i = 0; i < 10 - 2; i++) {
			temp[arr[i] - 1] = arr[i];
		}
		System.out.println();
		for (int i = 0; i < 10; i++) {
			if (temp[i] == 0) {
				System.out.println(i + 1);
			}
		}

	}
	
	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		
		int[] arr = {1,2,3,5,6,7,9,10};
		
		FindTwoMissingNumber.getMissingNumber(arr);
		
		
		
	}

}
