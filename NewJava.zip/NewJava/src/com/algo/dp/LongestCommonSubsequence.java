package com.algo.dp;

public class LongestCommonSubsequence {
	
	/**
	 * dp solution
	 * @param x
	 * @param y
	 * @param m
	 * @param n
	 * @return
	 */
	private static int LCS(char[] x, char[] y, int m, int n){
		int[][] lcs = new int[m+1][n+1];
		
		for(int i=0;i<=m;i++){
			for(int j=0;j<=n;j++){
				if(i==0 || j==0){
					lcs[i][j]=0;
				}else if(x[i-1] == y[j-1]){
					lcs[i][j] = 1+lcs[i-1][j-1];
				}else {
					lcs[i][j] = max(lcs[i][j-1], lcs[i-1][j]);
				}
			}
		}
		int count = 1;
		/*for(int i=0;i<=m;i++){
			for(int j=0;j<=n;j++){
				if(lcs[i][j]==1){
					System.out.print(lcs[i][j]+" ");
				}
				
			}
			System.out.println();
		}*/
		
		return lcs[m][n];
	}
	
	private static int max(int i, int j){
		return i>j?i:j;
	}
	
	/**
	 * recursive solution
	 * 
	 * @param x
	 * @param y
	 * @param m
	 * @param n
	 * @return
	 */
	private static int getLCS(char[] x, char[] y, int m, int n){
		int max, i,j;
		
		//base case
		if(m==0 || n==0)
			return 0;
		
		if(x[m-1]== y[n-1]){
			return 1+getLCS(x,y, m-1, n-1);
		}else{
			return  max(getLCS(x, y, m-1, n), getLCS(x, y, m, n-1));
		}
	}
	
	
	public static void main(String args[]){
		String str1 = "AGGTAB";
		String str2 = "GXTXAYB";
		char[] x = str1.toCharArray();
		char[] y = str2.toCharArray();
		
		System.out.println(LCS(x, y, str1.length(), str2.length()));
		
		System.out.println(getLCS(x, y, str1.length(), str2.length()));
	}
}
