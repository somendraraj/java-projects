package com.algo.dp;

/**
 * Maximum size square sub-matrix with all 1s
 * 
 * @author Somendra1.Raj
 *
 *         Algorithm: 1) Construct a sum matrix S[R][C] for the given M[R][C].
 *         a) Copy first row and first columns as it is from M[][] to S[][]
 *         b) For other entries, use following expressions to construct S[][] If
 *         M[i][j] is 1 then S[i][j] = min(S[i][j-1], S[i-1][j], S[i-1][j-1]) +
 *         1 Else S[i][j] = 0 
 *         2) Find the maximum entry in S[R][C] 
 *         3) Using the value and coordinates of maximum entry in S[i], print sub-matrix of
 *         M[][]
 */
public class MaxSizeSubMatrixWithAllOnes {

	static void printMaxSubMatrix(int[][] M) {
		int i, j;
		int R = M.length;
		int C = M[0].length;
		int[][] S = new int[R][C];

		int max_of_s, max_i, max_j;

		/* first column of S */
		for (i = 0; i < R; i++)
			S[i][0] = M[i][0];
		/* first row of S */
		for (j = 0; j < C; j++)
			S[0][j] = M[0][j];
		/* Fill other entries of S */
		for (i = 1; i < R; i++) {
			for (j = 1; j < C; j++){
				if (M[i][j] == 1){
					S[i][j] = min(S[i][j-1], S[i-1][j], S[i - 1][j - 1])+1;
				}else{
					S[i][j] = 0;
				}	
			}
		}

		/* find maximum entry and index of maximum entry */
		max_of_s = S[0][0];
		max_i = 0;
		max_j = 0;
		
		//printMatrix(S);

		for (i = 0; i < R; i++) {
			for (j = 0; j < C; j++) {
				if (max_of_s < S[i][j]) {
					max_of_s = S[i][j];
					max_i = i;
					max_j = j;
				}
			}
		}
		//System.out.println(max_of_s);
		//System.out.println(max_i);
		//System.out.println(max_j);
		/* Print sub matrix */
		for (i = max_i; i > max_i - max_of_s; i--) {
			for (j = max_j; j > max_j - max_of_s; j--) {
				System.out.print(M[i][j] + " ");
			}
			System.out.println();
		}
	}

	static int min(int a, int b, int c) {
		return Math.min(a, Math.min(b, c));
	}
	
	
	static void printMatrix(int[][] mat){
		int r = mat.length;
		int c = mat[0].length;
		for(int i=0;i<r;i++){
			for(int j=0;j<c;j++){
				System.out.print(mat[i][j]+" ");
			}
			System.out.println();
		}
	}

	public static void main(String args[]) {
		int M[][] = { { 0, 1, 1, 0, 1 },
				      { 1, 1, 0, 1, 0 }, 
				      { 0, 1, 1, 1, 0 }, 
				      { 1, 1, 1, 1, 0 }, 
				      { 1, 1, 1, 1, 1 },
				      { 0, 0, 0, 0, 0 } };

		printMaxSubMatrix(M);
	}

}
