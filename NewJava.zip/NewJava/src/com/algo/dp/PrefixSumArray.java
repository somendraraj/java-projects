package com.algo.dp;

public class PrefixSumArray {
	
	public static void prefixSum(int[] arr){
		int n = arr.length;
		int[] dp = new int[n];
		
		dp[0] = arr[0];
		
		for(int i=1;i<n;i++){
			dp[i] = dp[i-1]+arr[i];
		}
		
		print(dp, n);
	}
	
	private static void print(int[] arr, int n){
		for(int i=0;i<n;i++){
			System.out.print(arr[i]+" ");
		}
	}
	
	public static void main(String args[]){
		int[] arr = { 1, 1, 1, 1, 1 };
		prefixSum(arr);
	}
}
