package com.algo.dp;

import java.util.Arrays;

/**
 * 
 * @author Somendra1.Raj
 *
 */
public class GoldMineProblem {
	
	static int getMaxGold(int[][] gold, int m, int n){
		int table[][] = new int[m][n];
		
		//fill rows
		for(int[] row: table)
			Arrays.fill(row, 0);
		
		for(int col=n-1;col>=0;col--){
			for(int row=0;row<m;row++){
				
				int rightUp = (row==0||col==n-1)?0:table[row-1][col+1];
				int right = (col==n-1)?0:table[row][col+1];
				int rightDown = (row==m-1|| col==n-1)?0:table[row+1][col+1];
				
				table[row][col] = gold[row][col]+max(right, rightUp, rightDown);
			}
		}
		
		int max = table[0][0];
		for(int i=1;i<m;i++){
			max = Math.max(max, table[i][0]);
		}
		
		return max;
	}
	
	/**
	 * method will return max value
	 * 
	 * @param a
	 * @param b
	 * @param c
	 * @return
	 */
	static int max(int a, int b, int c){
		if(a>b && a> c)return a;
		if(b>a && b> c)return b;
		return c;
	}
	
	
	/**
	 * Driver main function
	 * @param arg
	 */
	public static void main(String arg[]) {
		int gold[][] = { { 1, 3, 1, 5 },
						{ 2, 2, 4, 1 }, 
						{ 5, 0, 2, 3 }, 
						{ 0, 6, 1, 2 } };

		int m = 4, n = 4;

		System.out.print(getMaxGold(gold, m, n));
	}
}
