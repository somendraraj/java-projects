package com.algo.dp;

public class UglyNumber {

	/* check for all the numbers from 1 to n one by one */
	public static int uglyNumber(int n) {
		boolean bool = true;
		int i = 1;
		int count = 0;
		while (bool) {
			if (((i % 2) == 0) || ((i % 3) == 0) || ((i % 5) == 0)) {
				if (count == n) {
					bool = false;
					return i;
				}
			}
			count++;
			i++;
		}
		return -1;
	}

	/* This function divides a by greatest divisible power of b */
	int maxDivide(int a, int b) {
		while (a % b == 0)
			a = a / b;
		return a;
	}

	/**/
	public static int uglyNumberDP(int n) {

		return n;
	}

	// simple method,

	public static void main(String args[]) {

		int n = 7;

		System.out.println(uglyNumber(n));

	}

}
