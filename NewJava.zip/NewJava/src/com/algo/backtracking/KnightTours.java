package com.algo.backtracking;

public class KnightTours {

	static int n = 8;

	static boolean isSafe(int x, int y, int[][] arr) {
		return (x >= 0 && x < n && y >= 0 && y < n && arr[x][y] == -1);
	}

	static void print(int[][] arr) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(arr[i][j] + " ");
			}
			System.out.println();
		}
	}

	static boolean solveKnightTours() {
		int[][] sol = new int[n][n];

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				sol[i][j] = -1;
			}
		}

		int xMove[] = { 2, 1, -1, -2, -2, -1, 1, 2 };
		int yMove[] = { 1, 2, 2, 1, -1, -2, -2, -1 };

		sol[0][0] = 0;// starts from first block

		if (!solveUtil(0, 0, 1, sol, xMove, yMove)) {
			System.out.println("Solution does not exist");
			return false;
		} else {
			print(sol);
		}
		return true;
	}

	static boolean solveUtil(int x, int y, int pos, int[][] sol, int[] xMove, int[] yMove) {

		int k, nextX, nextY;
		if (pos == n * n) {
			return true;
		}

		for (k = 0; k < 8; k++) {
			nextX = x + xMove[k];
			nextY = y + yMove[k];

			if (isSafe(nextX, nextY, sol)) {
				sol[nextX][nextY] = pos;
				if (solveUtil(nextX, nextY, pos + 1, sol, xMove, yMove)) {
					return true;
				} else {
					sol[nextX][nextY] = -1;
				}
			}
		}
		return false;
	}

	public static void main(String args[]) {
		solveKnightTours();

	}
}
