package com.algo.backtracking;

import java.util.HashMap;
import java.util.Hashtable;

public class TestGS {

	TestGS t;

	public static void main(String args[]) {

		TestGS t1 = new TestGS();

		TestGS t2 = new TestGS();

		t1.t = t2;
		t2.t = t1;

		t1 = null;

		t2 = null;

		System.gc();
		
		HashMap<Object, Object> hm = new HashMap<>();
		
		hm.put(new String("key"), "val");
		hm.put(null, null);
		hm.put(null, null);
		
		System.out.println(hm);
		
		Hashtable<Object, Object> ht = new Hashtable<>();
		
		//ht.put(null, null);
		System.out.println(ht);
	}

	@Override
	protected void finalize() throws Throwable {
		System.out.println("Finalize method called!");
	}

}
