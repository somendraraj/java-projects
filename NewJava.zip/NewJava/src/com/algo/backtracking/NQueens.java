package com.algo.backtracking;

public class NQueens {

	static int N = 8;

	static void print(int[][] sol, int n) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(" " + sol[i][j] + " ");
			}
			System.out.println();
		}
	}

	static boolean isSafe(int[][] arr, int x, int y) {
		int i, j;

		// check rows
		for (i = 0; i < y; i++) {
			if (arr[x][i] == 1)
				return false;
		}

		// check upper diagonals in left side
		for (i = x, j = y; i >= 0 && j >= 0; i--, j--) {
			if (arr[i][j] == 1) {
				return false;
			}
		}

		// check lower diagonal in left side
		for (i = x, j = y; i < N && j >= 0; i++, j--) {
			if (arr[i][j] == 1)
				return false;
		}
		return true;
	}

	boolean solveNQ() {

		int[][] arr = new int[N][N];

		if (solveNQUtil(arr, 0) == false) {
			System.out.print("Solution does not exist");
			return false;
		}

		print(arr, N);
		return true;
	}

	static boolean solveNQUtil(int[][] arr, int y) {
		// case 1: If all queens are placed
		if (y >= N)
			return true;

		for (int i = 0; i < N; i++) {
			if (isSafe(arr, i, y)) {

				arr[i][y] = 1;

				if (solveNQUtil(arr, y + 1) == true)
					return true;

				arr[i][y] = 0; // backtracking
			}
		}
		return false;
	}
	
	
	public static void main(String args[]){
		NQueens nQueens = new NQueens();
		nQueens.solveNQ();
	}
}
