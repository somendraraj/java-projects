package com.algo.backtracking;

/**
 * Naive Algo: 
 * while there are untried paths { 
 * 	generate the next path 
 * 	 if this path has all blocks as 1 {
 *  	print this path; 
 * 	 } 
 * }
 * 
 * @author Somendra1.Raj
 *
 */
public class RatInMaze {
	
	/**
	 * If destination is reached
		    print the solution matrix
	   Else
		   a) Mark current cell in solution matrix as 1. 
		   b) Move forward in the horizontal direction and recursively check if this 
		       move leads to a solution. 
		   c) If the move chosen in the above step doesn't lead to a solution
		       then move down and check if this move leads to a solution. 
		   d) If none of the above solutions works then unmark this cell as 0 
		       (BACKTRACK) and return false.
	 */
	
	
	final int n = 4;

	public void printSolution(int[][] arr) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(" " + arr[i][j] + " ");
			}
			System.out.println();
		}
	}

	public boolean isSafe(int[][] maze, int x, int y) {
		return (x >= 0 && x < n && y >= 0 && y < n && maze[x][y] == 1);
	}
	
	
	public boolean solveMaze(int[][] maze) {
		int[][] sol = new int[n][n];

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				sol[i][j] = 0;
			}
		}

		if (solveMazeUtil(maze, 0, 0, sol) == false) {
			System.out.print("Solution doesn't exist");
			return false;
		}

		printSolution(sol);
		return true;
	}
	
	public boolean solveMazeUtil(int[][] maze, int x, int y, int[][] sol) {
		if (x == n - 1 && y == n - 1) {
			sol[x][y] = 1;
			return true;
		}

		if (isSafe(maze, x, y) == true) {
			
			sol[x][y] = 1;
			
			//move right
			if (solveMazeUtil(maze, x + 1, y, sol))
				return true;

			//if right doesn't have sol then move down
			if (solveMazeUtil(maze, x, y + 1, sol))
				return true;

			sol[x][y] = 0;
			return false;
		}

		return false;
	}
	
	public static void main(String args[]) {
		RatInMaze rat = new RatInMaze();
		int maze[][] = { { 1, 1, 0, 0 },
						 { 1, 1, 0, 1 }, 
						 { 0, 1, 0, 0 }, 
						 { 1, 1, 1, 1 } };
		rat.solveMaze(maze);
	}
}
