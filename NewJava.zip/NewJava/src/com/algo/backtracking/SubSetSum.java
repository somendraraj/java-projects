package com.algo.backtracking;

public class SubSetSum {

	static int N = 4;

	static void print(int[] arr, int size) {
		for (int i = 0; i < size; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

	static void subSetSum(int[] s, int[] t, int m, int n, int sum, int ite, int targetSum) {
		N++;
		if (targetSum == sum) {
			// subset found
			print(t, n);

			subSetSum(s, t, m, n - 1, sum - s[ite], ite + 1, targetSum);
			return;
		} else {
			// generate node along the breadth
			for (int i = ite; i < m; i++) {
				t[n] = s[i];
				subSetSum(s, t, m, n + 1, sum + s[i], i + 1, targetSum);
			}
		}
	}

	void generateSubset(int[] s, int size, int targetSum) {
		int[] t = new int[size];
		subSetSum(s, t, size, 0, 0, 0, targetSum);

	}

	public static void main(String args[]) {
		int[] arr = { 10, 7, 5, 18, 12, 20, 15 };

		int size = arr.length;

		SubSetSum subSetSum = new SubSetSum();
		subSetSum.generateSubset(arr, size, 35);
	}
}
