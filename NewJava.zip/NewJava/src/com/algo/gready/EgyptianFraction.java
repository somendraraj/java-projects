package com.algo.gready;

public class EgyptianFraction {
	
	
	static void printEgyptian(int nr, int dr){
		//if nr or dr is zero
		if(dr==0||nr==0)
			return;
		
		if(dr%nr==0){
			System.out.print("1/"+dr/nr);
			return;
		}
			
		
		if(nr%dr==0){
			System.out.print(nr/dr);
			return;
		}
			
		
		if(nr>dr){
			System.out.print(nr/dr+" + ");
		     printEgyptian(nr%dr, dr);
		     return;
		}
		
		int n = dr/nr+1;
		System.out.print("1/"+n+" + ");
		printEgyptian(nr*n-dr, dr*n);
			
	}
	
	public static void main(String args[]){
		int nr = 6;
		int dr = 14;
		printEgyptian(nr, dr);
	}

}
