package com.db;

import java.util.Date;

public class LyfMobileDetailsObj implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Integer id;
	private Long _userid;
	private String _mobileno;
	private String _imei;
	private Date _sendtime;
	private Date _oprdate;

	public LyfMobileDetailsObj() {
	}

	public LyfMobileDetailsObj(Integer id, Long _userid, String _mobileno, String _imei, Date _sendtime,
			Date _oprdate) {
		this.id = id;
		this._userid = _userid;
		this._mobileno = _mobileno;
		this._imei = _imei;
		this._sendtime = _sendtime;
		this._oprdate = _oprdate;
	}
	
	public LyfMobileDetailsObj(Long _userid, String _mobileno, String _imei) {
		this._userid = _userid;
		this._mobileno = _mobileno;
		this._imei = _imei;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Long get_userid() {
		return _userid;
	}

	public void set_userid(Long _userid) {
		this._userid = _userid;
	}

	public String get_mobileno() {
		return _mobileno;
	}

	public void set_mobileno(String _mobileno) {
		this._mobileno = _mobileno;
	}

	public String get_imei() {
		return _imei;
	}

	public void set_imei(String _imei) {
		this._imei = _imei;
	}

	public Date get_sendtime() {
		return _sendtime;
	}

	public void set_sendtime(Date _sendtime) {
		this._sendtime = _sendtime;
	}

	public Date get_oprdate() {
		return _oprdate;
	}

	public void set_oprdate(Date _oprdate) {
		this._oprdate = _oprdate;
	}

}
