/*package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class BaseReader {

	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/test";

	// Database credentials
	static final String USER = "root";
	static final String PASS = "";

	static JSONArray dbReader() throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		JSONArray jArray = new JSONArray();
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "");

			Statement stmt = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			stmt.setFetchSize(100);
			ResultSet rs = stmt.executeQuery("select * from `table 8`");
			System.out.println("Fetching result");
			while (rs.next()) {
				JSONObject json = new JSONObject();
				json.put("title", rs.getString(1));
				json.put("platform", rs.getString(2));
				json.put("score", rs.getInt(3));
				json.put("genre", rs.getString(4));
				json.put("editors_choice", rs.getString(5));
				jArray.add(json);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("Json Size: "+jArray.size());
		System.out.println("Json: "+jArray);
		return jArray;
	}
	
	public static void main(String args[]){
		try {
			BaseReader.dbReader();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
}
*/