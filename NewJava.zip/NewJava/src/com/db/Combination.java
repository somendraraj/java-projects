package com.db;

import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;

public class Combination {
	
	
	static void getCounts(int[] tokens, int n){
		int[] arr = new int[n+1];
		for(int i=0;i<=n;i++){
			arr[i] = i+1;
		}
		
		String results[] = new String[n];
		Arrays.fill(results, "No");
		for(int i=1;i<=n;i++){
			for(int j=0;j<tokens.length;j++){
				if(arr[i]%tokens[j]==0){
					results[i] = "Yes";
				}
			}
		}
		
		for(int i=0;i<tokens.length-1;i++){
			for(int j=i;j<tokens.length;j++){
				int k = tokens[i]+tokens[j];
				if(k<n){
					results[k]="Yes";
				}
			}
		}
		print(results);
	}
	
	static void print(String[] res){
		for(String s: res){
			System.out.println(s);
		}
		
	}

	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int t = sc.nextInt();

		int token[] = new int[t];
		for (int i = 0; i < t; i++) {
			token[i] = sc.nextInt();
		}
			
		System.out.println(new Date().toGMTString());
		getCounts(token, n);
	}

}
