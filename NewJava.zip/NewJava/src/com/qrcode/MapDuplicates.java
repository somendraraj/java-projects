package com.qrcode;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MapDuplicates {
	
	public static void main(String args[]){
		Map<String , String > map = new HashMap<String, String>();
		
		map.put("landmark", "thane");
		map.put("landmark", "thane1");
		
		System.out.println(map);
		
		long number = (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
		System.out.println(number);
		
		System.out.println(UUID.randomUUID());
		
		System.out.println((8&7));
	}

}
