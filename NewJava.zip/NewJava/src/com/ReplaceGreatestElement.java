package com;

public class ReplaceGreatestElement {
	
	public static void main(String args[]){
		int arr[] = {16, 17, 4, 3, 5, 2};
		int arr1[] = {1, 2, 3, 2, 3, 1, 3};
		replaceArray(arr, arr.length);
		int k = getNumber(arr);
		//System.out.println(k);
	}
	
	static void replaceArray(int arr[], int n){
		for(int i=0;i<n-2;i++){
			int m = arr[i];
			for(int j=i+1;j<n;i++){
				if(m < arr[j]){
					arr[i] = arr[j];
				}
			}
		}
		arr[n-1] = -1;
		for(int i=0;i<n;i++){
			System.out.println(arr[i]+" ");
		}
		
	}
	
	
	static int getNumber(int arr1[]){
		int count=0;
		int n = arr1.length;
		int i=0;
		for(i=0;i<n-1;i++){
			int num = arr1[i];
			for(int j=i+1;j<n;i++){
				if(num == arr1[j]){ 
					count++;
					if(count%2 != 0){
						break;
					}
				}
			}
		}
		
		return arr1[i];
	}

}
