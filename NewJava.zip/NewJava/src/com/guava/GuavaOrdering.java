package com.guava;

import java.util.List;

import com.google.common.collect.Ordering;

import java.util.ArrayList;
import java.util.Collections;

public class GuavaOrdering {

	public static void main(String args[]) {
		List<Integer> list = new ArrayList<Integer>();
		list.add(new Integer(10));
		list.add(new Integer(2));
		list.add(new Integer(34));
		list.add(new Integer(17));
		list.add(new Integer(7));
		list.add(new Integer(42));
		list.add(new Integer(21));
		list.add(new Integer(3));
		list.add(new Integer(15));
		list.add(new Integer(27));
		list.add(new Integer(25));
		list.add(new Integer(12));

		Ordering<Integer> ordering = Ordering.natural();
		System.out.println("Input List: ");
		System.out.println(list);
		System.out.println("List is sorted: " + ordering.isOrdered(list));

		Collections.sort(list, ordering);
		System.out.println("Sorted List: ");
		System.out.println(list);

		System.out.println("===========================================");
		System.out.println("List is sorted: " + ordering.isOrdered(list));
		System.out.println("Maximum element: " + ordering.max(list));
		System.out.println("Minimum element: " + ordering.min(list));

		Collections.sort(list, ordering.reverse());
		System.out.println("Reverse List: " + list);

		list.add(null);
		System.out.println("Null added to sorted list");
		System.out.println(list);

		System.out.println("===========================================");
		Collections.sort(list, ordering.nullsFirst());
		System.out.println("Null first sorted list: ");
		System.out.println(list);

		List<String> names = new ArrayList<String>();

		names.add("Ram");
		names.add("Shyam");
		names.add("Mohan");
		names.add("Sohan");
		names.add("Ramesh");
		names.add("Suresh");
		names.add("Naresh");
		names.add("Mahesh");
		names.add(null);
		names.add("Vikas");
		names.add("Deepak");

		System.out.println("Another List: ");
		System.out.println(names);
		
		Ordering<String> order = Ordering.natural();

		Collections.sort(names, order.nullsFirst().reverse());
		System.out.println("Null first then reverse sorted list: ");
		System.out.println(names);

	}

}
