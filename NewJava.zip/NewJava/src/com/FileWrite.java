package com;


import java.io.FileWriter;
import java.io.IOException;

public class FileWrite {

	 public static void main(String args[]) throws IOException {  
	     

	      try {
	    	  String filename= "config.properties";
	    	  FileWriter fw = new FileWriter(filename,true); 
	    	  fw.write("\nadd a line"+"="+"http://10.135.140.118:9082");//appends the string to the file
	    	  fw.close();
	    	  System.out.println("Added successfully...");
	      }catch(IOException ioe)
	      {
	    	  System.err.println("IOException: " + ioe.getMessage());
	      }
	   }
}
