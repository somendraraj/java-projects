package com;

import java.util.Scanner;

public class AverageOfTwoNum {
	
	public int get_average(int a, int b){
		int a_half=a/2;
		int b_half=b/2;
		boolean a_even=a%2==0?true:false;
		boolean b_even=b%2==0?true:false;
		if(a>=0 && b>=0){
			if(!a_even && !b_even){
				return a_half+b_half+1;
			}
			return a_half+b_half;
		}else if(a<0 && b<0){
			if(a_even && b_even){
				return a_half+b_half;
			}
			return a_half+b_half-1;
		}else{
			int sum = a + b;
			if(sum < 0 && sum%2 !=0){
				return sum/2-1;
			}
			return sum/2;
		}	
	}
	
	public static void main(String[] args){
		int n, a,b;
		System.out.println("Number of test case");
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		AverageOfTwoNum obj = new AverageOfTwoNum();
		for(int i=0;i<n;i++){
			a = sc.nextInt();
			b = sc.nextInt();
			System.out.println("Average : "+obj.get_average(a,b));
		}
	}

}
