package com;

public class PrintNumbers {

	public static void main(String args[]) {
		PrintNumbers pn = new PrintNumbers();
		pn.print(4);

	}

	public int print(int n) {
		if (n == 0)
			return 0;
		else {
			System.out.println(n);
			return print(n - 1);
		}
	}

}
