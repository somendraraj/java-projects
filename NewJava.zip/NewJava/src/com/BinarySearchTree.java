package com;

public class BinarySearchTree {
	class Node {
		Node left, right;
		int key;

		public Node(int item) {
			key = item;
			left = right = null;
		}
	}

	// Root node
	Node root;

	BinarySearchTree() {
		root = null;
	}

	void insert(int key) {
		root = insertRec(root, key);
	}

	Node insertRec(Node root, int key) {

		/* If tree is empty, return */
		if (root == null) {
			root = new Node(key);
			return root;
		}

		if (key < root.key) {
			root.left = insertRec(root.left, key);

		} else if (root.key < key) {
			root.right = insertRec(root.right, key);

		}

		return root;
	}

	void inOrder(int len) {
		inorderRec(root, len);
	}

	static int count = 0;

	static void inorderRec(Node root, int len) {

		if (root != null) {
			count++;
			inorderRec(root.left, len);
			System.out.println(root.key + " ");
			inorderRec(root.right, len);
		}
		// System.out.print(len-count+1);
	}

	public static void main(String args[]) {
		BinarySearchTree bst = new BinarySearchTree();
		/*
		 * bst.insert(50); bst.insert(30); bst.insert(20); bst.insert(40);
		 * bst.insert(70); bst.insert(60); bst.insert(80);
		 */

		int arr[] = { 1, 1, 1, 1, 1, 2, 3, 4, 7 };
		int len = arr.length;
		for (int i = 0; i < len; i++) {
			bst.insert(arr[i]);
		}
		// bst.inOrder(len);
	}

}
