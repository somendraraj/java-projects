package com;

import java.util.Scanner;

public class CandyProblem {
	
	    public static void main(String[] args) {
	        Scanner in = new Scanner(System.in);
	        int n = in.nextInt();
	        int t = in.nextInt();
	        int[] c = new int[t];
	        for(int c_i=0; c_i < t; c_i++){
	            c[c_i] = in.nextInt();
	        }
	        // your code goes here
	        int x = getCandy(n,t, c);
	        System.out.println(x);
	    }
	    
	    static int getCandy(int n, int t, int c[]){
	    	int count = 0;
	    	int x = 0;
	    	for(int i=0;i<t;i++){
	    		n = n - c[i];
	    		x = x + c[i];
	    		if( i!= t-1 && n < 5 ){
	    			n = n + x;
	    			count = count+x;
	    			x = 0;		
	    		}
	    	}	
	    	return count;
	    }
}
