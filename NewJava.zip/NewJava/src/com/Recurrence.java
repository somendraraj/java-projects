package com;

/*T(0) = T(1) = 2
 * T(n) = Sumation i=1, i<n, 2*T(i)*T(i-1)
 * */

public class Recurrence {
	
	static int getSum(int n){
		int sum = 0;
		
		if(n == 0 || n == 1){
			return 2;
		}
		for(int i=1;i<n;i++){
			sum = sum + 2*getSum(i)*getSum(i-1);
		}
		
		return sum;
	}
	
	/*Optimize using DP Complexity O(n^2)*/
	static int findSum(int n){
		int T[] = new int[n+1];
		T[0] = T[1] = 2;
		for(int i=2;i<=n;i++){
			T[i] = 0;
			for(int j=1;j<i;j++){
				T[i] +=2*T[j]*T[j-1];
			}
		}
		
		return T[n];
	}
	
	/*More Optimize solution Complexity O(n)*/
	static int getMoreOptimize(int n){
		int T[] = new int[n+1];
		T[0] = T[1] = 2;
		T[2] = 2*T[1]*T[0];
		for(int i=3;i<=n;i++){
			T[i] = T[i-1]+2*T[i-1]*T[i-2];
		}
		
		return T[n];
	}
	
	
	public static void main(String args[]){
		int n =3;
		int m = getSum(n);
		System.out.println(m);
		
		System.out.println(findSum(n));
		
		System.out.println(getMoreOptimize(n));
	}
}
