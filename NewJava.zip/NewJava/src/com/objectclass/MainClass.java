package com.objectclass;

public class MainClass extends BeanClass{
	
	
	public static void main(String args[]){
		
		String str = "[BeanClass [name=somendra, address=bangalore]]";
		
		try {
			try {
				@SuppressWarnings("unchecked")
				BeanClasss b = (BeanClasss) Class.forName(str.toString()).newInstance();
				System.out.println(b.getName());
				
				
				
			} catch (InstantiationException | IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		/*Object obj = (Object) str;
		
		BeanClass bean = BeanClass.class.cast(str);
		
		
		System.out.println("Bean"+ bean);
		System.out.println("Bean Name"+bean.getName());
		*/
		
	}
	
}


class BeanClasss {
	
	private String name;
	private String address;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "BeanClass [name=" + name + ", address=" + address + "]";
	}

}
